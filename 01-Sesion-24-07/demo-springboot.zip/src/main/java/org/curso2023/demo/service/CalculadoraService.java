package org.curso2023.demo.service;

public class CalculadoraService {
    public Double division(Double num1, Double num2) {
        return num1/num2;
    }
}
