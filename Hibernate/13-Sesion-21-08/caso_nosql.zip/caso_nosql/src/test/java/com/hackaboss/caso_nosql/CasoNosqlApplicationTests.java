package com.hackaboss.caso_nosql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CasoNosqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
