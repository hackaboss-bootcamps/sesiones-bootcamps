package com.hackaboss.caso3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Caso3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
