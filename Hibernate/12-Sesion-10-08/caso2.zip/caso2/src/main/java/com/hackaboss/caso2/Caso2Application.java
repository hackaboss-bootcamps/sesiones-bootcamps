package com.hackaboss.caso2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Caso2Application {

	public static void main(String[] args) {
		SpringApplication.run(Caso2Application.class, args);
	}

}
