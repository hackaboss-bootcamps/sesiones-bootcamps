package com.grupo2.aap.Entity.Seguridad.LogsOperaciones;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que implementa la entidad LogAdministración, en la cual se van a almacenar todas los eventos
 * que se dan en el sistema en referencia a las tareas de Administración que no
 * provoquen problemas de seguridad. En este caso se usará su homóloga SecLogAdministración.
 *
 * */

import com.grupo2.aap.Entity.Seguridad.Component.LogData;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="log_administracion")
public class LogAdministracion extends LogData {

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de Datos">

    /**
     * Método que Clona la información de otra entidad LogAdministracion en sí misma
     *
     * @param PLogClonar LogAdministracion cuyos parámetros se desean clonar
     * @return Sí se ha realizado correctamente o no la operación.
     */
    public boolean clone(LogAdministracion PLogClonar){
        boolean VDevolucion;

        try{
            this.setOperacion(PLogClonar.getOperacion());
            this.setTipoEntidad(PLogClonar.getTipoEntidad());
            this.setEntidadId(PLogClonar.getEntidadId());
            this.setFecha(PLogClonar.getFecha());
            this.setUsuario(PLogClonar.getUsuario());
            this.setMensaje(PLogClonar.getMensaje());

            VDevolucion = true;
        }catch (Exception ex){
            VDevolucion = false;
        }

        return VDevolucion;
    }

// </editor-fold>

}
