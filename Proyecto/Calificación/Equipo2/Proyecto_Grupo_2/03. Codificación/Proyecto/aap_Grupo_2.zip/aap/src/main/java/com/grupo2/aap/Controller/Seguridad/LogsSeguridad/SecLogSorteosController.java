package com.grupo2.aap.Controller.Seguridad.LogsSeguridad;


import com.grupo2.aap.Entity.Seguridad.LogsSeguridad.SecLogSorteos;
import com.grupo2.aap.Iservice.Seguridad.LogsSeguridad.ISecLogSorteosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/seclogsorteos")
public class SecLogSorteosController {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    @Autowired
    private ISecLogSorteosService service;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos Controladores de Conexión">

    @GetMapping("/ID")
    public Optional<SecLogSorteos> show(@RequestParam Long id) {
        return service.findById(id);
    }

    @GetMapping("/OP")
    public List<SecLogSorteos> findByOperation(@RequestParam Long operation) {
        return service.findListByOperation(operation);
    }
    @GetMapping("/TE")
    public List<SecLogSorteos> findListByTypeOfEntity(@RequestParam Long tipoentidad) {
        return service.findListByTypeOfEntity(tipoentidad);
    }
    @GetMapping("/EN")
    public List<SecLogSorteos> findListByEntity(@RequestParam Long entidad) {
        return service.findListByEntity(entidad);
    }
    @GetMapping("/FE")
    public List<SecLogSorteos> findByDate(@RequestParam LocalDateTime fechaInicio,
                                          @RequestParam LocalDateTime fechaFin) {
        return service.findByDate(fechaInicio,fechaFin);
    }
    @GetMapping("/US")
    public List<SecLogSorteos> findListByUser(@RequestParam Long usuario){
        return service.findListByUser(usuario);
    }
    @GetMapping("/ME")
    public List<SecLogSorteos> findListByMessage(@RequestParam String mensaje) {
        return service.findListByMessage(mensaje);
    }
    @PostMapping
    @ResponseStatus(code = HttpStatus.CREATED)
    public SecLogSorteos save(@RequestBody SecLogSorteos seclogadministracion) {
        return service.save(seclogadministracion);
    }

// </editor-fold>

}
