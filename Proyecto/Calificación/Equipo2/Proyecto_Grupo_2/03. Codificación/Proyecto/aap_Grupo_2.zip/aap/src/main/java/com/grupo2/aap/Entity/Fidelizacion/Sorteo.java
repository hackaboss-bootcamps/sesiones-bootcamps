package com.grupo2.aap.Entity.Fidelizacion;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que implementa la Entidad Sorteo. Esta clase contendrá la información básica y las operaciones
 * Básicas con dicha información.
 *
 * */
@Entity
@Table(name="sorteos")
public class Sorteo {

// <editor-fold defaultstate="collapsed" desc="Constantes">

    public static final int PREMIO_DTO_PORCENTAJE_FACTURA =1;
    public static final int PREMIO_DTO_TARJETA_REGALO =2;
    public static final int PREMIO_DTO_DESCUENTO_PRODUCTOS =3;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Id del Sorteo */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Nombre del Sorteo */
    @Column(name = "nombre", length = 50, unique = true, nullable = false)
    private String nombre;

    /** Fecha de Creación del Sorteo */
    @Column(name = "fecha_creacion", nullable = false)
    private LocalDate fechaCreacion;

    /** Fecha de Inicio del Sorteo */
    @Column(name = "fecha_inicio", unique = true, nullable = false)
    private LocalDate fechaInicio;

    /** Fecha de Fin del Sorteo */
    @Column(name = "fecha_fin", unique = true, nullable = false)
    private LocalDate fechaFin;

    /** Número de Días después de la Fecha Fin donde las participaciones
     * son válidas del Sorteo */
    @Column(name = "dias_participacion_valida", nullable = false)
    private Integer diasParticipacionValida=1;

    /** Número Máximo de Ganadores del Sorteo */
    @Column(name = "num_max_ganador")
    private Integer numMaxGanador=1;

    /** En caso de Ser un sorteo que descuente un porcentaje de la Factura
     * dicho porcentaje estará almacenado en este atributo */
    @Column(name = "porcentaje_descuento_factura")
    private Integer PorcentajeDescuentoFactura=0;

    /** En caso de Ser un sorteo que descuente mediante una Tarjeta Regalo el
     * importe de la Factura dicha cantidad estará almacenada en este atributo */
    @Column(name = "descuento_tarjeta_regalo")
    private double DescuentoTarjetaRegalo=0.0;

    /** Atributo de Borrado Lógico de la Entidad */
    @Column(name = "fecha_eliminacion", nullable = true)
    private LocalDateTime fechaEliminacion;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Encapsulamiento">

    /**
     * Método que Devuelve el Id de la entidad.
     *
     * @return Id de la entidad.
     */
    public Long getId() {
        return id;
    }

    /**
     * Método que Introduce el Id del Sorteo.
     *
     * @param id de la entidad.
     *
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Método que Devuelve el Nombre del Sorteo.
     *
     * @return Nombre del Sorteo.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Método que Introduce el nombre del Sorteo.
     *
     * @param nombre de la entidad.
     *
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Método que Devuelve la Fecha de Creación del Sorteo.
     *
     * @return Fecha de Creación del Sorteo.
     */
    public LocalDate getFechaCreacion() {
        return fechaCreacion;
    }

    /**
     * Método que Introduce la Fecha de Creación del Sorteo.
     *
     * @param fechaCreacion del Sorteo.
     *
     */
    public void setFechaCreacion(LocalDate fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    /**
     * Método que Devuelve la Fecha de Inicio del Sorteo.
     *
     * @return FEcha de Inicio del Sorteo.
     */
    public LocalDate getFechaInicio() {
        return fechaInicio;
    }

    /**
     * Método que Introduce la Fecha de Inicio del Sorteo.
     *
     * @param fechaInicio del Sorteo.
     *
     */
    public void setFechaInicio(LocalDate fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    /**
     * Método que Devuelve la Fecha de Fin del Sorteo.
     *
     * @return Fecha Fin del Sorteo.
     */
    public LocalDate getFechaFin() {
        return fechaFin;
    }

    /**
     * Método que Introduce la Fecha de Fin del Sorteo.
     *
     * @param fechaFin del Sorteo.
     *
     */
    public void setFechaFin(LocalDate fechaFin) {
        this.fechaFin = fechaFin;
    }

    /**
     * Método que Devuelve el Número de Días que las Participaciones son válidas.
     *
     * @return Número de Días en las que las participaciones son Válidas.
     */
    public Integer getDiasParticipacionValida() {
        return diasParticipacionValida;
    }

    /**
     * Método que Introduce el número de días en las que las participaciones son válidas.
     *
     * @param diasParticipacionValida Días participación válida del Sorteo.
     *
     */
    public void setDiasParticipacionValida(Integer diasParticipacionValida) {
        this.diasParticipacionValida = diasParticipacionValida;
    }

    /**
     * Método que Devuelve el Número máximo de Ganadores del Sorteo
     *
     * @return Número máximo de Ganadores
     */
    public Integer getNumMaxGanador() {
        return numMaxGanador;
    }

    /**
     * Método que Introduce el número máximo de Ganadores del Sorteo.
     *
     * @param numMaxGanador Número máximo de ganadores del Sorteo.
     *
     */
    public void setNumMaxGanador(Integer numMaxGanador) {
        this.numMaxGanador = numMaxGanador;
    }

    /**
     * Método que Devuelve el Porcentaje de Descuento que se aplicarán en las Facturas de los
     * Clientes ganadores del Sorteo.
     *
     * @return Porcentaje de Descuento en Factura como premio del Sorteo.
     */
    public Integer getPorcentajeDescuentoFactura() {
        return PorcentajeDescuentoFactura;
    }

    /**
     * Método que Introduce el Porcentaje de Descuento en Factura que se sortea como premio
     * del Sorteo.
     *
     * @param porcentajeDescuentoFactura Porcentaje de Descuento de la Factura del Sorteo.
     */
    public void setPorcentajeDescuentoFactura(Integer porcentajeDescuentoFactura) {
        PorcentajeDescuentoFactura = porcentajeDescuentoFactura;
    }

    /**
     * Método que Devuelve el Descuento económico que se aplicarán en las Facturas de los
     * Clientes ganadores del Sorteo.
     *
     * @return Descuento económico en Factura como premio del Sorteo.
     */
    public Double getDescuentoTarjetaRegalo() {
        return DescuentoTarjetaRegalo;
    }

    /**
     * Método que Introduce el Descuento económico en Factura que se sortea como premio
     * del Sorteo.
     *
     * @param descuentoTarjetaRegalo Descuento económico en la Factura del Sorteo.
     */
    public void setDescuentoTarjetaRegalo(Double descuentoTarjetaRegalo) {
        DescuentoTarjetaRegalo = descuentoTarjetaRegalo;
    }

    /**
     * Método que Devuelve la Fecha de Eliminación del Sorteo
     *
     * @return Fecha de Eliminación del Sorteo.
     */
    public LocalDateTime getFechaEliminacion() {
        return fechaEliminacion;
    }

    /**
     * Método que Introduce la Fecha de Eliminación del Sorteo
     *
     * @param fechaEliminacion Fecha en la que se ha eliminado el Sorteo.
     */
    public void setFechaEliminacion(LocalDateTime fechaEliminacion) {
        this.fechaEliminacion = fechaEliminacion;
    }

    /**
     * Método que Devuelve la fecha máxima en las que las participaciones són válidas para hacerlas
     * efectivas
     *
     * @return Fecha Máxima de Validez de las participaciones premiadas.
     */
    public LocalDate getFechaMaxValidez() {
        LocalDate VDevolucion;

        try {
            VDevolucion=this.getFechaFin().plusDays(this.getDiasParticipacionValida());
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    /**
     * Método que Devuelve el tipo de premio tipificado mediante constantes.
     *
     * @return Tipo de premio que reparte el Sorteo.
     */
    public int devolverTipoPremio(){
        int VDevolucion;

        try{
            if (this.getPorcentajeDescuentoFactura()>0){
                VDevolucion= PREMIO_DTO_PORCENTAJE_FACTURA;
            }else{
                if (this.getDescuentoTarjetaRegalo()>0){
                    VDevolucion= PREMIO_DTO_TARJETA_REGALO;
                }else{
                    VDevolucion= PREMIO_DTO_DESCUENTO_PRODUCTOS;
                }
            }
        }catch (Exception ex){
            VDevolucion=-1;
        }

        return VDevolucion;
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de Datos">

    /**
     * Método que Clona la información de otra entidad sorteo en sí misma.
     *
     * @param PSorteoClonar Sorteo cuyos parámetros se desean clonar
     * @return Sí se ha realizado correctamente o no la operación.
     */
    public boolean clone(Sorteo PSorteoClonar){
        boolean VDevolucion;

        try{
            this.setId(PSorteoClonar.getId());
            this.setNombre(PSorteoClonar.getNombre());
            this.setFechaCreacion(PSorteoClonar.getFechaCreacion());
            this.setFechaInicio(PSorteoClonar.getFechaInicio());
            this.setFechaFin(PSorteoClonar.getFechaFin());
            this.setDiasParticipacionValida(PSorteoClonar.getDiasParticipacionValida());
            this.setNumMaxGanador(PSorteoClonar.getNumMaxGanador());
            this.setPorcentajeDescuentoFactura(PSorteoClonar.getPorcentajeDescuentoFactura());
            this.setDescuentoTarjetaRegalo(PSorteoClonar.getDescuentoTarjetaRegalo());
            this.setFechaEliminacion(PSorteoClonar.getFechaEliminacion());

            VDevolucion = true;
        }catch (Exception ex){
            VDevolucion = false;
        }

        return VDevolucion;
    }

// </editor-fold>


}
