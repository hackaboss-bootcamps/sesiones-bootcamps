package com.grupo2.aap.Component;

import com.grupo2.aap.Entity.Seguridad.Component.LogData;
import com.grupo2.aap.Entity.Seguridad.LogsOperaciones.LogAdministracion;
import com.grupo2.aap.Entity.Seguridad.LogsOperaciones.LogSorteos;
import com.grupo2.aap.Entity.Seguridad.LogsOperaciones.LogVentas;
import com.grupo2.aap.Entity.Seguridad.LogsSeguridad.SecLogAdministracion;
import com.grupo2.aap.Entity.Seguridad.LogsSeguridad.SecLogSorteos;
import com.grupo2.aap.Entity.Seguridad.LogsSeguridad.SecLogVentas;
import com.grupo2.aap.Entity.Seguridad.MaestrasSeguridad.LogOperaciones;
import com.grupo2.aap.Entity.Seguridad.MaestrasSeguridad.LogTipoEntidad;
import com.grupo2.aap.Entity.Seguridad.Usuario;
import com.grupo2.aap.Iservice.Seguridad.IUsuarioService;
import com.grupo2.aap.Iservice.Seguridad.LogsOperaciones.ILogAdministracionService;
import com.grupo2.aap.Iservice.Seguridad.LogsOperaciones.ILogSorteosService;
import com.grupo2.aap.Iservice.Seguridad.LogsOperaciones.ILogVentasService;
import com.grupo2.aap.Iservice.Seguridad.LogsSeguridad.ISecLogAdministracionService;
import com.grupo2.aap.Iservice.Seguridad.LogsSeguridad.ISecLogSorteosService;
import com.grupo2.aap.Iservice.Seguridad.LogsSeguridad.ISecLogVentasService;
import com.grupo2.aap.Iservice.Seguridad.MaestrasSeguridad.ILogOperacionesService;
import com.grupo2.aap.Iservice.Seguridad.MaestrasSeguridad.ILogTipoEntidadService;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que Gestionará todas las Operaciones de Seguridad del Sistema. Sus tareas principales son:
 *      - Gestión de Permisos
 *      - Gestión de Usuarios
 *      - Gestión de Roles
 *      - Registro de Logs de Administración
 *      - Registro de Logs de Ventas
 *      - Registro de Logs de Sorteos
 *      - Respuesta a los eventos de Seguridad Graves
 *
 * */
public class SecurityCtrl {

// <editor-fold defaultstate="collapsed" desc="Constantes">

    // <editor-fold defaultstate="collapsed" desc="Constantes de Tipo Incidencia">
    public final static int TIPO_SEC_ADMINISTRACION = 1;
    public final static int TIPO_SEC_SORTEOS = 2;
    public final static int TIPO_SEC_VENTAS = 3;
    public final static int TIPO_SEGURIDAD = 4;
    public final static int TIPO_ADMINISTRACION = 5;
    public final static int TIPO_SORTEOS = 6;
    public final static int TIPO_VENTAS = 7;

    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Constantes de Entidad">

    public final static long ENTIDAD_LOG_ADMINISTRACION = 1;
    public final static long ENTIDAD_LOG_SORTEOS = 2;
    public final static long ENTIDAD_LOG_VENTAS = 3;
    public final static long ENTIDAD_SEC_LOG_ADMINISTRACION = 4;
    public final static long ENTIDAD_SEC_LOG_SORTEOS = 5;
    public final static long ENTIDAD_SEC_LOG_VENTAS = 6;
    public final static long ENTIDAD_FACTURA = 7;
    public final static long ENTIDAD_FACTURA_SIMPLIFICADA = 8;
    public final static long ENTIDAD_DETALLE_FACTURA = 9;
    public final static long ENTIDAD_DETALLE_FACTURA_SIMPLIFICADA = 10;
    public final static long ENTIDAD_CLIENTE = 11;
    public final static long ENTIDAD_FAMILIA_PRODUCTO = 12;
    public final static long ENTIDAD_FORMA_PAGO = 13;
    public final static long ENTIDAD_PRODUCTO = 14;
    public final static long ENTIDAD_SORTEO = 15;
    public final static long ENTIDAD_PARTICIPACION = 16;
    public final static long ENTIDAD_DETALLE_SORTEO = 17;
    public final static long ENTIDAD_EMPLEADO = 18;
    public final static long ENTIDAD_USUARIO = 19;

    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Constantes de Operacion">

    public final static long OPERACION_ALTA = 1;
    public final static long OPERACION_BAJA = 2;
    public final static long OPERACION_CONSULTA = 3;
    public final static long OPERACION_MODIFICACION = 4;
    public final static long OPERACION_ELIMINACION = 5;
    public final static long OPERACION_REALIZACION = 6;
    public final static long OPERACION_CONTROL = 6;

    // </editor-fold>

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Objeto Usuario que representa al Usuario Activo en la Sesión */
    private Usuario usuarioActivo = null;

    /** Servicio de Usuario */
    private IUsuarioService servicioUsuario;

    /** Servicio de Log de Administración */
    private ILogAdministracionService logAdministracionService;

    /** Servicio de Log de Sorteos */
    private ILogSorteosService logSorteosService;

    /** Servicio de Log de Ventas */
    private ILogVentasService logVentasService;

    /** Servicio de Log de Seguridad de Administración */
    private ISecLogAdministracionService secLogAdministracionService;

    /** Servicio de Log de Seguridad de Sorteos */
    private ISecLogSorteosService secLogSorteosService;

    /** Servicio de Log de Seguridad de Ventas */
    private ISecLogVentasService secLogVentasService;

    /** Servicio de Log de Operaciones susceptibles de ser Registradas */
    private ILogOperacionesService logOperacionesService;

    /** Servicio de Log de Tipos de Entidad que almacenarán sus registros en el log del sistema */
    private ILogTipoEntidadService logTipoEntidadService;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Constructores">

    /**
     * Constructor de la Clase
     *
     * @param  PServicioUsuario Servicio de Información de Usuario
     * @param  PLogAdministracionService Servicio de Información del Log de Administración
     * @param  PLogSorteosService Servicio de Información del Log de Sorteos
     * @param  PLogVentasService Servicio de Información del Log de Ventas
     * @param  PSecLogAdministracionService Servicio de Información del Log de Seguridad de Administración
     * @param  PSecLogSorteosService Servicio de Información del Log de Seguridad de Sorteos
     * @param  PSecLogVentasService Servicio de Información del Log de Seguridad de Ventas
     * @param  PLogOperacionesService Servicio de Información del Log de Operaciones
     * @param  PLogTipoEntidadService Servicio de Información del Log de Tipo de Entidades
     *
     */
    public SecurityCtrl(IUsuarioService PServicioUsuario,
                        ILogAdministracionService PLogAdministracionService,
                        ILogSorteosService PLogSorteosService,
                        ILogVentasService PLogVentasService,
                        ISecLogAdministracionService PSecLogAdministracionService,
                        ISecLogSorteosService PSecLogSorteosService,
                        ISecLogVentasService PSecLogVentasService,
                        ILogOperacionesService PLogOperacionesService,
                        ILogTipoEntidadService PLogTipoEntidadService){

        this.servicioUsuario=PServicioUsuario;
        this.logAdministracionService=PLogAdministracionService;
        this.logSorteosService=PLogSorteosService;
        this.logVentasService=PLogVentasService;
        this.secLogAdministracionService=PSecLogAdministracionService;
        this.secLogSorteosService=PSecLogSorteosService;
        this.secLogVentasService=PSecLogVentasService;
        this.logOperacionesService=PLogOperacionesService;
        this.logTipoEntidadService=PLogTipoEntidadService;

    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de la Seguridad">

    /**
     * Método que autentifica al Usuario del Sistema mediante un Nombre de Usuario y una
     * Contrasena
     *
     * @param  PNombreUsuario Nombre del Usuario que se desea Autentificar
     * @param  PContrasenha Contrasena del Usuario que se desea Autentificar
     *
     * @return Sí se ha autentificado correctamente o no el usuario.
     */
    public boolean autentificar(String PNombreUsuario,String PContrasenha){
        boolean VDevolucion;
        Optional<Usuario> VUsuario;

        try{
            if (this.usuarioActivo==null){
                VUsuario=servicioUsuario.authenticate(PNombreUsuario,PContrasenha);
                if (!VUsuario.isEmpty()){
                    this.usuarioActivo=VUsuario.get();
                    VDevolucion = true;
                }else{
                    VDevolucion = false;
                }
            }else{
                VDevolucion = true;
            }
        }catch (Exception ex){
            VDevolucion = false;
        }

        return VDevolucion;
    }

    /**
     * Método que Registra una incidencia en el sistema. Se consideran los tres niveles
     * estándard:
     *              - Information
     *              - Warning
     *              - Error
     *
     * @param PTipoIncidencia Parámetro que determinará el LOG dónde se va a almacenar los datos. En este caso
     *                        la ubicación final del log dependerá de dos factores importantes:
     *                        - Nivel de Gravedad
     *                        - Lugar en el que se dio el problema.
     *                        (Valores posibles: Constantes de la Clase TIPO_[])
     *
     * @param POperacion Tipología de Operación que se estaba realizando en el momento de darse la incidencia.
     *                   (Valores posibles: Constantes de la Clase OPERACION_[])
     *
     * @param PTipoEntidad Tipología de Tipo de Entidad que estaba realizando la operación en el momento de
     *                     darse la incidencia. (Valores posibles: Constantes de la Clase ENTIDAD_[])
     *
     * @param PEntidadId Identificador de la Entidad en la cual se ha dado la incidencia.
     *
     * @param PMensaje Mensaje detallando la incidencia que se ha dado en la operación.
     *
     * @return Sí se ha realizado correctamente la Operación.
     */
    public boolean Registrar(int PTipoIncidencia, Long POperacion, Long PTipoEntidad, Long PEntidadId,String PMensaje){
        boolean VDevolucion=false;
        LogData VLog;

        try{
            VLog=this.crearLineaLog(POperacion,PTipoEntidad,PEntidadId,PMensaje);
            switch (PTipoIncidencia){
                case TIPO_SEGURIDAD:
                case TIPO_SEC_ADMINISTRACION:
                    VDevolucion=(this.secLogAdministracionService.save((SecLogAdministracion)VLog)!=null);
                    break;
                case TIPO_SEC_SORTEOS:
                    VDevolucion=(this.secLogSorteosService.save((SecLogSorteos) VLog)!=null);
                    break;
                case TIPO_SEC_VENTAS:
                    VDevolucion=(this.secLogVentasService.save((SecLogVentas) VLog)!=null);
                    break;
                case TIPO_ADMINISTRACION:
                    VDevolucion=(this.logAdministracionService.save((LogAdministracion)VLog)!=null);
                    break;
                case TIPO_SORTEOS:
                    VDevolucion=(this.logSorteosService.save((LogSorteos) VLog)!=null);
                    break;
                case TIPO_VENTAS:
                    VDevolucion=(this.logVentasService.save((LogVentas)VLog)!=null);
                    break;
            }

        }catch (Exception ex){
            VDevolucion=false;
        }

        return VDevolucion;
    }

    /**
     * Crea una línea Log con los datos introducidos por parámetro.
     *
     * @param POperacion Tipología de Operación que se estaba realizando en el momento de darse la incidencia.
     *                   (Valores posibles: Constantes de la Clase OPERACION_[])
     *
     * @param PTipoEntidad Tipología de Tipo de Entidad que estaba realizando la operación en el momento de
     *                     darse la incidencia. (Valores posibles: Constantes de la Clase ENTIDAD_[])
     *
     * @param PEntidadId Identificador de la Entidad en la cual se ha dado la incidencia.
     *
     * @param PMensaje Mensaje detallando la incidencia que se ha dado en la operación.
     *
     * @return Objeto LogData con toda la información lista para ser almacenada en el lugar
     * adecuado.
     */
    public LogData crearLineaLog(Long POperacion, Long PTipoEntidad, Long PEntidadId, String PMensaje){
        LogData VDevolucion = new LogData();
        Optional<LogOperaciones> VOperacion;
        Optional<LogTipoEntidad> VTipoEntidad;

        try{
            VOperacion=this.logOperacionesService.findById(POperacion);
            VTipoEntidad=this.logTipoEntidadService.findById(PTipoEntidad);
            VDevolucion.setUsuario(this.usuarioActivo);
            VDevolucion.setOperacion(VOperacion.get());
            VDevolucion.setTipoEntidad(VTipoEntidad.get());
            VDevolucion.setEntidadId(PEntidadId);
            VDevolucion.setMensaje(PMensaje);
            VDevolucion.setFecha(LocalDateTime.now());
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Encapsulación">

    /**
     * Método que devuelve el Nombre del Usuario del Sistema
     *
     * @return  Fecha de Eliminación del Usuario
     */
    public String getUserName(){
        String VDevolucion;

        try{
            VDevolucion=this.usuarioActivo.getNombreUsuario();
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    /**
     * Método que devuelve Sí el usuario es o no Administrador del Sistema
     *
     * @return  Si o No Administrador
     */
    public boolean isAdministrator(){
        return this.usuarioActivo.getAdministrador();
    }

// </editor-fold>


}
