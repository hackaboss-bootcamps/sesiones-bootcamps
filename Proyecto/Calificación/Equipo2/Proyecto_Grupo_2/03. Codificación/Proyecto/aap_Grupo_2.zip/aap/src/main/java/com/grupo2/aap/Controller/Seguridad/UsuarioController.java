package com.grupo2.aap.Controller.Seguridad;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Component.SecuritySession;
import com.grupo2.aap.Entity.Seguridad.Usuario;
import com.grupo2.aap.Iservice.Seguridad.IUsuarioService;
import jdk.jfr.ValueDescriptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/usuario")
public class UsuarioController {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    @Autowired
    private IUsuarioService service;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos Controladores de Conexión">

    @GetMapping("/ID")
    public Optional<Usuario> show(@RequestParam Long id, HttpSession sesion) {
        Optional<Usuario> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findById(id);
        }else{
            VDevolucion=null;
        }
        return VDevolucion;
    }

    @GetMapping("/EM")
    public List<Usuario> findByEmployee(@RequestParam Long employeeId, HttpSession sesion) {
        List<Usuario> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findByEmployee(employeeId);
        }else{
            VDevolucion=null;
        }
        return VDevolucion;
    }

    @GetMapping("/NO")
    public List<Usuario> findByName(@RequestParam String nombre, HttpSession sesion) {
        List<Usuario> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findByName(nombre);
        }else{
            VDevolucion=null;
        }
        return VDevolucion;
    }

    @GetMapping("/RO")
    public List<Usuario> findByRol(@RequestParam Boolean administrador, HttpSession sesion) {
        List<Usuario> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findByRol(administrador);
        }else{
            VDevolucion=null;
        }
        return VDevolucion;
    }

    @PostMapping
    @ResponseStatus(code = HttpStatus.CREATED)
    public Usuario save(@RequestBody Usuario cliente, HttpSession sesion) {
        Usuario VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.save(cliente);
        }else{
            VDevolucion=null;
        }
        return VDevolucion;
    }

    @PutMapping()
    @ResponseStatus(code = HttpStatus.ACCEPTED)
    public Usuario update(@RequestParam Long id,
                          @RequestBody Usuario cliente,
                          HttpSession sesion) {

        Usuario VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.update(id, cliente);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @DeleteMapping()
    @ResponseStatus(code = HttpStatus.ACCEPTED)
    public boolean delete(@RequestParam Long id, HttpSession sesion) {
        boolean VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion= service.delete(id);
        }else{
            VDevolucion = false;
        }

        return VDevolucion;
    }
// </editor-fold>

}
