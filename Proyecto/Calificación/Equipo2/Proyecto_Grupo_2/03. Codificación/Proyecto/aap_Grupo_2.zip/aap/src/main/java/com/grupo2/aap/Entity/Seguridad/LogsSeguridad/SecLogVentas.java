package com.grupo2.aap.Entity.Seguridad.LogsSeguridad;

import com.grupo2.aap.Entity.Seguridad.Component.LogData;
import com.grupo2.aap.Entity.Seguridad.LogsOperaciones.LogAdministracion;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que implementa la entidad SecLogVentas, en la cual se van a almacenar todas los eventos
 * que se dan en el sistema en referencia a las Ventas y que puedan provocar problemas
 * de seguridad.
 *
 * */
@Entity
@Table (name = "sec_log_ventas")
public class SecLogVentas extends LogData {

    /**
     * Método que Clona la información de otra entidad SecLogVentas en sí misma
     *
     * @param PLogClonar SecLogVentas cuyos parámetros se desean clonar
     * @return Sí se ha realizado correctamente o no la operación.
     */
    public boolean clone(SecLogVentas PLogClonar){
        boolean VDevolucion;

        try{
            this.setOperacion(PLogClonar.getOperacion());
            this.setTipoEntidad(PLogClonar.getTipoEntidad());
            this.setEntidadId(PLogClonar.getEntidadId());
            this.setFecha(PLogClonar.getFecha());
            this.setUsuario(PLogClonar.getUsuario());
            this.setMensaje(PLogClonar.getMensaje());

            VDevolucion = true;
        }catch (Exception ex){
            VDevolucion = false;
        }

        return VDevolucion;
    }

}
