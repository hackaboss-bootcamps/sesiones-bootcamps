package com.grupo2.aap.IRepository.Seguridad.LogsOperaciones;

import com.grupo2.aap.Entity.Seguridad.LogsOperaciones.LogSorteos;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que permite la ejecución de las cláusulas SQL necesarias para servir de repositorio de
 * la entidad LogSorteos
 *
 * */
@Repository
public interface ILogSorteosRepository extends JpaRepository<LogSorteos,Long> {

    /**
     * Método que encuentra la lista de clientes cuyo DNI es el que se introduce
     * por parámetro.
     *
     * @param POperacion Operacion de log_sorteos sobre la que se realizará la consulta.
     * @return Lista de log_sorteos cuya operacion coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM log_sorteos " +
            "WHERE operacion = :operacion", nativeQuery = true)
    List<LogSorteos> findListByOperation(@Param("operacion") Long POperacion);

    /**
     * Método que encuentra la lista de log_sorteos cuyo tipo_entidad es el que se introduce
     * por parámetro.
     *
     * @param PTipoEntidad Operacion de log_sorteos sobre la que se realizará la consulta.
     * @return Lista de log_sorteos cuyo tipo_entidad coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM log_sorteos " +
            "WHERE tipo_entidad = :tipoEntidad", nativeQuery = true)
    List<LogSorteos> findListByTypeOfEntity(@Param("tipoEntidad") Long PTipoEntidad);

    /**
     * Método que encuentra la lista de log_sorteos cuya entidad es el que se introduce
     * por parámetro.
     *
     * @param PEntidad Entidad de log_sorteos sobre la que se realizará la consulta.
     * @return Lista de log_sorteos cuyo entidad coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM log_sorteos " +
            "WHERE entidad = :entidad", nativeQuery = true)
    List<LogSorteos> findListByEntity(@Param("entidad") Long PEntidad);

    /**
     * Método que encuentra la lista de log_sorteos cuyas fechas de inicio y fechas finales son las que se introduce
     * por parámetro.
     *
     * @param PFechaInicio Fecha de inicio de log_sorteos sobre la que se realizará la consulta.
     * @param PFechaFin Fecha final de log_sorteos sobre la que se realizará la consulta.
     * @return Lista de log_sorteos cuyas fechas de inicio y fechas finales coinciden con los parámetros de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM log_sorteos " +
            "WHERE fecha BETWEEN fechaInicio AND fechaFin", nativeQuery = true)
    List<LogSorteos> findByDate(@Param("fechaInicio") LocalDateTime PFechaInicio, @Param("fechaFin") LocalDateTime PFechaFin);

    /**
     * Método que encuentra la lista de log_sorteos cuyo usuario es el que se introduce
     * por parámetro.
     *
     * @param PUsuario Usuario de log_sorteos sobre el que se realizará la consulta.
     * @return Lista de log_sorteos cuyo usuario coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM log_sorteos " +
            "WHERE usuario = :usuario", nativeQuery = true)
    List<LogSorteos> findListByUser(@Param("usuario") Long PUsuario);

    /**
     * Método que encuentra la lista de log_sorteos cuyo mensaje es el que se introduce
     * por parámetro.
     *
     * @param PMensaje Mensaje de log_sorteos sobre el que se realizará la consulta.
     * @return Lista de log_sorteos cuyo mensaje coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM log_sorteos " +
            "WHERE mensaje LIKE %:mensaje%", nativeQuery = true)
    List<LogSorteos> findListByMessage(@Param("mensaje") String PMensaje);


}
