package com.grupo2.aap.IRepository.Ventas;

import com.grupo2.aap.Entity.Ventas.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que permite la ejecución de las cláusulas SQL necesarias para servir de repositorio de
 * la entidad Cliente
 *
 * */

@Repository
public interface IClienteRepository extends JpaRepository<Cliente,Long> {

    /**
     * Método que encuentra la lista de clientes cuyo DNI es el que se introduce
     * por parámetro.
     *
     * @param PDni DNi del cliente sobre el que se realizará la consulta.
     * @return Lista de Clientes cuyo DNI coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM clientes " +
            "WHERE dni = :dni " +
            "AND fecha_eliminacion IS NULL", nativeQuery = true)
    List<Cliente> findListByDni(@Param("dni") String PDni);


    /**
     * Método que encuentra la lista de clientes cuyo Atributo nombre contenga
     * el nombre o cadena de caracteres que se introduce por parámetro.
     *
     * @param PNombre Nombre del cliente sobre el que se realizará la consulta.
     * @return Lista de Clientes cuyo Nombre contenga con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM clientes " +
            "WHERE nombre LIKE %:nombre% " +
            "OR apellido1 LIKE %:nombre% " +
            "OR apellido2 LIKE %:nombre% " +
            "AND fecha_eliminacion IS NULL", nativeQuery = true)
    List<Cliente> findListByName(@Param("nombre") String PNombre);


    /**
     * Método que encuentra la lista de clientes cuyo Atributo dirección contenga
     * la dirección o cadena de caracteres que se introduce por parámetro.
     *
     * @param PDireccion Dirección del cliente sobre el que se realizará la consulta.
     * @return Lista de Clientes cuya Dirección contenga con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM clientes " +
            "WHERE direccion LIKE %:direccion% " +
            "AND fecha_eliminacion IS NULL ", nativeQuery = true)
    List<Cliente> findListByAddress(@Param("direccion") String PDireccion);


    /**
     * Método que encuentra la lista de clientes cuyo Atributo provincia contenga
     * la provincia o cadena de caracteres que se introduce por parámetro.
     *
     * @param PProvincia Provincia del cliente sobre el que se realizará la consulta.
     * @return Lista de Clientes cuya provincia contenga con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM clientes " +
            "WHERE provincia LIKE %:provincia% " +
            "AND fecha_eliminacion IS NULL", nativeQuery = true)
    List<Cliente> findListByProvince(@Param("provincia") String PProvincia);


    /**
     * Método que encuentra la lista de clientes cuyo Atributo poblacion contenga
     * la Poblacion o cadena de caracteres que se introduce por parámetro.
     *
     * @param PPoblacion Poblacion del cliente sobre el que se realizará la consulta.
     * @return Lista de Clientes cuya poblacion contenga con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM clientes " +
            "WHERE poblacion LIKE %:poblacion% " +
            "AND fecha_eliminacion IS NULL", nativeQuery = true)
    List<Cliente> findListByTown(@Param("poblacion") String PPoblacion);


    /**
     * Método que encuentra la lista de clientes cuyo Atributo Codigo Postal contenga
     * el Codigo Postal o cadena de caracteres que se introduce por parámetro.
     *
     * @param PCodPostal Codigo Postal del cliente sobre el que se realizará la consulta.
     * @return Lista de Clientes cuyo Codigo Postal contenga con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM clientes " +
            "WHERE cod_postal LIKE %:codPostal% " +
            "AND fecha_eliminacion IS NULL", nativeQuery = true)
    List<Cliente> findListByPostalCode(@Param("codPostal") String PCodPostal);


    /**
     * Método que encuentra la lista de clientes cuyo Atributo email contenga
     * el email o cadena de caracteres que se introduce por parámetro.
     *
     * @param PEmail EMail del cliente sobre el que se realizará la consulta.
     * @return Lista de Clientes cuyo EMail contenga con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM clientes " +
            "WHERE email LIKE %:email% " +
            "AND fecha_eliminacion IS NULL", nativeQuery = true)
    List<Cliente> findListByEmail(@Param("email") String PEmail);



}
