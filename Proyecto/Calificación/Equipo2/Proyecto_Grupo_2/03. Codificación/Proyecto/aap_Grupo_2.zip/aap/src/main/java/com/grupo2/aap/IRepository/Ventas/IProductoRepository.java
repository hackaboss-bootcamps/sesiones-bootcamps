package com.grupo2.aap.IRepository.Ventas;

import com.grupo2.aap.Entity.Ventas.Factura;
import com.grupo2.aap.Entity.Ventas.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que permite la ejecución de las cláusulas SQL necesarias para servir de repositorio de
 * la entidad Producto.
 *
 * */
@Repository
public interface IProductoRepository extends JpaRepository<Producto,Long> {

    /**
     * Método que encuentra la lista de Productos cuyo Atributo Codigo Barras contenga
     * el Código de Barras o cadena de caracteres que se introduce por parámetro.
     *
     * @param PCodBarras Codigo de Barras del producto sobre el que se realizará la consulta.
     * @return Lista de Producto cuyo Codigo de Barras contenga con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM productos " +
            "WHERE cod_barras LIKE %:codBarras% " +
                "AND fecha_eliminacion IS NULL", nativeQuery = true)
    List<Producto> findListByCodBarras(@Param("codBarras") String PCodBarras);

    /**
     * Método que encuentra la lista de Productos cuyo Atributo Nombre contenga
     * el nombre o cadena de caracteres que se introduce por parámetro.
     *
     * @param PNombre Nombre del producto sobre el que se realizará la consulta.
     * @return Lista de Producto cuyo Nombre contenga con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM productos " +
            "WHERE nombre LIKE %:nombre% " +
                    "AND fecha_eliminacion IS NULL", nativeQuery = true)
    List<Producto> findListByName(@Param("nombre") String PNombre);

    /**
     * Método que encuentra la lista de Productos cuyo Atributo Cantidad es el que se introduce
     * por parámetro.
     *
     * @param cantidadInicio Cantidad Inicial sobre la que se realizará la consulta
     * @param cantidadFin Cantidad Final sobre la que se realizará la consulta
     * @return Lista de Producto cuya CantidadInicio y CantidadFin coincide con los parámetros de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM productos " +
            "WHERE (cantidad BETWEEN :cantidadInicio AND :cantidadFin) " +
                    "AND fecha_eliminacion IS NULL", nativeQuery = true)
    List<Producto> findListByAmount(@Param("cantidadInicio") Integer cantidadInicio,
                                    @Param("cantidadFin") Integer cantidadFin);

    /**
     * Método que encuentra la lista de Productos cuyo Atributo Precio es el que se introduce
     * por parámetro.
     *
     * @param precioInicio  sobre la que se realizará la consulta
     * @param precioFin Final sobre la que se realizará la consulta
     * @return Lista de Producto cuyo PrecioInicio y PrecioFinb coincide con los parámetros de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM productos " +
            "WHERE (precio_unitario BETWEEN :precioInicio AND :precioFin) " +
                    "AND fecha_eliminacion IS NULL", nativeQuery = true)
    List<Producto> findListByPrice(@Param("precioInicio") Double precioInicio,
                                   @Param("precioFin") Double precioFin);

    /**
     * Método que encuentra la lista de Productos cuyo Atributo Iva es el que se introduce
     *      * por parámetro.
     *
     * @param ivaInicio  sobre la que se realizará la consulta
     * @param ivaFin Final sobre la que se realizará la consulta
     * @return Lista de Producto cuyo IvaInicio e IvaFin coincide con los parámetros de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM productos " +
            "WHERE (iva BETWEEN :ivaInicio AND :ivaFin) " +
                    "AND fecha_eliminacion IS NULL", nativeQuery = true)
    List<Producto> findListByIva(@Param("ivaInicio") Integer ivaInicio,
                                   @Param("ivaFin") Integer ivaFin);

    /**
     * Método que encuentra la lista de Productos cuyo Atributo Observaciones contenga
     * las Observaciones o cadena de caracteres que se introduce por parámetro.
     *
     * @param PObservaciones Observaciones sobre la que se realizará la consulta.
     * @return Lista de Producto  cuyas Observaciones contenga con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM productos " +
            "WHERE observaciones LIKE %:observaciones%", nativeQuery = true)
    List<Producto> findListByRemarks(@Param("observaciones") String PObservaciones);

    /**
     * Método que encuentra la lista de Productos cuyo Atributo Familia Producto es el que se introduce por parámetro.
     *
     * @param familiaProducto  Familia de Producto sobre el que se realizará la consulta.
     * @return Lista de Producto cuya Familia Producto coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM productos " +
            "WHERE familia_producto = :familiaProducto " +
                    "AND fecha_eliminacion IS NULL", nativeQuery = true)
    List<Producto> findListByFamily(@Param("familiaProducto") Long familiaProducto);


}
