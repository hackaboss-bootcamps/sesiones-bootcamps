package com.grupo2.aap.Iservice.Seguridad.LogsOperaciones;


import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Seguridad.LogsOperaciones.LogAdministracion;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que será de obligada implementación por parte del servicio asociado.
 *
 * */
public interface ILogAdministracionService {


    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    void setSecurityCtrl(SecurityCtrl securityCtrl);

    /**
     * Método que devuelve todos los log de administracion de la Base de Datos
     *
     * @return Lista de Logs de la Capa de Persistencia
     */
    List<LogAdministracion> all();

    /**
     * Método que devuelve los log de administracion cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador del log de administracion del que se quiere obtener la información
     * @return Log de administracion que cumple con los requisitos de búsqueda.
     */
    Optional<LogAdministracion> findById(Long PId);

    /**
     * Método que encuentra la lista de log de administracion cuya operacion es la que se introduce
     * por parámetro.
     *
     * @param POperacion Operacion del log de administracion sobre el que se realizará la consulta.
     * @return Lista de log de administracion cuya operacion coincide con el parámetro de entrada.
     */
    List<LogAdministracion> findListByOperation(Long POperacion);

    /**
     * Método que encuentra la lista de log de administracion cuyo tipo de entidad es el que se introduce
     * por parámetro.
     *
     * @param PTipoEntidad Tipo de entidad del log de administracion sobre el que se realizará la consulta.
     * @return Lista de log de administracion cuyo tipo de entidad coincide con el parámetro de entrada.
     */
    List<LogAdministracion> findListByTypeOfEntity(Long PTipoEntidad);

    /**
     * Método que encuentra la lista de log de administracion cuya entidad es la que se introduce
     * por parámetro.
     *
     * @param PEntidad Entidad del log de administracion sobre la que se realizará la consulta.
     * @return Lista de log administracion cuya entidad coincide con el parámetro de entrada.
     */
    List<LogAdministracion> findListByEntity(Long PEntidad);

    /**
     * Método que encuentra la lista de log de administracion cuya fecha inicial y fecha final son las que se introducen
     * por parámetro.
     * @param PFechaInicio Fecha inicial del log de administracion sobre la que se realizará la consulta.
     * @param PFechaFin Fecha final del log de administracion sobre la que se realizará la consulta.
     * @return Lista de log de administracion cuyas fechas iniciales y fechas finales coincide con el parámetro de entrada.
     */
    List<LogAdministracion> findByDate(LocalDateTime PFechaInicio, LocalDateTime PFechaFin);

    /**
     * Método que encuentra la lista de log administracion cuyo usuario es el que se introduce
     * por parámetro.
     *
     * @param PUsuario Usuario del log de administracion sobre el que se realizará la consulta.
     * @return Lista de log de administracion cuyo usuario coincide con el parámetro de entrada.
     */
    List<LogAdministracion> findListByUser(Long PUsuario);

    /**
     * Método que encuentra la lista de log de administracion cuyo mensaje es el que se introduce
     * por parámetro.
     *
     * @param PMensaje Mensaje del log de administracion sobre el que se realizará la consulta.
     * @return Lista de log de administracion cuyo mensaje coincide con el parámetro de entrada.
     */
    List<LogAdministracion> findListByMessage(String PMensaje);

    /**
     * Método que Guarda la información del log de administracion que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PLogAdministracion Entidad del log de administracion que se desea almacenar.
     * @return Log de administracion con los datos que han sido guardados en la Base de Datos
     */
    LogAdministracion save(LogAdministracion PLogAdministracion);

}
