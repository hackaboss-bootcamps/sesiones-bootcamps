package com.grupo2.aap.Controller.Ventas;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Component.SecuritySession;
import com.grupo2.aap.Entity.Ventas.Cliente;
import com.grupo2.aap.Entity.Ventas.FamiliaProducto;
import com.grupo2.aap.Entity.Ventas.Producto;
import com.grupo2.aap.Iservice.Ventas.IFamiliaProductoService;
import com.grupo2.aap.Iservice.Ventas.IProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/fproducto")
public class FamiliaProductoController {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    @Autowired
    private IFamiliaProductoService service;


// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos Controladores de Conexión">


    @GetMapping("/ID")
    public Optional<FamiliaProducto> show(@RequestParam Long id) {
        return service.findById(id);
    }

    @GetMapping("/NO")
    public List<FamiliaProducto> findByName(@RequestParam String nombre) {
        return service.findListByName(nombre);
    }

    @GetMapping("/FA")
    public List<FamiliaProducto> findByFamily(@RequestParam Long familiaProducto) {
        return service.findListByFamily(familiaProducto);
    }

    @PostMapping
    @ResponseStatus(code = HttpStatus.CREATED)
    public FamiliaProducto save(@RequestBody FamiliaProducto familiaProducto, HttpSession sesion) {
        FamiliaProducto VDevolucion;
        SecurityCtrl VSecurityCtrl;

        try{
            VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
            if (VSecurityCtrl!=null){
                service.setSecurityCtrl(VSecurityCtrl);
                VDevolucion=service.save(familiaProducto);
            }else{
                VDevolucion=null;
            }
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @PutMapping()
    @ResponseStatus(code = HttpStatus.ACCEPTED)
    public FamiliaProducto update(@RequestParam Long id,
                                  @RequestBody FamiliaProducto familiaProducto,
                                  HttpSession sesion) {

        FamiliaProducto VDevolucion;
        SecurityCtrl VSecurityCtrl;

        try{
            VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
            if (VSecurityCtrl!=null){
                service.setSecurityCtrl(VSecurityCtrl);
                VDevolucion=service.update(id, familiaProducto);
            }else{
                VDevolucion = null;
            }
        }catch (Exception ex){
            VDevolucion = null;
        }

        return VDevolucion;
    }

    @DeleteMapping()
    @ResponseStatus(code = HttpStatus.ACCEPTED)
    public boolean delete(@RequestParam Long id, HttpSession sesion) {
        boolean VDevolucion;
        SecurityCtrl VSecurityCtrl;

        try{
            VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
            if (VSecurityCtrl!=null){
                service.setSecurityCtrl(VSecurityCtrl);

                VDevolucion=service.delete(id);
            }else{
                VDevolucion=false;
            }
        }catch (Exception ex){
            VDevolucion=false;
        }

        return VDevolucion;
    }
// </editor-fold>

}
