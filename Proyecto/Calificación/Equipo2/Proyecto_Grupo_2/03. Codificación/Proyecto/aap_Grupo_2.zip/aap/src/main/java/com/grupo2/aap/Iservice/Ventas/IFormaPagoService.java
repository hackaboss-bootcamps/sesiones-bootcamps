package com.grupo2.aap.Iservice.Ventas;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Ventas.FormaPago;

import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que será de obligada implementación por parte del servicio asociado.
 *
 * */
public interface IFormaPagoService {

    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    void setSecurityCtrl(SecurityCtrl securityCtrl);

    /**
     * Método que devuelve todas las Formas de Pago de la Base de Datos
     *
     * @return Lista de Forma de Pago de la Base de Datos
     */
    List<FormaPago> all();

    /**
     * Método que devuelve la forma pago cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador de la forma pago de la que se quiere obtener la información
     * @return Forma Pago que cumple con los requisitos de búsqueda.
     */
    Optional<FormaPago> findById(Long PId);

    /**
     * Método que encuentra la lista Formas de  Pago cuyo Atributo FormaPago contenga
     * el Nombre o cadena de caracteres que se introduce por parámetro.
     *
     * @param PNombre FormaPago de la familia de Formas de Pago sobre el que se realizará la consulta.
     * @return Lista de Forma Pago cuyo nombre contenga con el parámetro de entrada.
     */
    List<FormaPago> findByName(String PNombre);

    /**
     * Método que encuentra la lista Formas de  Pago cuyo Atributo FormaPago contenga
     * el Nombre  o cadena de caracteres que se introduce por parámetro.
     *
     * @param PFormaPago FormaPago de la familia de Formas de Pago sobre el que se realizará la consulta.
     * @return Lista de Forma Pago cuyo nombre contenga con el parámetro de entrada.
     */
    List<FormaPago> findListByName(String PFormaPago);

    /**
     * Método que Guarda la información de la Forma Pago que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PFormaPago Entidad FormaPago que se desea almacenar.
     * @return Forma Pago con los datos que han sido guardados en la Base de Datos
     */
    FormaPago save(FormaPago PFormaPago);

    /**
     * Método que Guarda los cambios de la información de la FormaPago e que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador de la Entidad FormaPago que se desea Actualizar.
     * @param PFormaPago Entidad FormaPago que se desea Actualizar.
     */
    void update(Long PId, FormaPago PFormaPago);

    /**
     * Método que elimina la Forma Pago que se introduce por parámetro de la Base de Datos
     *
     * @param PId Identificador de la Forma Pago  que se desea Eliminar.
     */
    void delete(Long PId);


}
