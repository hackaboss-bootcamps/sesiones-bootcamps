package com.grupo2.aap.Service.Ventas;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Ventas.Cliente;
import com.grupo2.aap.Entity.Ventas.Factura;
import com.grupo2.aap.Entity.Ventas.Producto;
import com.grupo2.aap.IRepository.Ventas.IProductoRepository;
import com.grupo2.aap.Iservice.Ventas.IProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.swing.text.html.Option;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que contiene el Servicio de sobre el Repositorio de Productos
 *
 * */
@Service
public class ProductoService implements IProductoService {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    @Autowired
    private IProductoRepository repository;

    /** Sistema de Control de la Seguridad que controlará los accesos por parte de los usuarios y
     * las actividades realizadas por los mismos */
    private SecurityCtrl securityCtrl;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Encapsulamiento">

    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    @Override
    public void setSecurityCtrl(SecurityCtrl securityCtrl) {
        this.securityCtrl = securityCtrl;
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Consultas">

    /**
     * Método que devuelve los productos cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador del producto de la que se quiere obtener la información
     * @return Producto que cumple con los requisitos de búsqueda.
     */
    @Override
    public Optional<Producto> findById(Long PId) {
        return repository.findById(PId);
    }

    /**
     * Método que encuentra la lista de Productos cuyo Atributo Codigo Barras contenga
     * el Código de Barras o cadena de caracteres que se introduce por parámetro.
     *
     * @param PCodBarras Codigo de Barras del producto sobre el que se realizará la consulta.
     * @return Lista de Producto cuyo Codigo de Barras contenga con el parámetro de entrada.
     */
    @Override
    public List<Producto> findByCodBarras(String PCodBarras) {
        return this.repository.findListByCodBarras(PCodBarras);
    }

    /**
     * Método que encuentra la lista de Productos cuyo Atributo Nombre contenga
     * el nombre o cadena de caracteres que se introduce por parámetro.
     *
     * @param PNombre Nombre del producto sobre el que se realizará la consulta.
     * @return Lista de Producto cuyo Nombre contenga con el parámetro de entrada.
     */
    @Override
    public List<Producto> findByName(String PNombre) {
        return this.repository.findListByName(PNombre);
    }

    /**
     * Método que encuentra la lista de Productos cuyo Atributo Cantidad es el que se introduce
     * por parámetro.
     *
     * @param cantidadInicio Cantidad Inicial sobre la que se realizará la consulta
     * @param cantidadFin Cantidad Final sobre la que se realizará la consulta
     * @return Lista de Producto cuya CantidadInicio y CantidadFin coincide con los parámetros de entrada.
     */
    @Override
    public List<Producto> findByAmount(Integer cantidadInicio, Integer cantidadFin) {
        List<Producto> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByAmount(cantidadInicio,cantidadFin);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de Productos cuyo Atributo Precio es el que se introduce
     * por parámetro.
     *
     * @param precioInicio  sobre la que se realizará la consulta
     * @param precioFin Final sobre la que se realizará la consulta
     * @return Lista de Producto cuyo PrecioInicio y PrecioFinb coincide con los parámetros de entrada.
     */
    @Override
    public List<Producto> findByPrice(Double precioInicio, Double precioFin) {
        List<Producto> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByPrice(precioInicio,precioFin);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de Productos cuyo Atributo Iva es el que se introduce
     *      * por parámetro.
     *
     * @param ivaInicio  sobre la que se realizará la consulta
     * @param ivaFin Final sobre la que se realizará la consulta
     * @return Lista de Producto cuyo IvaInicio e IvaFin coincide con los parámetros de entrada.
     */
    @Override
    public List<Producto> findByIva(Integer ivaInicio, Integer ivaFin) {
        List<Producto> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByIva(ivaInicio,ivaFin);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de Productos cuyo Atributo Observaciones contenga
     * las Observaciones o cadena de caracteres que se introduce por parámetro.
     *
     * @param PObservaciones Observaciones sobre la que se realizará la consulta.
     * @return Lista de Producto  cuyas Observaciones contenga con el parámetro de entrada.
     */
    @Override
    public List<Producto> findByRemarks(String PObservaciones) {
        List<Producto> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByRemarks(PObservaciones);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de Productos cuyo Atributo Familia Producto es el que se introduce por parámetro.
     *
     * @param familiaProducto  Familia de Producto sobre el que se realizará la consulta.
     * @return Lista de Producto cuya Familia Producto coincide con el parámetro de entrada.
     */
    @Override
    public List<Producto> findByFamily(Long familiaProducto) {
        return this.repository.findListByFamily(familiaProducto);
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de Datos">

    /**
     * Método que Guarda la información del Producto que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PProducto Entidad Producto que se desea almacenar.
     * @return Producto con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public Producto save(Producto PProducto) {
        return repository.save(PProducto);
    }

    /**
     * Método que Guarda los cambios de la información del Producto e que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador de la Entidad Producto que se desea Actualizar.
     * @param PProducto Entidad Producto  que se desea Actualizar.
     * @return Producto con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public Producto update(Long PId, Producto PProducto) {
        Producto VDevolucion;
        Optional<Producto> VProducto;

        try{
            VProducto = repository.findById(PId);

            if(!VProducto.isEmpty()){
                PProducto.setId(VProducto.get().getId());

                VDevolucion = repository.save(PProducto);
            }else{
                VDevolucion =null;
            }
        }catch (Exception ex){
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que Actualiza la Cantidad de Uniddes del Producto cuyo Id se introduce por parámetro
     *
     * @param PId Identificador de la Entidad Producto que se desea Actualizar.
     * @param PUnidades Unidades que se le sumarán a la cantidad de existencias del producto
     * @return Producto que se ha actualizado
     */
    @Override
    public Producto updateStorage(Long PId,Integer PUnidades) {
        Producto VDevolucion;
        Optional<Producto> VProducto;

        try{
            VProducto = repository.findById(PId);

            if(!VProducto.isEmpty()){
                VDevolucion=VProducto.get();
                VDevolucion.setCantidad(VDevolucion.getCantidad()-PUnidades);

                VDevolucion=repository.save(VDevolucion);

            }else{
                VDevolucion=null;
            }

        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    /**
     * Método que elimina el Producto que se introduce por parámetro de la Base de Datos
     *
     * @param PId Identificador del Producto  que se desea Eliminar.
     */
    @Override
    public boolean delete(Long PId) {
        boolean VDevolucion;
        Optional<Producto> VProducto;

        if (this.securityCtrl.isAdministrator()){
            VProducto = this.findById(PId);

            if (!VProducto.isEmpty()){
                VProducto.get().setFechaEliminacion(LocalDateTime.now());
                VDevolucion = (this.save(VProducto.get())!=null);
            }else{
                VDevolucion=false;
            }
        }else{
            VDevolucion=false;
        }

        return VDevolucion;
    }

// </editor-fold>

}
