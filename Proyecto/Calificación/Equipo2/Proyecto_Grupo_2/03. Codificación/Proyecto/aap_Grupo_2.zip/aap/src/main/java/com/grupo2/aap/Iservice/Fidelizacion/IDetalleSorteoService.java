package com.grupo2.aap.Iservice.Fidelizacion;


import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Fidelizacion.DetalleSorteo;

import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que será de obligada implementación por parte del servicio asociado.
 *
 * */
public interface IDetalleSorteoService {

// <editor-fold defaultstate="collapsed" desc="Métodos para el Control de la Seguridad">
    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    void setSecurityCtrl(SecurityCtrl securityCtrl);

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Consultas">

    /**
     * Método que devuelve todos los Detalles de Sorteos de la Base de Datos
     *
     * @return Lista de Detalles de Sorteos de la Base de Datos
     */
    List<DetalleSorteo> all();

    /**
     * Método que devuelve el Detalle de Sorteo cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador del Detalle de Sorteo del que se quiere obtener la información
     * @return Detalle de Sorteo que cumple con los requisitos de búsqueda.
     */
    Optional<DetalleSorteo> findById(Long PId);

    /**
     * Método que devuelve el Detalle de Sorteo que contiene el producto que se ha introducido
     * por parámetro
     *
     * @param PProducto Producto que filtrará los detalles del sorteo
     * @return Lista de detalles de los sorteos que continen el producot que se introduce por parámetro.
     */
    List<DetalleSorteo> findByProduct(Long PProducto);

    /**
     * Método que devuelve el Detalle de Sorteo que tiene un dto en el intervalo introducido por parámetro.
     *
     * @param PDtoInicio Dto que marca el inicio del intervalo en el que se quiere buscar
     * @param PDtoFin Dto que marca el fin del intervalo en el que se quiere buscar
     * @return Lista de detalles de los sorteos que están en el intervalo que se introduce por parámetro
     */
    List<DetalleSorteo> findByDto(Integer PDtoInicio, Integer PDtoFin);

    /**
     * Método que devuelve los detalles del sorteo que se introduce por parámetro
     *
     * @param PIdSorteo Sorteo sobre el que se quiere realizar la consulta de los detalles
     * @return Lista de detalles del sorteo consultado
     */
    List<DetalleSorteo> findBySorteo(Long PIdSorteo);

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de la Persistencia">

    /**
     * Método que Guarda la información del Detalle de Sorteo que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PDetalleSorteo Entidad Detalle de Sorteo que se desea almacenar.
     * @return Detalle de Sorteo con los datos que han sido guardados en la Base de Datos
     */
    DetalleSorteo save(DetalleSorteo PDetalleSorteo);

    /**
     * Método que Guarda los cambios de la información del Detalle del Sorteo que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador de la Entidad Detalle del Sorteo que se desea Actualizar.
     * @param PDetalleSorteo Entidad Detalle del Sorteo que se desea Actualizar.
     * @return Detalle del Sorteo con los datos que han sido guardados en la Base de Datos
     */
    DetalleSorteo update(Long PId, DetalleSorteo PDetalleSorteo);

    /**
     * Método que elimina el Detalle de Sorteo que se introduce por parámetro de la Base de Datos
     *
     * @param PId Identificador del Detalle de Sorteo que se desea Eliminar.
     * @return Sí se ha realizado o no correctamente la operacion
     */
    boolean delete(Long PId);

// </editor-fold>

}

