package com.grupo2.aap.Iservice.Fidelizacion;
import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Fidelizacion.Participacion;
import com.grupo2.aap.Entity.Fidelizacion.Sorteo;
import com.grupo2.aap.Entity.Ventas.Factura;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que será de obligada implementación por parte del servicio asociado.
 *
 * */
public interface IParticipacionService {

// <editor-fold defaultstate="collapsed" desc="Métodos para el Control de la Seguridad">

    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    void setSecurityCtrl(SecurityCtrl securityCtrl);

    /**
     * Método que devuelve todos los Sorteos de la Base de Datos
     *
     * @return Lista de Sorteos de la Base de Datos
     */
    List<Participacion> all();

    /**
     * Método que devuelve la Participación cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador de la Participación del que se quiere obtener la información
     * @return PArticipación que cumple con los requisitos de búsqueda.
     */
    Optional<Participacion> findById(Long PId);

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Consultas">

    /**
     * Método que encuentra la lista de Participaciones que tengan como número el
     * que se introduce par parámetro
     *
     * @param PNumero Número de la Participación sobre el que se realizará la consulta.
     * @return Lista de Participaciones con el número introducido
     */
    List<Participacion> findByNumber(Integer PNumero);

    /**
     * Método que encuentra la lista de Participaciones que se hayan aplicado a la factura que se
     * introduce por parámetro
     *
     * @param PIdFactura Identificador de la Factura sobre la que se aplicó la Participación
     * @return Lista de Participaciones que se han aplicado a la Factura introducida
     */
    List<Participacion> findByApplicationInvoice(Long PIdFactura);

    /**
     * Método que encuentra la lista de Participaciones que se hayan generadas por la factura introducida
     *
     * @param PIdFactura Identificador de la Factura que generó las participaciones
     * @return Lista de Participaciones que se han Generadas por la Factura introducida
     */
    List<Participacion> findByGenerationInvoice(Long PIdFactura);

    /**
     * Método que encuentra la lista de Participaciones que son válidas entre las fechas que se introducen
     * por parámetro
     *
     * @param PFechaInicio Fecha de Acotación inicial del intervalo de tiempo
     * @param PFechaFin Fecha de Acotación final del intervalo de tiempo
     * @return Lista de Participaciones que son válidas en el intervalo de tiempo introducido
     */
    List<Participacion> findByMaxValidityDate(LocalDateTime PFechaInicio,LocalDateTime PFechaFin);

    /**
     * Método que encuentra la lista de Participaciones que han sido candeladas entre las fechas que se introducen
     * por parámetro
     *
     * @param PFechaInicio Fecha de Acotación inicial del intervalo de tiempo
     * @param PFechaFin Fecha de Acotación final del intervalo de tiempo
     * @return Lista de Participaciones que han sido canceladas en el intervalo de tiempo introducido
     */
    List<Participacion> findByCancelDate(LocalDateTime PFechaInicio,LocalDateTime PFechaFin);

    /**
     * Método que encuentra la lista de Participaciones del Sorteo que se introduce por parámetro
     *
     * @param PSorteo Sorteo del que se quiere saber la lista de participaciones
     * @return Lista de Participaciones del sorteo introducido
     */
    List<Participacion> findByDraw(Long PSorteo);

    /**
     * Método que encuentra la lista de Participaciones ganadoras del sorteo introducido.
     *
     * @param PSorteo Sorteo del que se quiere saber la lista de participaciones ganadoras
     * @return Lista de Participaciones ganadoras del sorteo introducido
     */
    List<Participacion> findByWinnersDraw(Long PSorteo);


// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de la Persistencia">

    /**
     * Método que Marca como premiada la participación que se introduce por parámetro
     *
     * @param PParticipacion Participación que va a ser marcada como ganadora
     * @param PFechaMaxValidez Fecha máxima en la que se puede hacer efectiva la participación
     * @return Si se ha realizado correctamente la operación o no
     */
    boolean premiar(Participacion PParticipacion, LocalDate PFechaMaxValidez);

    /**
     * Método que genera una participación del sorteo que se introduce por parámetro y que relaciona
     * con la factura introducida
     *
     * @param PSorteo Sorteo al que debe pertenecer la Participación
     * @param PFacturaGeneracion Factura por la cual se ha generado la participacióny a la cual queda viculada
     * @return PArticipación válida para el sorteo introducido
     */
    Participacion generar(Sorteo PSorteo, Factura PFacturaGeneracion);

    /**
     * Método que Guarda la información de la participación que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PParticipacion Participación que se desea guardar
     * @return Participacion con los datos que han sido guardados en la Base de Datos
     */
    Participacion save(Participacion PParticipacion);

    /**
     * Método que Guarda los cambios de la información de la Participación que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador de la Entidad Participación que se desea Actualizar.
     * @param PParticipacion Entidad Participación que se desea Actualizar.
     * @return Sorteo con los datos que han sido guardados en la Base de Datos
     */
    Participacion update(Long PId, Participacion PParticipacion);

    /**
     * Método que cancela la participación que se introduce por parámetro de la Base de Datos
     *
     * @param PId Identificador de la participación que se desea cancelar.
     * @return Sí se ha realizado o no correctamente la operacion
     */

    boolean delete(Long PId);

// </editor-fold>

}
