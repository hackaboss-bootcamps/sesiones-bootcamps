package com.grupo2.aap.Entity.Ventas;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que implementa la Entidad de Producto. Esta clase contendrá la información básica y las operaciones
 * Básicas con dicha información.
 *
 * */
@Entity
@Table (name = "productos")
public class Producto {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Id del Producto */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Código de Barras del Producto */
    @Column (name = "cod_barras",nullable = false,unique = true,length = 20)
    private String codBarras;

    /** Nombre del Producto */
    @Column (name = "nombre",nullable = false,unique = true,length = 150)
    private String nombre;

    /** Familia del Producto */
    @ManyToOne(fetch = FetchType.EAGER, optional = true)
    @JoinColumn(name = "familia_producto", nullable = true)
    private FamiliaProducto familiaProducto;

    /** Precio Unitario del Producto */
    @Column (name = "precio_unitario",nullable = false)
    private Double precioUnitario;

    /** Cantidad del Producto disponible en el almacén */
    @Column (name = "cantidad")
    private int cantidad = 0;

    /** IVA del Producto */
    @Column (name = "iva")
    private int iva = 21;

    /** Observaciones sobre el Producto */
    @Column (name = "observaciones")
    private String observaciones;

    /** FEcha de Eliminación del Producto */
    @Column (name = "fecha_eliminacion")
    private LocalDateTime fechaEliminacion;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Encapsulamiento">

    /**
     * Método que Devuelve el Id del Producto.
     *
     * @return Id del Producto.
     */
    public long getId() {
        return id;
    }

    /**
     * Método que Introduce el Id del Producto.
     *
     * @param id del Producto.
     *
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * Método que Devuelve el Código de Barras del Producto.
     *
     * @return Código de Barras del Producto.
     */
    public String getCodBarras() {
        return codBarras;
    }

    /**
     * Método que Introduce el Código de Barras del Producto.
     *
     * @param codBarras del Producto.
     *
     */
    public void setCodBarras(String codBarras) {
        this.codBarras = codBarras;
    }

    /**
     * Método que Devuelve el Nombre del Producto.
     *
     * @return Nombre del Producto.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Método que Introduce el Nombre del Producto.
     *
     * @param nombre del Producto.
     *
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Método que Devuelve la Familia del Producto.
     *
     * @return Familia del Producto.
     */
    public FamiliaProducto getFamiliaProducto() {
        return familiaProducto;
    }

    /**
     * Método que Introduce la Familia del Producto.
     *
     * @param familiaProducto del Producto.
     *
     */
    public void setFamiliaProducto(FamiliaProducto familiaProducto) {
        this.familiaProducto = familiaProducto;
    }

    /**
     * Método que Devuelve el Precio Unitario del Producto.
     *
     * @return Precio Unitario del Producto.
     */
    public Double getPrecioUnitario() {
        return precioUnitario;
    }

    /**
     * Método que Introduce el Precio Unitario del Producto.
     *
     * @param precioUnitario del Producto.
     *
     */
    public void setPrecioUnitario(Double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    /**
     * Método que Devuelve la Cantidad del Producto en el Almacén.
     *
     * @return Cantidad del Producto.
     */
    public int getCantidad() {
        return cantidad;
    }

    /**
     * Método que Introduce la Cantidad del Producto disponible en el Almacén.
     *
     * @param cantidad del Producto.
     *
     */
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    /**
     * Método que Devuelve el IVA del Producto.
     *
     * @return IVA del Producto.
     */
    public int getIva() {
        return iva;
    }

    /**
     * Método que Introduce el IVA del Producto.
     *
     * @param iva del Producto.
     *
     */
    public void setIva(int iva) {
        this.iva = iva;
    }

    /**
     * Método que Devuelve las Observaciones sobre el Producto.
     *
     * @return Observaciones del Producto.
     */
    public String getObservaciones() {
        return observaciones;
    }

    /**
     * Método que Introduce las Observaciones del Producto.
     *
     * @param observaciones del Producto.
     *
     */
    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    /**
     * Método que Devuelve la Fecha de Eliminación del Producto.
     *
     * @return Fecha de Eliminación del Producto.
     */
    public LocalDateTime getFechaEliminacion() {
        return fechaEliminacion;
    }

    /**
     * Método que Introduce la Fecha de Eliminación del Producto.
     *
     * @param fechaEliminacion del Producto.
     *
     */
    public void setFechaEliminacion(LocalDateTime fechaEliminacion) {
        this.fechaEliminacion = fechaEliminacion;
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de Datos">

    /**
     * Método que Clona la información de otra entidad producto en sí misma.
     *
     * @param PProductoClonar Producto cuyos parámetros se desean clonar.
     * @return Sí se ha realizado correctamente o no la operación.
     */
    public boolean clone(Producto PProductoClonar){
        boolean VDevolucion;

        try{
            this.setCantidad(PProductoClonar.getCantidad());
            this.setNombre(PProductoClonar.getNombre());
            this.setCodBarras(PProductoClonar.getCodBarras());
            this.setObservaciones(PProductoClonar.getObservaciones());
            this.setPrecioUnitario(PProductoClonar.getPrecioUnitario());
            this.setIva(PProductoClonar.getIva());
            this.setFamiliaProducto(PProductoClonar.getFamiliaProducto());
            this.setFechaEliminacion(PProductoClonar.getFechaEliminacion());

            VDevolucion = true;
        }catch (Exception ex){
            VDevolucion = false;
        }

        return VDevolucion;
    }

// </editor-fold>


}
