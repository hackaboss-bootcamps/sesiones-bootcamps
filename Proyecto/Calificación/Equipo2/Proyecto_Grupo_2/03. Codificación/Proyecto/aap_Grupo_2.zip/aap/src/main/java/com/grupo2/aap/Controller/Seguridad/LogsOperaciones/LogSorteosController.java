package com.grupo2.aap.Controller.Seguridad.LogsOperaciones;


import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Component.SecuritySession;
import com.grupo2.aap.Entity.Seguridad.LogsOperaciones.LogSorteos;
import com.grupo2.aap.Iservice.Seguridad.LogsOperaciones.ILogSorteosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/logsorteos")
public class LogSorteosController {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    @Autowired
    private ILogSorteosService service;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos Controladores de Conexión">

    @GetMapping("/ID")
    public Optional<LogSorteos> show(@RequestParam Long id, HttpSession sesion) {
        Optional<LogSorteos> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findById(id);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @GetMapping("/OP")
    public List<LogSorteos> findByOperation(@RequestParam Long operation, HttpSession sesion) {
        List<LogSorteos> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByOperation(operation);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }


    @GetMapping("/TE")
    public List<LogSorteos> findListByTypeOfEntity(@RequestParam Long tipoEntidad, HttpSession sesion) {
        List<LogSorteos> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByTypeOfEntity(tipoEntidad);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }


    @GetMapping("/EN")
    public List<LogSorteos> findListByEntity(@RequestParam Long entidad, HttpSession sesion) {
        List<LogSorteos> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByEntity(entidad);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }


    @GetMapping("/FE")
    public List<LogSorteos> findByDate(@RequestParam LocalDateTime fechaInicio,
                                              @RequestParam LocalDateTime fechaFin,
                                              HttpSession sesion) {
        List<LogSorteos> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findByDate(fechaInicio,fechaFin);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }


    @GetMapping("/US")
    public List<LogSorteos> findListByUser(@RequestParam Long usuario,
                                                  HttpSession sesion){
        List<LogSorteos> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByUser(usuario);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }


    @GetMapping("/ME")
    public List<LogSorteos> findListByMessage(@RequestParam String mensaje,
                                                     HttpSession sesion) {
        List<LogSorteos> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByMessage(mensaje);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

// </editor-fold>

}