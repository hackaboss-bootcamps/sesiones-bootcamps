package com.grupo2.aap.IRepository.Fidelizacion;

import com.grupo2.aap.Entity.Fidelizacion.DetalleSorteo;
import com.grupo2.aap.Entity.Fidelizacion.Sorteo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que permite la ejecución de las cláusulas SQL necesarias para servir de repositorio de
 * la entidad Sorteo.
 *
 * */
@Repository
public interface ISorteoRepository  extends JpaRepository<Sorteo,Long> {
    /**
     * Método que encuentra la lista de sorteo cuyo Atributo Nombre es el que se introduce
     * por parámetro.
     *
     * @param PNombre Nombre sobre el que se realizará la consulta.
     * @return Lista de Sorteo cuyo Nombre coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT * " +
            "FROM sorteos " +
            "WHERE nombre = :nombre " +
            "AND fecha_eliminacion IS NULL",nativeQuery = true)
    List<Sorteo> findByNombre(@Param("nombre") String PNombre);

    /**
     * Método que encuentra la lista de  sorteo  cuyo Atributo Fecha Creación es el que se introduce
     * por parámetro.
     *
     * @param PFechaInicio Fecha Inicial sobre la que se realizará la consulta.
     * @param PFechaFin Fecha Final sobre la que se realizará la consulta.
     * @return Lista de Sorteo cuya FechaInicio y FechaFin coincide con los parámetros de entrada.
     */
    @Query(value = "SELECT * " +
            "FROM sorteos " +
            "WHERE (fecha_creacion BETWEEN :fechaInicio AND :fechaFin) " +
            "AND fecha_eliminacion IS NULL",nativeQuery = true)
    List<Sorteo> findByCreationDate(@Param("fechaInicio") LocalDateTime PFechaInicio, @Param("fechaFin") LocalDateTime PFechaFin);

    /**
     * Método que encuentra la lista de sorteos cuyo Atributo Fecha Inicio es el que se introduce
     * por parámetro.
     *
     * @param PFechaInicio Fecha Inicial sobre la que se realizará la consulta.
     * @param PFechaFin Fecha Final sobre la que se realizará la consulta.
     * @return Lista de Sorteo cuya FechaInicio y FechaFin coincide con los parámetros de entrada.
     */
    @Query(value = "SELECT * " +
            "FROM sorteos " +
            "WHERE (fecha_inicio BETWEEN :fechaInicio AND :fechaFin) " +
            "AND fecha_eliminacion IS NULL",nativeQuery = true)
    List<Sorteo> findByStartDate(@Param("fechaInicio") LocalDateTime PFechaInicio, @Param("fechaFin") LocalDateTime PFechaFin);

    /**
     * Método que encuentra la lista de  sorteo  cuyo Atributo Fecha Fin es el que se introduce
     * por parámetro.
     *
     * @param PFechaInicio Fecha Inicial sobre la que se realizará la consulta.
     * @param PFechaFin Fecha Final sobre la que se realizará la consulta.
     * @return Lista de Sorteo cuya FechaInicio y FechaFin coincide con los parámetros de entrada.
     */
    @Query(value = "SELECT * " +
            "FROM sorteos " +
            "WHERE (fecha_fin BETWEEN :fechaInicio AND :fechaFin) " +
            "AND fecha_eliminacion IS NULL",nativeQuery = true)
    List<Sorteo> findByFinalizeDate(@Param("fechaInicio") LocalDateTime PFechaInicio, @Param("fechaFin") LocalDateTime PFechaFin);

    /**
     * Método que encuentra la lista de sorteo cuyo Atributo Descuento Tarjeta Regalo es el que se introduce
     * por parámetro.
     *
     * @param PDtoInicio Descuento Inicial sobre la que se realizará la consulta.
     * @param PDtoFin Descuento Final sobre la que se realizará la consulta.
     * @return Lista de Sorteo cuyo DtoInicio y DtoFin coincide con los parámetros de entrada.
     */
    @Query(value = "SELECT * " +
            "FROM sorteos " +
            "WHERE (descuento_tarjeta_regalo BETWEEN :dtoInicio AND :dtoFin) " +
            "AND fecha_eliminacion IS NULL",nativeQuery = true)
    List<Sorteo> findByDtoPresentCard(@Param("dtoInicio") Double PDtoInicio, @Param("dtoFin") Double PDtoFin);

    /**
     * Método que encuentra la lista de  sorteo  cuyo Atributo Porcentaje Descuento Factura es el que se introduce
     * por parámetro.
     *
     * @param PDtoInicio Descuento Inicial sobre la que se realizará la consulta.
     * @param PDtoFin Descuento Final sobre la que se realizará la consulta.
     * @return Lista de Sorteo cuyo DtoInicio y DtoFin coincide con los parámetros de entrada.
     */
    @Query(value = "SELECT * " +
            "FROM sorteos " +
            "WHERE (porcentaje_descuento_factura BETWEEN :dtoInicio AND :dtoFin) " +
            "AND fecha_eliminacion IS NULL",nativeQuery = true)
    List<Sorteo> findByDtoInvoice(@Param("dtoInicio") Integer PDtoInicio, @Param("dtoFin") Integer PDtoFin);

    /**
     * Método que encuentra la lista de  sorteo  cuyo Atributo Días Participación Válida es el que se introduce
     * por parámetro.
     *
     * @param PNumeroDiasInicio Número Días Inicio  sobre la que se realizará la consulta.
     * @param PNumeroDiasFin Número Días Fin  sobre la que se realizará la consulta.
     * @return Lista de Sorteo cuyo Dias Participación Válida coincide con los parámetros de entrada.
     */
    @Query(value = "SELECT * " +
            "FROM sorteos " +
            "WHERE (dias_participacion_valida BETWEEN :numeroDiasInicio AND :numeroDiasFin) " +
            "AND fecha_eliminacion IS NULL",nativeQuery = true)
    List<Sorteo> findByDaysParticipaction(@Param("numeroDiasInicio") Integer PNumeroDiasInicio, @Param("numeroDiasFin") Integer PNumeroDiasFin);

    /**
     * Método que encuentra la lista de  sorteo  cuyo Atributo Número Maximo de Ganadores  es el que se introduce
     * por parámetro.
     *
     * @param PNumeroInicio Número Inicio  sobre la que se realizará la consulta.
     * @param PNumeroFin Número Fin  sobre la que se realizará la consulta.
     * @return Lista de Sorteo cuyo Número Máximo de Ganadores coincide con los parámetros de entrada.
     */
    @Query(value = "SELECT * " +
            "FROM sorteos " +
            "WHERE (num_max_ganador BETWEEN :numeroInicio AND :numeroFin) " +
            "AND fecha_eliminacion IS NULL",nativeQuery = true)
    List<Sorteo> findByMaxWinners(@Param("numeroInicio") Integer PNumeroInicio, @Param("numeroFin") Integer PNumeroFin);

    /**
     * Método que devuelve la lista de sorteos que están activos.
     *
     * @return Lista de Sorteos Activos
     */
    @Query(value = "SELECT * " +
            "FROM sorteos " +
            "WHERE (NOW() BETWEEN fecha_inicio AND fecha_fin) " +
            "AND fecha_eliminacion IS NULL",nativeQuery = true)
    List<Sorteo> findActiveDraw();



}