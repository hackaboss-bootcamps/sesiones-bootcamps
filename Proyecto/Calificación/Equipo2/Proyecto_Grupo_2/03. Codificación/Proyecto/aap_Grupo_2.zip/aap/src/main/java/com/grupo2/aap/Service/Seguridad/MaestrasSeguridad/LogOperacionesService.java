package com.grupo2.aap.Service.Seguridad.MaestrasSeguridad;

import com.grupo2.aap.Entity.Seguridad.MaestrasSeguridad.LogOperaciones;
import com.grupo2.aap.IRepository.Seguridad.MestrasSeguridad.ILogOperacionRepository;
import com.grupo2.aap.Iservice.Seguridad.MaestrasSeguridad.ILogOperacionesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que contiene el Servicio de sobre el Repositorio LogVentas
 *
 * */
@Service
public class LogOperacionesService implements ILogOperacionesService {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Repositorio de LogOperacion*/
    @Autowired
    private ILogOperacionRepository repository;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Consultas">

    /**
     * Método que devuelve todas las Operaciones de seguridad de la Base de Datos
     *
     * @return Lista de log de Operaciones de seguridad de la Base de Datos
     */
    @Override
    public List<LogOperaciones> all() {
        return repository.findAll();
    }

    /**
     * Método que devuelve Operación de seguridad cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador del log de ventas de seguridad del que se quiere obtener la información
     * @return Lista de Operacones de seguridad que cumple con los requisitos de búsqueda.
     */
    @Override
    public Optional<LogOperaciones> findById(Long PId) {
        return repository.findById(PId);
    }

    /**
     * Método que devuelve Operación de seguridad cuyo Nombre Coincide total o parcialmente con el
     * introducir por parámetro.
     *
     * @param PNombre Nombre de la Operación que se desea consultar
     * @return Lista de Operaciones de seguridad que cumple con los requisitos de búsqueda.
     */
    @Override
    public List<LogOperaciones> findListByName(String PNombre) {
        return repository.findListByName(PNombre);
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de la Persistencia">

    /**
     * Método que Guarda la información de la Operación de seguridad que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PLogOperacion Entidad de log de Operación de seguridad que se desea almacenar.
     * @return Operación de seguridad que se ha guardado
     */
    @Override
    public LogOperaciones save(LogOperaciones PLogOperacion) {
        return repository.save(PLogOperacion);
    }

    /**
     * Método que Actualiza la información de la Operación de seguridad que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador de la Operación de Seguridad que se desea Actualizar.
     * @param PLogOperacion Entidad del log de Operaciónn de seguridad que se desea almacenar.
     */
    @Override
    public void update(Long PId, LogOperaciones PLogOperacion) {
        LogOperaciones VLogOperacionActualizado = new LogOperaciones();
        Optional<LogOperaciones> VLogOperaciones;

        VLogOperaciones = repository.findById(PId);

        if(VLogOperaciones.isEmpty()){
            System.out.println("Dato no encontrado");
        }else{
            VLogOperacionActualizado.clone(VLogOperaciones.get());

            repository.save(VLogOperacionActualizado);
        }
    }

    /**
     * Método que Elimina la información de la Operación de seguridad que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador de la Operación de Seguridad que se desea Eliminar.
     */
    @Override
    public void delete(Long PId) {
        repository.deleteById(PId);
    }

// </editor-fold>

}
