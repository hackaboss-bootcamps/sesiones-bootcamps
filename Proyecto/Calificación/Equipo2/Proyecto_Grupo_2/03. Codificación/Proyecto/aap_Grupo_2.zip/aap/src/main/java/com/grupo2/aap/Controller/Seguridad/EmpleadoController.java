package com.grupo2.aap.Controller.Seguridad;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Component.SecuritySession;
import com.grupo2.aap.Entity.Seguridad.Empleado;
import com.grupo2.aap.Entity.Ventas.Cliente;
import com.grupo2.aap.Iservice.Seguridad.IEmpleadoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/empleado")
public class EmpleadoController {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    @Autowired
    private IEmpleadoService service;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos Controladores de Conexión">

    @GetMapping("/ID")
    public Optional<Empleado> show(@RequestParam Long id, HttpSession sesion) {
        Optional<Empleado> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findById(id);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }


    @GetMapping("/NO")
    public List<Empleado> findByName(@RequestParam String nombre, HttpSession sesion) {
        List<Empleado> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByName(nombre);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @GetMapping("/DI")
    public List<Empleado> findByAdress(@RequestParam String direccion, HttpSession sesion) {
        List<Empleado> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByAddress(direccion);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @GetMapping("/PR")
    public List<Empleado> findByProvince(@RequestParam String provincia, HttpSession sesion) {
        List<Empleado> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByProvince(provincia);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @GetMapping("/PO")
    public List<Empleado> findByPoblacion(@RequestParam String poblacion, HttpSession sesion) {
        List<Empleado> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByTown(poblacion);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @GetMapping("/CP")
    public List<Empleado> findByPostalCode(@RequestParam String codPostal, HttpSession sesion) {
        List<Empleado> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByPostalCode(codPostal);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }


    @GetMapping("/EM")
    public List<Empleado> findByEmail(@RequestParam String email, HttpSession sesion) {
        List<Empleado> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByEMail(email);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @PostMapping
    @ResponseStatus(code = HttpStatus.CREATED)
    public Empleado save(@RequestBody Empleado cliente, HttpSession sesion) {
        Empleado VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.save(cliente);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @PutMapping()
    @ResponseStatus(code = HttpStatus.ACCEPTED)
    public Empleado update(@RequestParam Long id, @RequestBody Empleado cliente, HttpSession sesion) {
        Empleado VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.update(id, cliente);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @DeleteMapping()
    @ResponseStatus(code = HttpStatus.ACCEPTED)
    public boolean delete(@RequestParam Long id, HttpSession sesion) {
        boolean VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion = service.delete(id);
        }else{
            VDevolucion=false;
        }

        return VDevolucion;
    }
// </editor-fold>

}
