package com.grupo2.aap.Entity.Ventas;

import com.grupo2.aap.Entity.Ventas.Component.DetalleFacturaData;

import javax.persistence.*;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que implementa la Entidad de DetalleFacturaSimplificada. Esta clase contendrá la información básica y las operaciones
 * Básicas con dicha información.
 *
 * */
@Entity
@Table(name="detalles_facturas_simplificadas")
public class DetalleFacturaSimplificada extends DetalleFacturaData {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Factura a la que pertenece el Detalle  */
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "factura", nullable = false)
    private FacturaSimplificada factura;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Encapsulamiento">

    /**
     * Método que Devuelve la Factura Simplificada a la que pertenece el Detalle de Factura.
     *
     * @return Factura simplificada a la que pertenece la factura.
     */
    public FacturaSimplificada getFactura() {
        return factura;
    }

    /**
     * Método que Introduce la Factura Simplificada a la que pertenece el Detalle.
     *
     * @param factura Factura Simplificada a la que pertenece el Detalle.
     */
    public void setFactura(FacturaSimplificada factura) {
        this.factura = factura;
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de Datos">

    /**
     * Método que Clona la información de otra entidad detallefacturasimplificada en sí misma.
     *
     * @param PDetalleFacturaSimplificadaClonar DetalleFactura cuyos parámetros se desean clonar
     * @return Sí se ha realizado correctamente o no la operación.
     */
    public boolean clone(DetalleFacturaSimplificada PDetalleFacturaSimplificadaClonar){
        boolean VDevolucion;

        try{
            this.setId(PDetalleFacturaSimplificadaClonar.getId());
            this.setFactura(PDetalleFacturaSimplificadaClonar.getFactura());
            this.setProducto(PDetalleFacturaSimplificadaClonar.getProducto());
            this.setCantidad(PDetalleFacturaSimplificadaClonar.getCantidad());
            this.setPrecioUnitario(PDetalleFacturaSimplificadaClonar.getPrecioUnitario());
            this.setDtoPorcentaje(PDetalleFacturaSimplificadaClonar.getDtoPorcentaje());
            this.setIva(PDetalleFacturaSimplificadaClonar.getIva());

            VDevolucion = true;
        }catch (Exception ex){
            VDevolucion = false;
        }

        return VDevolucion;
    }

// </editor-fold>

}


