package com.grupo2.aap.Entity.Ventas;

import com.grupo2.aap.Entity.Ventas.Component.DetalleFacturaData;

import javax.persistence.*;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que implementa la Entidad de DetalleFactura. Esta clase contendrá la información básica y las operaciones
 * Básicas con dicha información.
 *
 * */

@Entity
@Table(name="detalles_facturas")
public class DetalleFactura extends DetalleFacturaData {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Factura a la que pertenece el Detalle  */
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "factura", nullable = false)
    private Factura factura;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Encapsulamiento">

    /**
     * Método que Devuelve la Factura del Detalle.
     *
     * @return Factura del Detalle.
     */
    public Factura getFactura() {
        return factura;
    }

    /**
     * Método que Introduce la Factura a la que pertenece el Detalle.
     *
     * @param factura Factura del Detalle.
     */
    public void setFactura(Factura factura) {
        this.factura = factura;
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de Datos">

    /**
     * Método que Clona la información de otra entidad detallefactura en sí misma.
     *
     * @param PDetalleFacturaClonar DetalleFactura cuyos parámetros se desean clonar
     * @return Sí se ha realizado correctamente o no la operación.
     */
    public boolean clone(DetalleFactura PDetalleFacturaClonar){
        boolean VDevolucion;

        try{
            this.setId(PDetalleFacturaClonar.getId());
            this.setFactura(PDetalleFacturaClonar.getFactura());
            this.setProducto(PDetalleFacturaClonar.getProducto());
            this.setCantidad(PDetalleFacturaClonar.getCantidad());
            this.setPrecioUnitario(PDetalleFacturaClonar.getPrecioUnitario());
            this.setDtoPorcentaje(PDetalleFacturaClonar.getDtoPorcentaje());
            this.setIva(PDetalleFacturaClonar.getIva());

            VDevolucion = true;
        }catch (Exception ex){
            VDevolucion = false;
        }

        return VDevolucion;
    }


// </editor-fold>

}


