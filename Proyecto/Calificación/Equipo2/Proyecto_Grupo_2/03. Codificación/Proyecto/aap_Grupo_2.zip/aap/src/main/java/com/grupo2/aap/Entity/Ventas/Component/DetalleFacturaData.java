package com.grupo2.aap.Entity.Ventas.Component;

import com.grupo2.aap.Entity.Ventas.Producto;

import javax.persistence.*;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que Contiene la información qu será almacenada en cada uno de los detalles de las facturas,
 * sean Facturas o Facturas Simplificadas.
 *
 * */

@MappedSuperclass
public  class DetalleFacturaData {

    /** Id del Detalle de la Factura */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Producto que se ha comprado */
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "producto", nullable = false)
    private Producto producto;

    /** Cantidad que se ha comprado */
    @Column(name = "cantidad",  nullable = false)
    private Integer cantidad=1;

    /** Precio Unitario del Producto */
    @Column(name = "precio_unitario", nullable = false)
    private Double precioUnitario;

    /** Porcentaje de Descuento aplicado al Producto */
    @Column(name = "dto_porcentaje", nullable = true)
    private Integer dtoPorcentaje=0;

    /** IVA al que está sujeto el Producto */
    @Column(name = "iva",  nullable = false)
    private Integer iva;


    /**
     * Método que Devuelve el Id del Detalle de Factura.
     *
     * @return Id del Detalle de Factura.
     */
    public Long getId() {
        return id;
    }

    /**
     * Método que Introduce el Id del Detalle de Factura.
     *
     * @param id del Detalle de Factura.
     *
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Método que Devuelve el Producto del Detalle de Factura.
     *
     * @return Producto del Detalle de Factura.
     */
    public Producto getProducto() {
        return producto;
    }

    /**
     * Método que Introduce el Producto del Detalle de Factura.
     *
     * @param producto del Detalle de Factura.
     *
     */
    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    /**
     * Método que Devuelve la Cantidad de Producto del Detalle de Factura.
     *
     * @return Cantidad del Detalle de Factura.
     */
    public Integer getCantidad() {
        return cantidad;
    }

    /**
     * Método que Introduce la Cantidad de Producto del Detalle de Factura.
     *
     * @param cantidad del Detalle de Factura.
     *
     */
    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    /**
     * Método que Devuelve el Precio Unitario del Producto del Detalle de Factura.
     *
     * @return Precio Unitario del Detalle de Factura.
     */
    public Double getPrecioUnitario() {
        return precioUnitario;
    }

    /**
     * Método que Introduce el Precio Unitario del Producto del Detalle de Factura.
     *
     * @param precioUnitario del Detalle de Factura.
     *
     */
    public void setPrecioUnitario(Double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    /**
     * Método que Devuelve el Porcentaje de Descuento en el producto del Detalle de Factura.
     *
     * @return Porcentaje de descuento del Detalle de Factura.
     */
    public Integer getDtoPorcentaje() {
        return dtoPorcentaje;
    }

    /**
     * Método que Introduce el Porcentaje de Descuento del Producto del Detalle de Factura.
     *
     * @param dtoPorcentaje del Detalle de Factura.
     *
     */
    public void setDtoPorcentaje(Integer dtoPorcentaje) {
        this.dtoPorcentaje = dtoPorcentaje;
    }

    /**
     * Método que Devuelve el IVA al que está sujeto el Producto del Detalle de Factura.
     *
     * @return IVA del Detalle de Factura.
     */
    public Integer getIva() {
        return iva;
    }

    /**
     * Método que Introduce el IVA al que está sujeto el Producto del Detalle de Factura.
     *
     * @param iva del Detalle de Factura.
     *
     */
    public void setIva(Integer iva) {
        this.iva = iva;
    }
}