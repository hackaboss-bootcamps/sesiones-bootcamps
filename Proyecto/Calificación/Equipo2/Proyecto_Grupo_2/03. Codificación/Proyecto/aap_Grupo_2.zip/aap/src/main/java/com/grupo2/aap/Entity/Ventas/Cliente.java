package com.grupo2.aap.Entity.Ventas;

import com.grupo2.aap.Entity.Component.PersonalData;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que implementa la Entidad de Cliente. Esta clase contendrá la información básica y las operaciones
 * Básicas con dicha información
 *
 * */

@Entity
@Table (name = "clientes")
public class Cliente extends PersonalData {

    /** Fecha de Eliminación de la Entidad (Borrado Lógico) */
    @Column (name = "fecha_eliminacion",nullable = true)
    private LocalDateTime fechaEliminacion;


    /**
     * Método que Devuelve la Fecha de Eliminación de la entidad
     *
     * @return Fecha en la que se ha eliminado la entidad.(Borrado Lógico)
     */
    public LocalDateTime getFechaEliminacion() {
        return fechaEliminacion;
    }


    /**
     * Método que Introduce la Fecha de Eliminación de la entidad
     *
     * @param fechaEliminacion Fecha en la que se ha eliminado la entidad.(Borrado Lógico)
     */
    public void setFechaEliminacion(LocalDateTime fechaEliminacion) {
        this.fechaEliminacion = fechaEliminacion;
    }


    /**
     * Método que Clona la información de otra entidad cliente en sí misma
     *
     * @param PClienteClonar Cliente cuyos parámetros se desean clonar
     * @return Sí se ha realizado correctamente o no la operación.
     */
    public boolean clone(Cliente PClienteClonar){
        boolean VDevolucion;

        try{
            this.setDni(PClienteClonar.getDni());
            this.setNombre(PClienteClonar.getNombre());
            this.setApellido1(PClienteClonar.getApellido1());
            this.setApellido2(PClienteClonar.getApellido2());
            this.setDireccion(PClienteClonar.getDireccion());
            this.setProvincia(PClienteClonar.getProvincia());
            this.setPoblacion(PClienteClonar.getPoblacion());
            this.setCodPostal(PClienteClonar.getCodPostal());
            this.setEmail(PClienteClonar.getEmail());

            VDevolucion = true;

        }catch (Exception ex){
            VDevolucion = false;
        }

        return VDevolucion;
    }

}