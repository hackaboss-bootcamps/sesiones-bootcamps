package com.grupo2.aap.IRepository.Ventas;

import com.grupo2.aap.Entity.Ventas.DetalleFactura;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que permite la ejecución de las cláusulas SQL necesarias para servir de repositorio de
 * la entidad DetalleFactura.
 *
 * */
@Repository
public interface IDetalleFacturaRepository extends JpaRepository<DetalleFactura,Long> {

    /**
     * Método que encuentra la lista de detalles factura cuya  Atributo Factura es la que se introduce
     * por parámetro.
     *
     * @param PFactura Factura sobre la que se realizará la consulta.
     * @return Lista de Detalle De Factura cuya Factura coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM detalles_facturas " +
            "WHERE factura = :factura", nativeQuery = true)
    List<DetalleFactura> findListByInvoice(@Param("factura") Long PFactura);

    /**
     * Método que encuentra la lista de detalles factura cuyo Atributo Producto es el que se introduce
     * por parámetro.
     *
     * @param PProducto Producto sobre la que se realizará la consulta.
     * @return Lista de Detalle De Factura cuyo Producto coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM detalles_facturas " +
            "WHERE producto = :producto", nativeQuery = true)
    List<DetalleFactura> findByProduct(@Param("producto") Long PProducto);

    /**
     * Método que encuentra la lista de detalles factura cuyo Atributo Cantidad es el que se introduce
     * por parámetro.
     *
     * @param PCantidadInicio Cantidad Inicial sobre la que se realizará la consulta.
     * @param PCantidadFin Cantidad Final sobre la que se realizará la consulta.
     * @return Lista de Detalle De Factura cuya CantidadInicio y CantidadFin coincide con los parámetros de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM detalles_facturas " +
            "WHERE cantidad BETWEEN :cantidadInicio AND :cantidadFin", nativeQuery = true)
    List<DetalleFactura> findByAmount(@Param("cantidadInicio") Integer PCantidadInicio,
                                      @Param("cantidadFin") Integer PCantidadFin);


}
