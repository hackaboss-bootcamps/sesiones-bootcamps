package com.grupo2.aap.Entity.Seguridad.Component;

import com.grupo2.aap.Entity.Seguridad.LogsOperaciones.LogAdministracion;
import com.grupo2.aap.Entity.Seguridad.MaestrasSeguridad.LogOperaciones;
import com.grupo2.aap.Entity.Seguridad.MaestrasSeguridad.LogTipoEntidad;
import com.grupo2.aap.Entity.Seguridad.Usuario;

import javax.persistence.*;
import java.security.Timestamp;
import java.time.LocalDateTime;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que mantendrá los datos necesarios para cualquier tipo de log que se necesite en el sistema.
 *
 * */
@MappedSuperclass
public  class LogData {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Identificador del Log*/
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Operación registrada en el Log*/
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "operacion", nullable = false)
    private LogOperaciones operacion;

    /** Tipo de Entidad registrada en el Log*/
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "tipo_entidad", nullable = false)
    private LogTipoEntidad tipoEntidad;

    /** Identificador Entidad registrada en el Log*/
    @Column(name = "entidad_id", nullable = false)
    private Long entidadId;

    /** Fecha del Registro Log*/
    @Column(name = "fecha")
    private LocalDateTime fecha;

    /** Usuario al que le sucedió el evento registrado en el Log*/
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "usuario", nullable = false)
    private Usuario usuario;

    /** Mensaje registrado en el Log*/
    @Column(name = "mensaje", length = 255, nullable = true)
    private String mensaje;


// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Encapsulamiento">

    /**
     * Método que devuelve el Identificador del Registro de Log
     *
     * @return  Identificador del Registro de Log
     */
    public Long getId() {
        return id;
    }

    /**
     * Método que Introduce el Identificador del Registro de Log
     *
     * @param id Identificador del Registro de Log
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Método que devuelve la operación del Registro de Log
     *
     * @return  Operación del Registro de Log
     */
    public LogOperaciones getOperacion() {
        return operacion;
    }

    /**
     * Método que Introduce la Operación del Registro de Log
     *
     * @param operacion Operación del Registro de Log
     */
    public void setOperacion(LogOperaciones operacion) {
        this.operacion = operacion;
    }

    /**
     * Método que devuelve el Tipo de Entidad del Registro de Log
     *
     * @return  Tipo de Entidad del Registro de Log
     */
    public LogTipoEntidad getTipoEntidad() {
        return tipoEntidad;
    }

    /**
     * Método que Introduce el Tipo de Entidad del Registro de Log
     *
     * @param tipoEntidad Tipo de Entidad del Registro de Log
     */
    public void setTipoEntidad(LogTipoEntidad tipoEntidad) {
        this.tipoEntidad = tipoEntidad;
    }

    /**
     * Método que devuelve el Identificador de la Entidad del Registro de Log
     *
     * @return  Identificador de la Entidad del Registro de Log
     */
    public Long getEntidadId() {
        return entidadId;
    }

    /**
     * Método que Introduce el Identificador de la Entidad del Registro de Log
     *
     * @param entidadId Identificador de la Entidad del Registro de Log
     */
    public void setEntidadId(Long entidadId) {
        this.entidadId = entidadId;
    }

    /**
     * Método que devuelve la Fecha del Registro de Log
     *
     * @return  Fecha del Registro de Log
     */
    public LocalDateTime getFecha() {
        return fecha;
    }

    /**
     * Método que Introduce la Fecha del Registro de Log
     *
     * @param fecha Fecha del Registro de Log
     */
    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }

    /**
     * Método que devuelve el Usuario del Registro de Log
     *
     * @return  Usuario del Registro de Log
     */
    public Usuario getUsuario() {
        return usuario;
    }

    /**
     * Método que Introduce el Usuario del Registro de Log
     *
     * @param usuario Usuario del Registro de Log
     */
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    /**
     * Método que devuelve el Mensaje del Registro de Log
     *
     * @return  Mensaje del Registro de Log
     */
    public String getMensaje() {
        return mensaje;
    }

    /**
     * Método que Introduce el Mensaje del Registro de Log
     *
     * @param mensaje Mensaje del Registro de Log
     */
    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

// </editor-fold>


}
