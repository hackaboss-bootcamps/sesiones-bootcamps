package com.grupo2.aap.Service.Seguridad.LogsSeguridad;
import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Seguridad.LogsSeguridad.SecLogVentas;


import com.grupo2.aap.IRepository.Seguridad.LogsSeguridad.ISecLogVentasRepository;
import com.grupo2.aap.Iservice.Seguridad.LogsSeguridad.ISecLogVentasService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que contiene el Servicio de sobre el Repositorio SecLogVentas
 *
 * */
@Service
public class SecLogVentasService implements ISecLogVentasService {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    @Autowired
    private ISecLogVentasRepository repository;


    /** Sistema de Control de la Seguridad que controlará los accesos por parte de los usuarios y
     * las actividades realizadas por los mismos */
    private SecurityCtrl securityCtrl;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos para el Control de la Seguridad">


    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    @Override
    public void setSecurityCtrl(SecurityCtrl securityCtrl) {
        this.securityCtrl = securityCtrl;
    }


// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Consultas">

    /**
     * Método que devuelve todos los log de ventas de seguridad de la Base de Datos
     *
     * @return Lista de log de ventas de seguridad de la Base de Datos
     */
    @Override
    public List<SecLogVentas> all(){
        List<SecLogVentas> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = repository.findAll();
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que devuelve el log de ventas de seguridad cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador del log de ventas de seguridad del que se quiere obtener la información
     * @return Log de ventas de seguridad que cumple con los requisitos de búsqueda.
     */
    @Override
    public Optional<SecLogVentas> findById(Long PId){
        Optional<SecLogVentas> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion=repository.findById(PId);
        }else{
            VDevolucion=Optional.empty();
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de log de ventas de seguridad cuya operacion es la que se introduce
     * por parámetro.
     *
     * @param POperacion Operacion del log de ventas de seguridad sobre el que se realizará la consulta.
     * @return Lista de log de ventas de seguridad cuya operacion coincide con el parámetro de entrada.
     */
    @Override
    public List<SecLogVentas> findListByOperation(Long POperacion){
        List<SecLogVentas> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByOperation(POperacion);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de log de ventas de seguridad cuyo tipo de entidad es el que se introduce
     * por parámetro.
     *
     * @param PTipoEntidad Tipo de entidad del log de ventas de seguridad sobre el que se realizará la consulta.
     * @return Lista de log de ventas de seguridad cuyo tipo de entidad coincide con el parámetro de entrada.
     */
    @Override
    public List<SecLogVentas> findListByTypeOfEntity(Long PTipoEntidad){
        List<SecLogVentas> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByTypeOfEntity(PTipoEntidad);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de log de ventas de seguridad cuya entidad es la que se introduce
     * por parámetro.
     *
     * @param PEntidad Entidad del log de ventas de seguridad sobre la que se realizará la consulta.
     * @return Lista de log de ventas de seguridad cuya entidad coincide con el parámetro de entrada.
     */
    @Override
    public List<SecLogVentas> findListByEntity(Long PEntidad){
        List<SecLogVentas> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByEntity(PEntidad);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de log de ventas de seguridad cuya fecha inicial y fecha final son las que se introducen
     * por parámetro.
     * @param PFechaInicio Fecha inicial del log de ventas de seguridad sobre la que se realizará la consulta.
     * @param PFechaFin Fecha final del log de ventas de seguridad sobre la que se realizará la consulta.
     * @return Lista de log de ventas de seguridad cuyas fechas iniciales y fechas finales coincide con el parámetro de entrada.
     */
    @Override
    public List<SecLogVentas> findByDate(LocalDateTime PFechaInicio, LocalDateTime PFechaFin){
        List<SecLogVentas> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findByDate(PFechaInicio,PFechaFin);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de log de ventas de seguridad cuyo usuario es el que se introduce
     * por parámetro.
     *
     * @param PUsuario Usuario del log de ventas de seguridad sobre el que se realizará la consulta.
     * @return Lista de log de ventas de seguridad cuyo usuario coincide con el parámetro de entrada.
     */
    @Override
    public List<SecLogVentas> findListByUser(Long PUsuario){
        List<SecLogVentas> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByUser(PUsuario);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de log de ventas de seguridad cuyo mensaje es el que se introduce
     * por parámetro.
     *
     * @param PMensaje Mensaje del log de ventas de seguridad sobre el que se realizará la consulta.
     * @return Lista de log de ventas de seguridad cuyo mensaje coincide con el parámetro de entrada.
     */
    @Override
    public List<SecLogVentas> findListByMessage(String PMensaje){
        List<SecLogVentas> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByMessage(PMensaje);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de la Persistencia">

    /**
     * Método que Guarda la información del log de ventas de seguridad que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PSecLogVentas Entidad del log de ventas de seguridad que se desea almacenar.
     * @return Log de ventas de seguridad con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public SecLogVentas save(SecLogVentas PSecLogVentas){
        SecLogVentas VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion=repository.save(PSecLogVentas);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

// </editor-fold>

}