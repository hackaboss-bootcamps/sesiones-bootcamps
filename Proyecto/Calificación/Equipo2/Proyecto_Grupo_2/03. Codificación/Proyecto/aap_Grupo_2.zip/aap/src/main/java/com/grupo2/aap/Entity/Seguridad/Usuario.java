package com.grupo2.aap.Entity.Seguridad;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que Implementa a la entidad Usuario que representa todas las credenciales de acceso necesarias
 * para que un empleado pueda acceder al Sistema.
 *
 *
 * */

@Entity
@Table (name = "usuarios")
public class Usuario {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Identificador de la entidad */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    /** Empleado de la entidad */
    @OneToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "empleado", nullable = false)
    private Empleado empleado;

    /** Atributo que expresa sí el Usuario es o no Administrador del Sistema */
    @Column(name = "administrador",nullable = false)
    private Boolean administrador = false;

    /** Nombre de Usuario del Sistema */
    @Column(name = "nombre_usuario",nullable = false,length = 50)
    private String nombreUsuario;

    /** Password del Usuario del Sistema */
    @Column(name = "password",nullable = false,length = 50)
    private String password;

    /** FEcha de Eliminación del Usuario del sistema */
    @Column (name = "fecha_eliminacion",nullable = true)
    private LocalDateTime fechaEliminacion;


// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Encapsulamiento">


    /**
     * Método que devuelve el Identificador del Usuario
     *
     * @return Identificador del Usuario
     */
    public long getId() {
        return id;
    }

    /**
     * Método que Introduce el Id del Usuario.
     *
     * @param id del Usuario.
     *
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * Método que devuelve Si el Usuario usuario es Administrador o no
     *
     * @return Administrador Si o No
     */
    public Boolean getAdministrador() {
        return administrador;
    }

    /**
     * Método que Introduce si el Usuario es Administrador.
     *
     * @param administrador Si o No Administrador.
     *
     */
    public void setAdministrador(Boolean administrador) {
        this.administrador = administrador;
    }

    /**
     * Método que devuelve el Nombre del Usuario
     *
     * @return Nombre del Usuario
     */
    public String getNombreUsuario() {
        return nombreUsuario;
    }

    /**
     * Método que Introduce el Nombre del Usuario.
     *
     * @param nombreUsuario Nombre del Usuario.
     *
     */
    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    /**
     * Método que devuelve el Pasword del Usuario
     *
     * @return Password del Usuario
     */
    public String getPassword() {
        return password;
    }

    /**
     * Método que Introduce el password del Usuario.
     *
     * @param password del Usuario.
     *
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Método que devuelve el Empleado al que pertenece el Usuario
     *
     * @return Empleado propietario del Usuario
     */
    public Empleado getEmpleado() {
        return empleado;
    }

    /**
     * Método que Introduce el empleado propietario del Usuario.
     *
     * @param empleado Empleado propietario del Usuario.
     *
     */
    public void setEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }

    /**
     * Método que devuelve la Fecha de Eliminación del usuario
     *
     * @return Fecha de Eliminación del Usuario
     */
    public LocalDateTime getFechaEliminacion() {
        return fechaEliminacion;
    }

    /**
     * Método que Introduce la Fecha de Eliminación del Usuario.
     *
     * @param fechaEliminacion Fecha de Eliminación Usuario.
     *
     */
    public void setFechaEliminacion(LocalDateTime fechaEliminacion) {
        this.fechaEliminacion = fechaEliminacion;
    }


// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de Datos">

    /**
     * Método que Clona la información de otra entidad Usuario en sí misma.
     *
     * @param PUsuarioClonar Usuario cuyos parámetros se desean clonar.
     * @return Sí se ha realizado correctamente o no la operación.
     */
    public boolean clone(Usuario PUsuarioClonar){
        boolean VDevolucion;

        try{
            this.setAdministrador(PUsuarioClonar.getAdministrador());
            this.setNombreUsuario(PUsuarioClonar.getNombreUsuario());
            this.setPassword(PUsuarioClonar.getPassword());
            this.setEmpleado(PUsuarioClonar.getEmpleado());

            VDevolucion = true;
        }catch (Exception ex){
            VDevolucion = false;
        }

        return VDevolucion;
    }

// </editor-fold>

}
