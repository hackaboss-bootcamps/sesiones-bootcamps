package com.grupo2.aap.Iservice.Ventas;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Ventas.FamiliaProducto;

import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que será de obligada implementación por parte del servicio asociado.
 *
 * */
public interface IFamiliaProductoService {

    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    void setSecurityCtrl(SecurityCtrl securityCtrl);

    /**
     * Método que devuelve la familia producto cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador de la familia producto de la que se quiere obtener la información
     * @return Familia Producto que cumple con los requisitos de búsqueda.
     */
    Optional<FamiliaProducto> findById(Long PId);

    /**
     * Método que encuentra la lista familia productos cuyo Atributo Nombre contenga
     * el Nombre o cadena de caracteres que se introduce por parámetro.
     *
     * @param PNombre Nombre de la familia de producto sobre el que se realizará la consulta.
     * @return Lista de Familias de  Productos cuyo nombre contenga con el parámetro de entrada.
     */
    List<FamiliaProducto> findListByName(String PNombre);

    /**
     * Método que encuentra la lista familia productos cuyo Atributo FamiliaPadre es el que se introduce
     *por parámetro.
     *
     * @param PFamilia de la familia de producto sobre el que se realizará la consulta.
     * @return Lista de Familias de  Productos cuyo familia producto coincide con el parámetro de entrada.
     */
    List<FamiliaProducto> findListByFamily(Long PFamilia);

    /**
     * Método que Guarda la información de la Familia Producto que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PFamiliaProducto Entidad FamiliaProducto que se desea almacenar.
     * @return FamiliaProduct con los datos que han sido guardados en la Base de Datos
     */
    FamiliaProducto save(FamiliaProducto PFamiliaProducto);

    /**
     * Método que Guarda los cambios de la información de la FamiliaProducto e que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador de la Entidad FamiliaProducto que se desea Actualizar.
     * @param PFamiliaProducto Entidad FamiliaProducto que se desea Actualizar.
     * @return FamiliaProducto con los datos que han sido guardados en la Base de Datos
     */
    FamiliaProducto update(Long PId, FamiliaProducto PFamiliaProducto);

    /**
     * Método que elimina la Familia Producto que se introduce por parámetro de la Base de Datos
     *
     * @param PId Identificador de la FamiliaProducto a que se desea Eliminar.
     * @return Sí se ha realizado correctamente la operación o no
     */
    boolean delete(Long PId);

}
