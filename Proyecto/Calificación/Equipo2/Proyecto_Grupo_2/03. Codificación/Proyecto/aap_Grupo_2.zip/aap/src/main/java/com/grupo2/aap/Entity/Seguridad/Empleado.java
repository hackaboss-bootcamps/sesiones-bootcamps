package com.grupo2.aap.Entity.Seguridad;

import com.grupo2.aap.Entity.Component.PersonalData;

import javax.persistence.*;
import javax.swing.text.html.Option;
import java.time.LocalDateTime;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que implementa la entidad de Empleado; donde como su nombre indica, contendrán todos los datos
 * de los empleados
 *
 * */
@Entity
@Table (name = "empleados")
public class Empleado extends PersonalData {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Fecha de Eliminación del Empleado*/
    @Column (name = "fecha_eliminacion",nullable = true)
    private LocalDateTime fechaEliminacion;


// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Encapsulamiento">

    /**
     * Método que devuelve la Fecha de Eliminacion del Usuario del Sistema
     *
     * @return  Fecha de Eliminación del Usuario
     */
    public LocalDateTime devolverFechaEliminacion() {
        return fechaEliminacion;
    }

    /**
     * Método que Introduce la Fecha de Eliminacion del Usuario del Sistema
     *
     * @param fechaEliminacion Fecha de Eliminacion del Usuario del Sistema
     */
    public void setFechaEliminacion(LocalDateTime fechaEliminacion) {
        this.fechaEliminacion = fechaEliminacion;
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de Datos">

    /**
     * Método que Clona la información de otra entidad Empleado en sí misma.
     *
     * @param PEmpleadoClonar Empleado cuyos parámetros se desean clonar
     * @return Sí se ha realizado correctamente o no la operación.
     */

    public boolean clone(Empleado PEmpleadoClonar){
        boolean VDevolucion;
        
        try{
            this.setDni(PEmpleadoClonar.getDni());
            this.setNombre(PEmpleadoClonar.getNombre());
            this.setApellido1(PEmpleadoClonar.getApellido1());
            this.setApellido2(PEmpleadoClonar.getApellido2());
            this.setDireccion(PEmpleadoClonar.getDireccion());
            this.setProvincia(PEmpleadoClonar.getProvincia());
            this.setPoblacion(PEmpleadoClonar.getPoblacion());
            this.setCodPostal(PEmpleadoClonar.getCodPostal());
            this.setEmail(PEmpleadoClonar.getEmail());

            VDevolucion = true;        
        }catch (Exception ex){
            VDevolucion = false;
        }
        
        return VDevolucion;
    }

// </editor-fold>

}