package com.grupo2.aap.Controller.Fidelizacion;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Component.SecuritySession;
import com.grupo2.aap.Entity.Fidelizacion.Participacion;
import com.grupo2.aap.Entity.Fidelizacion.Sorteo;
import com.grupo2.aap.Iservice.Fidelizacion.IParticipacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/participacion")
public class ParticipacionController {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    @Autowired
    private IParticipacionService service;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos Controladores de Conexión">

    @GetMapping("/ID")
    public Optional<Participacion> show(@RequestParam Long id) {
        Optional<Participacion> VDevolucion;

        try{
            VDevolucion=service.findById(id);
        }catch (Exception ex){
            VDevolucion=Optional.empty();
        }

        return VDevolucion;
    }

    @GetMapping("/SO")
    public List<Participacion> findBySorteo(@RequestParam Long idSorteo) {
        List<Participacion> VDevolucion;

        try{
            VDevolucion=service.findByDraw(idSorteo);
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @GetMapping("/GS")
    public List<Participacion> findByGanadoresSorteo(@RequestParam Long idSorteo) {
        List<Participacion> VDevolucion;

        try{
            VDevolucion=service.findByWinnersDraw(idSorteo);
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @GetMapping("/NU")
    public List<Participacion> findByNumber(@RequestParam Integer number) {
        List<Participacion> VDevolucion;

        try{
            VDevolucion=service.findByNumber(number);
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @GetMapping("/CD")
    public List<Participacion> findByCancelDate(@RequestParam String fechaInicio,
                                                @RequestParam String fechaFin) {
        List<Participacion> VDevolucion;
        DateTimeFormatter VFormateador = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        LocalDateTime VFechaInicio;
        LocalDateTime VFechaFin;

        try{
            fechaInicio=fechaInicio+" 00:00";
            fechaFin=fechaFin+" 00:00";
            VFechaInicio=LocalDateTime.parse(fechaInicio, VFormateador);
            VFechaFin=LocalDateTime.parse(fechaFin, VFormateador);

            VDevolucion=service.findByCancelDate(VFechaInicio,VFechaFin);
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @GetMapping("/MV")
    public List<Participacion> findByMaxValidityDate(@RequestParam String fechaInicio,
                                                     @RequestParam String fechaFin) {
        List<Participacion> VDevolucion;
        DateTimeFormatter VFormateador = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        LocalDateTime VFechaInicio;
        LocalDateTime VFechaFin;

        try{
            fechaInicio=fechaInicio+" 00:00";
            fechaFin=fechaFin+" 00:00";
            VFechaInicio=LocalDateTime.parse(fechaInicio, VFormateador);
            VFechaFin=LocalDateTime.parse(fechaFin, VFormateador);

            VDevolucion=service.findByMaxValidityDate(VFechaInicio,VFechaFin);
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @GetMapping("/FA")
    public List<Participacion> findByApplicationInvoice(@RequestParam Long idFactura) {
        List<Participacion> VDevolucion;

        try{
            VDevolucion=service.findByApplicationInvoice(idFactura);
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @GetMapping("/FG")
    public List<Participacion> findByGenerationInvoice(@RequestParam Long idFactura) {
        List<Participacion> VDevolucion;

        try{
            VDevolucion=service.findByGenerationInvoice(idFactura);
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }


    @PostMapping("/SA")
    @ResponseStatus(code = HttpStatus.CREATED)
    public Participacion save(@RequestBody Participacion participacion, HttpSession sesion) {
        Participacion VDevolucion;
        SecurityCtrl VSecurityCtrl;

        try{
            VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
            if (VSecurityCtrl!=null){
                service.setSecurityCtrl(VSecurityCtrl);
                VDevolucion=service.save(participacion);
            }else{
                VDevolucion=null;
            }
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @PutMapping()
    @ResponseStatus(code = HttpStatus.ACCEPTED)
    public Participacion update(@RequestParam Long id,
                                @RequestBody Participacion participacion,
                                HttpSession sesion) {
        Participacion VDevolucion;
        SecurityCtrl VSecurityCtrl;

        try{
            VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
            if (VSecurityCtrl!=null){
                service.setSecurityCtrl(VSecurityCtrl);
                VDevolucion=service.update(id, participacion);
            }else{
                VDevolucion = null;
            }
        }catch (Exception ex){
            VDevolucion = null;
        }

        return VDevolucion;
    }

    @DeleteMapping()
    @ResponseStatus(code = HttpStatus.ACCEPTED)
    public boolean delete(@RequestParam Long id, HttpSession sesion) {
        boolean VDevolucion;
        SecurityCtrl VSecurityCtrl;

        try{
            VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
            if (VSecurityCtrl!=null){
                service.setSecurityCtrl(VSecurityCtrl);

                VDevolucion=service.delete(id);
            }else{
                VDevolucion=false;
            }
        }catch (Exception ex){
            VDevolucion=false;
        }

        return VDevolucion;
    }

// </editor-fold>

}
