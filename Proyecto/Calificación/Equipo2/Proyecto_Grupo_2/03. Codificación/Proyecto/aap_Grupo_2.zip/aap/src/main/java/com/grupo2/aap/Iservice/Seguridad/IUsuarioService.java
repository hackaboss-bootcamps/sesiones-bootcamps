package com.grupo2.aap.Iservice.Seguridad;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Seguridad.Usuario;

import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que será de obligada implementación por parte del servicio asociado.
 *
 * */
public interface IUsuarioService {

    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    void setSecurityCtrl(SecurityCtrl securityCtrl);

    /**
     * Método que devuelve todos los usuarios de la Base de Datos
     *
     * @return Lista de usuarios de la Base de Datos
     */
    List<Usuario> all();

    /**
     * Método que devuelve el usuario cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador del Usuario del que se quiere obtener la información
     * @return Usuario que cumple con los requisitos de búsqueda.
     */
    Optional<Usuario> findById(Long PId);

    /**
     * Método que encuentra la lista de usuario cuyo empleado es el que se introduce
     * por parámetro.
     *
     * @param PEmpleado Empleado del usuario sobre el que se realizará la consulta.
     * @return Lista de Usuarios cuyo empleado coincide con el parámetro de entrada.
     */
    List<Usuario> findByEmployee(Long PEmpleado);

    /**
     * Método que encuentra la lista de usuarios cuyo nombre de usuario es el que se introduce
     * por parámetro.
     *
     * @param PNombreUsuario Nombre de usuario del usuario sobre el que se realizará la consulta.
     * @return Lista de Usuario cuyo nombre de usuario coincide con el parámetro de entrada.
     */
    List<Usuario> findByName(String PNombreUsuario);

    /**
     * Método que encuentra la lista de usuarios cuyo Rol es el que se introduce
     * por parámetro.
     *
     * @param PAdministrador Administrador del usuario sobre el que se realizará la consulta.
     * @return Lista de Usuarios cuyo administrador coincide con el parámetro de entrada.
     */
    List<Usuario> findByRol(Boolean PAdministrador);

    /**
     * Método que autentifica al usuario mediante un Nombre de Usaurio y una Password
     *
     * @param PNombreUsuario Nombre de usuario del usuario sobre el que se realizará la consulta.
     * @param PContrasenha Contraseña del usuario sobre el que se realizará la consulta.
     * @return Lista de Usuarios cuyo nombre de usuario y contraseña coinciden con los parámetros de entrada.
     */
    Optional<Usuario> authenticate(String PNombreUsuario,
                                   String PContrasenha);

    /**
     * Método que Guarda la información del usuario que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PUsuario Entidad Usuario que se desea almacenar.
     * @return Usuario con los datos que han sido guardados en la Base de Datos
     */
    Usuario save(Usuario PUsuario);

    /**
     * Método que Guarda los cambios de la información del usuario que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador de la Entidad Usuario que se desea Actualizar.
     * @param PUsuario Entidad Usuario que se desea Actualizar.
     * @return Usuario con los datos que han sido guardados en la Base de Datos
     */
    Usuario update(Long PId, Usuario PUsuario);

    /**
     * Método que elimina el Usuario que se introduce por parámetro de la Base de Datos
     *
     * @param PId Identificador del Usuario que se desea Eliminar.
     */
    boolean delete(Long PId);

}
