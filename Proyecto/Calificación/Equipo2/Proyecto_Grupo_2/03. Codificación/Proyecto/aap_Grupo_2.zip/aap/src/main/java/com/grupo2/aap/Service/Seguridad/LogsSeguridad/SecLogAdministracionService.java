package com.grupo2.aap.Service.Seguridad.LogsSeguridad;


import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.IRepository.Seguridad.LogsSeguridad.ISecLogAdministracionRepository;
import com.grupo2.aap.Entity.Seguridad.LogsSeguridad.SecLogAdministracion;
import com.grupo2.aap.Iservice.Seguridad.LogsSeguridad.ISecLogAdministracionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que contiene el Servicio de sobre el Repositorio SecLogAdministracion
 *
 * */
@Service
public class SecLogAdministracionService implements ISecLogAdministracionService {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Repositorio de SecLogAdministracion*/
    @Autowired
    private ISecLogAdministracionRepository repository;


    /** Sistema de Control de la Seguridad que controlará los accesos por parte de los usuarios y
     * las actividades realizadas por los mismos */
    private SecurityCtrl securityCtrl;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos para el Control de la Seguridad">


    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    @Override
    public void setSecurityCtrl(SecurityCtrl securityCtrl) {
        this.securityCtrl = securityCtrl;
    }


// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Consultas">

    /**
     * Método que devuelve todos los log de administracion de seguridad de la Base de Datos
     *
     * @return Lista de log de administracion de seguridad de la Base de Datos
     */
    @Override
    public List<SecLogAdministracion> all(){
        List<SecLogAdministracion> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = repository.findAll();
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que devuelve el log de administracion de seguridad cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador del log de administracion de seguridad del que se quiere obtener la información
     * @return Log de administracion de seguridad que cumple con los requisitos de búsqueda.
     */
    @Override
    public Optional<SecLogAdministracion> findById(Long PId){
        Optional<SecLogAdministracion> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion=repository.findById(PId);
        }else{
            VDevolucion=Optional.empty();
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de log de administracion de seguridad cuya operacion es la que se introduce
     * por parámetro.
     *
     * @param POperacion Operacion del log de administracion de seguridad sobre el que se realizará la consulta.
     * @return Lista de log de administracion de seguridad cuya operacion coincide con el parámetro de entrada.
     */
    @Override
    public List<SecLogAdministracion> findListByOperation(Long POperacion){
        List<SecLogAdministracion> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByOperation(POperacion);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de log de administracion de seguridad cuyo tipo de entidad es el que se introduce
     * por parámetro.
     *
     * @param PTipoEntidad Tipo de entidad del log de administracion de seguridad sobre el que se realizará la consulta.
     * @return Lista de log de administracion de seguridad cuyo tipo de entidad coincide con el parámetro de entrada.
     */
    @Override
    public List<SecLogAdministracion> findListByTypeOfEntity(Long PTipoEntidad){
        List<SecLogAdministracion> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByTypeOfEntity(PTipoEntidad);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de log de administracion de seguridad cuya entidad es la que se introduce
     * por parámetro.
     *
     * @param PEntidad Entidad del log de administracion de seguridad sobre la que se realizará la consulta.
     * @return Lista de log de administracion de seguridad cuya entidad coincide con el parámetro de entrada.
     */
    @Override
    public List<SecLogAdministracion> findListByEntity(Long PEntidad){
        List<SecLogAdministracion> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByEntity(PEntidad);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de log de administracion de seguridad cuya fecha inicial y fecha final son las que se introducen
     * por parámetro.
     * @param PFechaInicio Fecha inicial del log de administracion de seguridad sobre la que se realizará la consulta.
     * @param PFechaFin Fecha final del log de administracion de seguridad sobre la que se realizará la consulta.
     * @return Lista de log de administracion de seguridad cuyas fechas iniciales y fechas finales coincide con el parámetro de entrada.
     */
    @Override
    public List<SecLogAdministracion> findByDate(LocalDateTime PFechaInicio, LocalDateTime PFechaFin){
        List<SecLogAdministracion> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findByDate(PFechaInicio,PFechaFin);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de log de administracion de seguridad cuyo usuario es el que se introduce
     * por parámetro.
     *
     * @param PUsuario Usuario del log de administracion de seguridad sobre el que se realizará la consulta.
     * @return Lista de log de administracion de seguridad cuyo usuario coincide con el parámetro de entrada.
     */
    @Override
    public List<SecLogAdministracion> findListByUser(Long PUsuario){
        List<SecLogAdministracion> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByUser(PUsuario);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de log de administracion de seguridad cuyo mensaje es el que se introduce
     * por parámetro.
     *
     * @param PMensaje Mensaje del log de administracion de seguridad sobre el que se realizará la consulta.
     * @return Lista de log de administracion de seguridad cuyo mensaje coincide con el parámetro de entrada.
     */
    @Override
    public List<SecLogAdministracion> findListByMessage(String PMensaje){
        List<SecLogAdministracion> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByMessage(PMensaje);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }
// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de la Persistencia">

    /**
     * Método que Guarda la información del log de administracion de seguridad que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PSecLogAdministracion Entidad del log de administracion de seguridad que se desea almacenar.
     * @return Log de administracion de seguridad con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public SecLogAdministracion save(SecLogAdministracion PSecLogAdministracion){
        SecLogAdministracion VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion=repository.save(PSecLogAdministracion);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

// </editor-fold>

}

