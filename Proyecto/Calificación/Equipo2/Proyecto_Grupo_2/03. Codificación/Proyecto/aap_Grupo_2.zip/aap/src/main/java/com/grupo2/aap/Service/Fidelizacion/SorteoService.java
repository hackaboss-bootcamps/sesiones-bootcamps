package com.grupo2.aap.Service.Fidelizacion;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Fidelizacion.DetalleSorteo;
import com.grupo2.aap.Entity.Fidelizacion.Participacion;
import com.grupo2.aap.Entity.Fidelizacion.Sorteo;
import com.grupo2.aap.Entity.Ventas.Factura;
import com.grupo2.aap.IRepository.Fidelizacion.ISorteoRepository;
import com.grupo2.aap.Iservice.Fidelizacion.IDetalleSorteoService;
import com.grupo2.aap.Iservice.Fidelizacion.IParticipacionService;
import com.grupo2.aap.Iservice.Fidelizacion.ISorteoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que contiene el Servicio de sobre el Repositorio Sorteos
 *
 * */

@Service
public class SorteoService implements ISorteoService {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    @Autowired
    private ISorteoRepository repository;

    @Autowired
    private IDetalleSorteoService detalleSorteoService;

    @Autowired
    private IParticipacionService participacionService;

    /** Sistema de Control de la Seguridad que controlará los accesos por parte de los usuarios y
     * las actividades realizadas por los mismos */
    private SecurityCtrl securityCtrl;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos para el Control de la Seguridad">


    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    @Override
    public void setSecurityCtrl(SecurityCtrl securityCtrl) {
        this.securityCtrl = securityCtrl;
        this.detalleSorteoService.setSecurityCtrl(this.securityCtrl);
        this.participacionService.setSecurityCtrl(this.securityCtrl);
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Consultas">


    /**
     * Método que devuelve todos los Sorteos de la Base de Datos
     *
     * @return Lista de Sorteos de la Base de Datos
     */
    @Override
    public List<Sorteo> all() {
        return repository.findAll();
    }

    /**
     * Método que devuelve el Sorteo cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador del Sorteo del que se quiere obtener la información
     * @return Sorteo que cumple con los requisitos de búsqueda.
     */
    @Override
    public Optional<Sorteo> findById(Long PId) {
        return repository.findById(PId);
    }

    /**
     * Método que encuentra la lista de Sorteos cuyo Atributo nombre contenga
     * el nombre o cadena de caracteres que se introduce por parámetro.
     *
     * @param PNombre Nombre del Sorteo sobre el que se realizará la consulta.
     * @return Lista de Sorteos cuyo Nombre contenga con el parámetro de entrada.
     */
    @Override
    public List<Sorteo> findByNombre(String PNombre) {
        return repository.findByNombre( PNombre);
    }

    /**
     * Método que encuentra la lista de Sorteos Cuya Fecha de Creación
     * está entre la Fecha de Inicio y de Fin
     *
     * @param PFechaInicio Fecha de Inicio sobre la que se quiere hacer la consulta
     * @param PFechaFin Fecha de Fin sobre la que se quiere hacer la consulta
     * @return Lista de Sorteos que cumplan la condición
     */
    @Override
    public List<Sorteo> findByCreationDate(LocalDateTime PFechaInicio, LocalDateTime PFechaFin) {
        return repository.findByCreationDate(PFechaInicio,PFechaFin);
    }

    /**
     * Método que encuentra la lista de Sorteos Cuya Fecha de Inicio
     * está entre la Fecha de Inicio y de Fin
     *
     * @param PFechaInicio Fecha de Inicio sobre la que se quiere hacer la consulta
     * @param PFechaFin Fecha de Fin sobre la que se quiere hacer la consulta
     * @return Lista de Sorteos que cumplan la condición
     */
    @Override
    public List<Sorteo> findByStartDate(LocalDateTime PFechaInicio, LocalDateTime PFechaFin) {
        return repository.findByStartDate(PFechaInicio,  PFechaFin);
    }

    /**
     * Método que encuentra la lista de Sorteos Cuya Fecha de Finalización
     * está entre la Fecha de Inicio y de Fin
     *
     * @param PFechaInicio Fecha de Inicio sobre la que se quiere hacer la consulta
     * @param PFechaFin Fecha de Fin sobre la que se quiere hacer la consulta
     * @return Lista de Sorteos que cumplan la condición
     */
    @Override
    public List<Sorteo> findByFinalizeDate(LocalDateTime PFechaInicio, LocalDateTime PFechaFin) {
        return repository.findByFinalizeDate(PFechaInicio, PFechaFin);
    }

    /**
     * Método que encuentra la lista de Sorteos Cuya Descuento por tarjeta de regalo
     * está entre el Dto de Inicio y de Fin
     *
     * @param PDtoInicio Valor del Descuento de Inicio sobre la que se quiere hacer la consulta
     * @param PDtoFin Valor del Descuento de Fin sobre la que se quiere hacer la consulta
     * @return Lista de Sorteos que cumplan la condición
     */
    @Override
    public List<Sorteo> findByDtoPresentCard(Double PDtoInicio,Double PDtoFin) {
        return repository.findByDtoPresentCard(PDtoInicio,PDtoFin);
    }

    /**
     * Método que encuentra la lista de Sorteos Cuya Descuento en factura
     * está entre el Dto de Inicio y de Fin
     *
     * @param PDtoInicio Valor del Descuento de Inicio sobre la que se quiere hacer la consulta
     * @param PDtoFin Valor del Descuento de Fin sobre la que se quiere hacer la consulta
     * @return Lista de Sorteos que cumplan la condición
     */
    @Override
    public List<Sorteo> findByDtoInvoice(Integer PDtoInicio,Integer PDtoFin) {
        return repository.findByDtoInvoice( PDtoInicio, PDtoFin);
    }

    /**
     * Método que encuentra la lista de Sorteos cuyos días en la que la participación es válida
     * está entre el Número de Días de Inicio y de Fin
     *
     * @param PNumeroDiasInicio Número de días de Inicio sobre la que se quiere hacer la consulta
     * @param PNumeroDiasFin Número de días de Fin sobre la que se quiere hacer la consulta
     * @return Lista de Sorteos que cumplan la condición
     */
    @Override
    public List<Sorteo> findByDaysParticipation(Integer PNumeroDiasInicio, Integer PNumeroDiasFin) {
        return repository.findByDaysParticipaction(PNumeroDiasInicio, PNumeroDiasFin);
    }

    /**
     * Método que encuentra la lista de Sorteos cuyo número máximo de Ganadores
     * está entre el Número de Inicio y de Fin
     *
     * @param PNumeroInicio Número de Ganadores máximo de Inicio sobre la que se quiere hacer la consulta
     * @param PNumeroFin Número de Ganadores Máximo de Fin sobre la que se quiere hacer la consulta
     * @return Lista de Sorteos que cumplan la condición
     */
    @Override
    public List<Sorteo> findByMaxWinners(Integer PNumeroInicio,Integer PNumeroFin) {
        return repository.findByMaxWinners(PNumeroInicio,PNumeroFin);
    }

    /**
     * Método que encuentra la lista de Detalles de Sorteos cuyo Número de Sorteo es el que se introduce
     * por parámetro
     *
     * @param PSorteo Sorteo sobre el que se quiere consultar
     * @return Lista de Sorteos que cumplan la condición
     */
    @Override
    public List<DetalleSorteo> findDetallesSorteo(Sorteo PSorteo) {
        return this.detalleSorteoService.findBySorteo(PSorteo.getId());
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de la Persistencia">

    // <editor-fold defaultstate="collapsed" desc="Gestión de Participaciones">

    /**
     * Método que premia las Participaciones que se introducen por parámetro
     *
     * @param PParticipacionesPremiadas Particiones premiadas
     * @param PSorteo Sorteo al cual pertenecen las participaciones
     * @return Lista de Participaciones premiadas con marca de Fecha de Máxima Validez
     */
    @Override
    public List<Participacion> premiarParticipaciones(List<Participacion> PParticipacionesPremiadas, Sorteo PSorteo) {
        List<Participacion> VDevolucion=new ArrayList<Participacion>();
        Participacion VParticipacionAux;
        int VIndice=0;

        try{
            participacionService.setSecurityCtrl(this.securityCtrl);
            for (VIndice=0;VIndice<PParticipacionesPremiadas.size();VIndice++){
                VParticipacionAux=PParticipacionesPremiadas.get(VIndice);
                if (participacionService.premiar(VParticipacionAux,PSorteo.getFechaMaxValidez())){
                    VDevolucion.add(VParticipacionAux);
                }
            }

        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    /**
     * Método que Genera una participación y le asigna la Factura por la cual se ha generado
     *
     * @param PFactura Factura que a generado la participación
     * @return Participación Generada
     */
    @Override
    public Participacion generarParticipacion(Factura PFactura) {
        Participacion VDevolucion;
        List<Sorteo> VSorteosActuales;

        try{
            VSorteosActuales=repository.findActiveDraw();
            if (VSorteosActuales!=null && VSorteosActuales.size()>0){
                this.participacionService.setSecurityCtrl(this.securityCtrl);
                VDevolucion=this.participacionService.generar(VSorteosActuales.get(0),PFactura);
            }else{
                VDevolucion=null;
            }

        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    /**
     * Método que Genera una participación para el Sorteo que se introduce por parámetro y le
     * Asigna la Factura por la cual se ha generado
     *
     * @param PSorteo Sorteo para la cual es la participación
     * @param PFactura Factura que a generado la participación
     * @return Participación Generada
     */
    @Override
    public Participacion generarParticipacion(Sorteo PSorteo, Factura PFactura) {
        Participacion VDevolucion;

        try{
            VDevolucion=this.participacionService.generar(PSorteo,PFactura);
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Herramientas de la Clase">

    /**
     * Método que realiza el sorteo aleatorio y devuelve la lista de Participaciones premiadas
     *
     * @return Lista de Participaciones Premiadas
     */
    @Override
    public List<Participacion> realizarSorteo() {
        List<Participacion> VDevolucion;
        List<Participacion> VParticipacionesPremiadas;
        List<Sorteo> VSorteos;
        List<Participacion> VParticipaciones;
        Sorteo VSorteoActual;
        Participacion VParticipacionAux;
        int VNumeroSeleccionadoAux;
        int VIndice=0;
        int VNumeroMaxGanadores;
        int VContadorOportunidades=0;
        Random VGeneradorNumerosAletarios=new Random();
        Double VNumeroAletorioOriginal;

        try{
            VSorteos = repository.findActiveDraw();
            if (VSorteos!=null && VSorteos.size()>0){
                VSorteoActual = VSorteos.get(0);

                participacionService.setSecurityCtrl(this.securityCtrl);
                VParticipaciones=participacionService.findByDraw(VSorteoActual.getId());
                if (VParticipaciones!=null){

                    VNumeroMaxGanadores=VSorteoActual.getNumMaxGanador();
                    if (VNumeroMaxGanadores>=VParticipaciones.size()){
                        VParticipacionesPremiadas=VParticipaciones;
                    }else{
                        VParticipacionesPremiadas=new ArrayList<Participacion>();
                        while (VIndice<VNumeroMaxGanadores && VContadorOportunidades<VNumeroMaxGanadores*10){
                            VNumeroSeleccionadoAux=VGeneradorNumerosAletarios.nextInt(VParticipaciones.size());
                            VParticipacionAux=VParticipaciones.get(VNumeroSeleccionadoAux);
                            if (!estaSeleccionadaParaPremiar(VParticipacionesPremiadas,VParticipacionAux.getId())){
                                VParticipacionesPremiadas.add(VParticipacionAux);
                                VIndice++;
                            }else{
                                VContadorOportunidades++;
                            }
                        }
                    }
                    if (VParticipacionesPremiadas!=null){
                        VDevolucion=this.premiarParticipaciones(VParticipacionesPremiadas,VSorteoActual);
                    }else{
                        VDevolucion=null;
                    }
                }else{
                    VDevolucion=null;
                }
            }else{
                VDevolucion=null;
            }

        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    /**
     * Método que Guarda la información del Sorteo que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PSorteo Entidad Sorteo que se desea almacenar.
     * @return Sorteo con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public Sorteo save(Sorteo PSorteo) {
        return repository.save(PSorteo);
    }

    /**
     * Método que Guarda los cambios de la información del Sorteo que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador de la Entidad Sorteo que se desea Actualizar.
     * @param PSorteo Entidad Sorteo que se desea Actualizar.
     * @return Sorteo con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public Sorteo update(Long PId, Sorteo PSorteo) {
        Sorteo VDevolucion;
        Optional<Sorteo> VSorteo;

        try{
            if (this.securityCtrl.isAdministrator()){
                VSorteo = repository.findById(PId);

                if(!VSorteo.isEmpty()){
                    PSorteo.setId(VSorteo.get().getId());

                    VDevolucion = repository.save(PSorteo);
                }else{
                    VDevolucion =null;
                }
            }else{
                VDevolucion=null;
            }
        }catch (Exception ex){
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que elimina el Sorteo que se introduce por parámetro de la Base de Datos
     *
     * @param PId Identificador del Sorteo que se desea Eliminar.
     * @return Sí se ha realizado o no correctamente la operacion
     */
    @Override
    public boolean delete(Long PId) {
        boolean VDevolucion;
        Optional<Sorteo> VSorteo;

        if (this.securityCtrl.isAdministrator()){
            VSorteo = this.findById(PId);

            if (!VSorteo.isEmpty()){
                VSorteo.get().setFechaEliminacion(LocalDateTime.now());
                VDevolucion = (this.save(VSorteo.get())!=null);
            }else{
                VDevolucion=false;
            }
        }else{
            VDevolucion=false;
        }

        return VDevolucion;
    }

    // </editor-fold>

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Herramientas de la Clase">

    private boolean estaSeleccionadaParaPremiar(List<Participacion> PParticipacionesSeleccionadas, Long PIdParticipacionComprobar){
        boolean VDevolucion;
        boolean VEncontrado=false;
        int VIndice=0;

        try{
            while (VIndice<PParticipacionesSeleccionadas.size() && !VEncontrado){
                VEncontrado=(PParticipacionesSeleccionadas.get(VIndice).getId()==PIdParticipacionComprobar);
                VIndice++;
            }

            VDevolucion=VEncontrado;

        }catch (Exception ex){
            VDevolucion=false;
        }

        return VDevolucion;
    }

// </editor-fold>

}


