package com.grupo2.aap.Iservice.Ventas;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Ventas.Producto;

import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que será de obligada implementación por parte del servicio asociado.
 *
 * */
public interface IProductoService {

    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    void setSecurityCtrl(SecurityCtrl securityCtrl);

    /**
     * Método que devuelve los productos cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador del producto de la que se quiere obtener la información
     * @return Producto que cumple con los requisitos de búsqueda.
     */
    Optional<Producto> findById(Long PId);

    /**
     * Método que encuentra la lista de Productos cuyo Atributo Codigo Barras contenga
     * el Código de Barras o cadena de caracteres que se introduce por parámetro.
     *
     * @param PCodBarras Codigo de Barras del producto sobre el que se realizará la consulta.
     * @return Lista de Producto cuyo Codigo de Barras contenga con el parámetro de entrada.
     */
    List<Producto> findByCodBarras(String PCodBarras);

    /**
     * Método que encuentra la lista de Productos cuyo Atributo Nombre contenga
     * el nombre o cadena de caracteres que se introduce por parámetro.
     *
     * @param PNombre Nombre del producto sobre el que se realizará la consulta.
     * @return Lista de Producto cuyo Nombre contenga con el parámetro de entrada.
     */
    List<Producto> findByName(String PNombre);

    /**
     * Método que encuentra la lista de Productos cuyo Atributo Cantidad es el que se introduce
     * por parámetro.
     *
     * @param cantidadInicio Cantidad Inicial sobre la que se realizará la consulta
     * @param cantidadFin Cantidad Final sobre la que se realizará la consulta
     * @return Lista de Producto cuya CantidadInicio y CantidadFin coincide con los parámetros de entrada.
     */
    List<Producto> findByAmount(Integer cantidadInicio,
                                Integer cantidadFin);

    /**
     * Método que encuentra la lista de Productos cuyo Atributo Precio es el que se introduce
     * por parámetro.
     *
     * @param precioInicio  sobre la que se realizará la consulta
     * @param precioFin Final sobre la que se realizará la consulta
     * @return Lista de Producto cuyo PrecioInicio y PrecioFinb coincide con los parámetros de entrada.
     */
    List<Producto> findByPrice(Double precioInicio,
                               Double precioFin);

    /**
     * Método que encuentra la lista de Productos cuyo Atributo Iva es el que se introduce
     *      * por parámetro.
     *
     * @param ivaInicio  sobre la que se realizará la consulta
     * @param ivaFin Final sobre la que se realizará la consulta
     * @return Lista de Producto cuyo IvaInicio e IvaFin coincide con los parámetros de entrada.
     */
    List<Producto> findByIva(Integer ivaInicio,
                             Integer ivaFin);

    /**
     * Método que encuentra la lista de Productos cuyo Atributo Observaciones contenga
     * las Observaciones o cadena de caracteres que se introduce por parámetro.
     *
     * @param PObservaciones Observaciones sobre la que se realizará la consulta.
     * @return Lista de Producto  cuyas Observaciones contenga con el parámetro de entrada.
     */
    List<Producto> findByRemarks(String PObservaciones);

    /**
     * Método que encuentra la lista de Productos cuyo Atributo Familia Producto es el que se introduce por parámetro.
     *
     * @param familiaProducto  Familia de Producto sobre el que se realizará la consulta.
     * @return Lista de Producto cuya Familia Producto coincide con el parámetro de entrada.
     */
    List<Producto> findByFamily(Long familiaProducto);


    /**
     * Método que Guarda la información del Producto que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PProducto Entidad Producto que se desea almacenar.
     * @return Producto con los datos que han sido guardados en la Base de Datos
     */
    Producto save(Producto PProducto);

    /**
     * Método que Guarda los cambios de la información del Producto e que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador de la Entidad Producto que se desea Actualizar.
     * @param PProducto Entidad Producto  que se desea Actualizar.
     * @return Producto con los datos que han sido guardados en la Base de Datos
     */
    Producto update(Long PId, Producto PProducto);

    /**
     * Método que Actualiza la Cantidad de Uniddes del Producto cuyo Id se introduce por parámetro
     *
     * @param PId Identificador de la Entidad Producto que se desea Actualizar.
     * @param PUnidades Unidades que se le sumarán a la cantidad de existencias del producto
     * @return Producto que se ha actualizado
     */
    Producto updateStorage(Long PId,Integer PUnidades);

    /**
     * Método que elimina el Producto que se introduce por parámetro de la Base de Datos
     *
     * @param PId Identificador del Producto  que se desea Eliminar.
     */
    boolean delete(Long PId);

}
