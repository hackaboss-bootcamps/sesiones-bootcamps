package com.grupo2.aap.Service.Seguridad;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Seguridad.Empleado;
import com.grupo2.aap.Entity.Ventas.Cliente;
import com.grupo2.aap.IRepository.Seguridad.IEmpleadoRepository;
import com.grupo2.aap.Iservice.Seguridad.IEmpleadoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que contiene el Servicio de sobre el Repositorio de Empleados
 *
 * */
@Service
public class EmpleadoService implements IEmpleadoService {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Repositorio de Empleados*/
    @Autowired
    private IEmpleadoRepository repository;

    /** Sistema de Control de la Seguridad que controlará los accesos por parte de los usuarios y
     * las actividades realizadas por los mismos */
    private SecurityCtrl securityCtrl;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos para el Control de la Seguridad">


    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    @Override
    public void setSecurityCtrl(SecurityCtrl securityCtrl) {
        this.securityCtrl = securityCtrl;
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Consultas">

    /**
     * Método que devuelve el empleados cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador del empleado del que se quiere obtener la información
     * @return Empleado que cumple con los requisitos de búsqueda.
     */
    @Override
    public Optional<Empleado> findById(Long PId) {
        Optional<Empleado> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion=repository.findById(PId);
        }else{
            VDevolucion=null;
        }
        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de empleados cuyo Atributo nombre contenga
     * el nombre o cadena de caracteres que se introduce por parámetro.
     *
     * @param PNombreEmpleado Nombre del empleado sobre el que se realizará la consulta.
     * @return Lista de Empleados cuyo Nombre contenga con el parámetro de entrada.
     */
    @Override
    public List<Empleado> findListByName(String PNombreEmpleado) {
        List<Empleado> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion=repository.findListByName(PNombreEmpleado);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de empleados cuyo Atributo dirección contenga
     * la dirección o cadena de caracteres que se introduce por parámetro.
     *
     * @param PDireccion Dirección del empleado sobre el que se realizará la consulta.
     * @return Lista de Empleados cuya Dirección contenga con el parámetro de entrada.
     */
    @Override
    public List<Empleado> findListByAddress(String PDireccion) {
        List<Empleado> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion=repository.findListByAddress(PDireccion);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de empleados cuyo Atributo provincia contenga
     * la provincia o cadena de caracteres que se introduce por parámetro.
     *
     * @param PProvince Provincia del empleado sobre el que se realizará la consulta.
     * @return Lista de empleados cuya provincia contenga con el parámetro de entrada.
     */
    @Override
    public List<Empleado> findListByProvince(String PProvince) {
        List<Empleado> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion=repository.findListByProvince(PProvince);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de empleados cuyo Atributo poblacion contenga
     * la Poblacion o cadena de caracteres que se introduce por parámetro.
     *
     * @param PTown Poblacion del empleado sobre el que se realizará la consulta.
     * @return Lista de empleados cuya poblacion contenga con el parámetro de entrada.
     */
    @Override
    public List<Empleado> findListByTown(String PTown) {
        List<Empleado> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion=repository.findListByTown(PTown);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de empleados cuyo Atributo Codigo Postal contenga
     * el Codigo Postal o cadena de caracteres que se introduce por parámetro.
     *
     * @param PPostalCode Codigo Postal del empleado sobre el que se realizará la consulta.
     * @return Lista de Empleados cuyo Codigo Postal contenga con el parámetro de entrada.
     */
    @Override
    public List<Empleado> findListByPostalCode(String PPostalCode) {
        List<Empleado> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion=repository.findListByPostalCode(PPostalCode);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de empleados cuyo Atributo email contenga
     * el email o cadena de caracteres que se introduce por parámetro.
     *
     * @param PEMail EMail del empleado sobre el que se realizará la consulta.
     * @return Lista de empleados cuyo EMail contenga con el parámetro de entrada.
     */
    @Override
    public List<Empleado> findListByEMail(String PEMail) {
        List<Empleado> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion=repository.findListByEmail(PEMail);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de la Persistencia">

    /**
     * Método que Guarda la información del Empleado que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PEmpleado Entidad Empleado que se desea almacenar.
     * @return Empleado con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public Empleado save(Empleado PEmpleado) {
        Empleado VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion=repository.save(PEmpleado);
        }else{
            VDevolucion=null;
        }
        return VDevolucion;
    }

    /**
     * Método que Guarda los cambios de la información del empleado que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador de la Entidad Empleado que se desea Actualizar.
     * @param PEmpleado Entidad Empleado que se desea Actualizar.
     * @return Empleado con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public Empleado update(Long PId, Empleado PEmpleado) {
        Empleado VDevolucion;
        Optional<Empleado> VEmpleado;

        try{
            if (this.securityCtrl.isAdministrator()){
                VEmpleado = repository.findById(PId);

                if(!VEmpleado.isEmpty()){
                    PEmpleado.setId(VEmpleado.get().getId());

                    VDevolucion=repository.save(PEmpleado);
                }else{
                    VDevolucion=null;
                }
            }else{
                VDevolucion = null;
            }
        }catch (Exception ex){
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que elimina el Empleado que se introduce por parámetro de la Base de Datos
     *
     * @param PId Identificador del Empleado que se desea Eliminar.
     * @return Si se ha realizado correctamente la operación o no
     */
    @Override
    public boolean delete(Long PId) {
        boolean VDevolucion;
        Optional<Empleado> VEmpleado;

        if (this.securityCtrl.isAdministrator()){
            VEmpleado = this.findById(PId);

            if (!VEmpleado.isEmpty()){
                VEmpleado.get().setFechaEliminacion(LocalDateTime.now());
                VDevolucion = (this.save(VEmpleado.get())!=null);
            }else{
                VDevolucion = false;
            }
        }else{
            VDevolucion=false;
        }

        return VDevolucion;
    }

// </editor-fold>


}
