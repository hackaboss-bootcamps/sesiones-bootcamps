package com.grupo2.aap.Service.Ventas;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Ventas.FacturaSimplificada;
import com.grupo2.aap.Entity.Ventas.FacturaSimplificadaExtendida;
import com.grupo2.aap.IRepository.Ventas.IFacturaSimplificadaRepository;
import com.grupo2.aap.Iservice.Ventas.IDetalleFacturaSimplificadaService;
import com.grupo2.aap.Iservice.Ventas.IFacturaSimplificadaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que contiene el Servicio de sobre el Repositorio Detalles de Facturas
 *
 * */
@Service
public class FacturaSimplificadaService implements IFacturaSimplificadaService {

    /** Repositorio de Factura Simplificada*/
    @Autowired
    private IFacturaSimplificadaRepository repository;

    /** Servicio de Detalle de Factura Simplificada*/
    @Autowired
    private IDetalleFacturaSimplificadaService detalleFacturaSimplificadaService;


    /** Sistema de Control de la Seguridad que controlará los accesos por parte de los usuarios y
     * las actividades realizadas por los mismos */
    private SecurityCtrl securityCtrl;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Consultas">

    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    @Override
    public void setSecurityCtrl(SecurityCtrl securityCtrl) {
        this.securityCtrl = securityCtrl;
    }

    /**
     * Método que devuelve todas las Facturas Simplificadas de la Base de Datos
     *
     * @return Lista de Facturas Simplificadas de la Base de Datos
     */
    @Override
    public List<FacturaSimplificada> all() {
        return repository.findAll();
    }

    /**
     * Método que devuelve la factura simplificada cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador de la factura simplificada  de la que se quiere obtener la información
     * @return Factura Simplificada que cumple con los requisitos de búsqueda.
     */
    @Override
    public Optional<FacturaSimplificada> findById(Long PId) {
        return repository.findById(PId);
    }

    /**
     * Método que encuentra la lista de facturas simplificadas cuyo Atributo Número es el que se introduce
     * por parámetro.
     *
     * @param PNumero Número sobre el que se realizará la consulta.
     * @return Lista de Facturas Simplificadas cuyo Número coincide con el parámetro de entrada.
     */
    @Override
    public List<FacturaSimplificada> findListByNumber(Long PNumero) {
        return this.repository.findListByNumber(PNumero);
    }

    /**
     * Método que encuentra la lista de facturas simplificadas cuyo Atributo Fecha es el que se introduce
     * por parámetro.
     *
     * @param PFechaInicio Fecha Inicial sobre la que se realizará la consulta
     * @param PFechaFin Fecha Final sobre la que se realizará la consulta
     * @return Lista de Facturas Simplificadas cuya FechaInicio y FechaFin coincide con los parámetros de entrada.
     */
    @Override
    public List<FacturaSimplificada> findByDate(LocalDateTime PFechaInicio, LocalDateTime PFechaFin) {
        return this.repository.findByDate(PFechaInicio,PFechaFin);
    }

    /**
     * Método que encuentra la lista de facturas simplificadas cuyo Atributo Forma de Pago es el que se introduce
     * por parámetro.
     *
     * @param PFormaPago Forma de Pago sobre la que se realizará la consulta.
     * @return Lista de Facturas Simplificadas  cuya Forma de Pago coincide con el parámetro de entrada.
     */
    @Override
    public List<FacturaSimplificada> findByWay2Pay(Long PFormaPago) {
        return this.repository.findByFormaWay2Pay(PFormaPago);
    }

    /**
     * Método que encuentra la lista de facturas simplificadas cuyo Atributo Observaciones contenga
     * las Observaciones o cadena de caracteres que se introduce por parámetro.
     *
     * @param PObservaciones Observaciones sobre la que se realizará la consulta.
     * @return Lista de Facturas Simplificadas  cuyas Observaciones contenga con el parámetro de entrada.
     */
    @Override
    public List<FacturaSimplificada> findByRemarks(String PObservaciones) {
        return this.repository.findByRemarks(PObservaciones);
    }

    /**
     * Método que devuelve la FacturaSimplificadaExtendida cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador de la factura de la que se quiere obtener la información
     * @return Factura Extendida que cumple con los requisitos de búsqueda.
     */
    @Override
    public FacturaSimplificadaExtendida findExtInvoiceById(Long PId) {
        FacturaSimplificadaExtendida VDevolucion;
        Optional<FacturaSimplificada> VFactura;

        try{
            VFactura=this.repository.findById(PId);
            if (!VFactura.isEmpty()){
                VDevolucion=new FacturaSimplificadaExtendida(VFactura.get(),
                                                            this.detalleFacturaSimplificadaService);
            }else{
                VDevolucion=null;
            }

        }catch (Exception ex){
            VDevolucion=null;
        }


        return VDevolucion;
    }

    /**
     * Método que Guarda la información de la Factura Simplificada que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PFacturaSimplificada Entidad FacturaSimplificada que se desea almacenar.
     * @return FacturaSimplifica con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public FacturaSimplificada save(FacturaSimplificada PFacturaSimplificada) {
        FacturaSimplificada VDevolucion;

        try{
            if (PFacturaSimplificada.getFecha()==null){
                PFacturaSimplificada.setFecha(LocalDateTime.now());
            }
            VDevolucion=repository.save(PFacturaSimplificada);
        }catch (Exception ex){
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que Guarda los cambios de la información de la Factura Simplificada e que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador de la Entidad FacturaSimplificada que se desea Actualizar.
     * @param PFacturaSimplificada Entidad FacturaSimplificada que se desea Actualizar.
     * @return FacturaSimplificada con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public FacturaSimplificada update(Long PId, FacturaSimplificada PFacturaSimplificada) {
        FacturaSimplificada VDevolucion;
        FacturaSimplificada VFacturaActualizada = new FacturaSimplificada();
        Optional<FacturaSimplificada> VFactura;

        try{
            VFactura = repository.findById(PId);

            if(!VFactura.isEmpty()){

                VFacturaActualizada.clone(PFacturaSimplificada);
                VFacturaActualizada.setId(VFactura.get().getId());

                VDevolucion=repository.save(VFacturaActualizada);
            }else{
                VDevolucion=null;
            }
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    /**
     * Método que elimina la Factura Simplificada que se introduce por parámetro de la Base de Datos
     *
     * @param PId Identificador de la Factura Simplificada que se desea Eliminar.
     */
    @Override
    public boolean delete(Long PId) {
        boolean VDevolucion;
        Optional<FacturaSimplificada> VFactura;

        try {
            VFactura = repository.findById(PId);

            if (!VFactura.isEmpty()){

                VFactura.get().setFechaAnulacion(LocalDateTime.now());
                VDevolucion=(this.save(VFactura.get())!=null);
            }else{
                VDevolucion=false;
            }
        }catch (Exception ex){
            VDevolucion=false;
        }

        return VDevolucion;
    }

    /**
     * Método que Genera una factura Simplificada en función del Objeto que se introduce por parámetro
     *
     * @param PFactura Objeto Factura Simplificada que contiene los datos de la Nueva Factura
     * @return Imagen de la factura Simplificada que se ha dado de alta en la Capa de Persistencia
     */
    @Override
    public FacturaSimplificada generarFactura(FacturaSimplificada PFactura){
        Long VNumeroFactura;
        FacturaSimplificada VFactura = new FacturaSimplificada();
        FacturaSimplificada VDevolucion;

        try{
            VNumeroFactura = repository.findInvoiceNextNumber();
            PFactura.setNumero(VNumeroFactura);

            VDevolucion=this.save(PFactura);

        }catch (Exception ex){
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que Genera una factura Simplificada Extendida en función del Objeto que se introduce por parámetro
     *
     * @param PFactura Objeto Factura Simplificada Extendida que contiene los datos de la Nueva Factura
     * @return Imagen de la factura Simplificada Extendida que se ha dado de alta en la Capa de Persistencia
     */
    @Override
    public boolean generarFactura(FacturaSimplificadaExtendida PFactura){
        Long VNumeroFactura;
        boolean VDevolucion;

        try{
            VNumeroFactura = repository.findInvoiceNextNumber();
            PFactura.setNumero(VNumeroFactura);
            PFactura.setServices(this,
                                    this.detalleFacturaSimplificadaService);

            VDevolucion=PFactura.save();

        }catch (Exception ex){
            VDevolucion = false;
        }

        return VDevolucion;
    }


}
