package com.grupo2.aap.IRepository.Seguridad.MestrasSeguridad;

import com.grupo2.aap.Entity.Seguridad.MaestrasSeguridad.LogOperaciones;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que permite la ejecución de las cláusulas SQL necesarias para servir de repositorio de
 * la entidad LogOperacion
 * */
public interface ILogOperacionRepository extends JpaRepository<LogOperaciones,Long> {

    /**
     * Método que encuentra la lista de Operaciones que se pueden registrar en los LOGS
     *
     * @return Lista de Operaciones que se pueden registrar en los logs
     */
    @Query(value = "SELECT  * " +
            "FROM LogOperacion " +
            "WHERE nombre LIKE %:nombre% ", nativeQuery = true)
    List<LogOperaciones> findListByName(@Param("nombre") String PNombre);
}
