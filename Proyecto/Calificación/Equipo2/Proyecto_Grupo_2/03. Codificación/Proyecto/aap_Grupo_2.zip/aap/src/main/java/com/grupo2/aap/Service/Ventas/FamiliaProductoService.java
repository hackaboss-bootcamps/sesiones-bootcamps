package com.grupo2.aap.Service.Ventas;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Ventas.FamiliaProducto;
import com.grupo2.aap.Iservice.Ventas.IFamiliaProductoService;
import com.grupo2.aap.IRepository.Ventas.IFamiliaProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que contiene el Servicio de sobre el Servicio de Familia de Productos
 *
 * */
@Service
public class FamiliaProductoService implements IFamiliaProductoService {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Repositorio de Familias de Producto*/
    @Autowired
    private IFamiliaProductoRepository repository;

    /** Sistema de Control de la Seguridad que controlará los accesos por parte de los usuarios y
     * las actividades realizadas por los mismos */
    private SecurityCtrl securityCtrl;


// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Encapsulamiento">

    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    @Override
    public void setSecurityCtrl(SecurityCtrl securityCtrl) {
        this.securityCtrl = securityCtrl;
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Consultas">

    /**
     * Método que devuelve la familia producto cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador de la familia producto de la que se quiere obtener la información
     * @return Familia Producto que cumple con los requisitos de búsqueda.
     */
    @Override
    public Optional<FamiliaProducto> findById(Long PId) {
        return repository.findById(PId);
    }

    /**
     * Método que encuentra la lista familia productos cuyo Atributo Nombre contenga
     * el Nombre o cadena de caracteres que se introduce por parámetro.
     *
     * @param PNombre Nombre de la familia de producto sobre el que se realizará la consulta.
     * @return Lista de Familias de  Productos cuyo nombre contenga con el parámetro de entrada.
     */
    @Override
    public List<FamiliaProducto> findListByName(String PNombre) {
        return this.repository.findListByName(PNombre);
    }

    /**
     * Método que encuentra la lista familia productos cuyo Atributo FamiliaPadre es el que se introduce
     *por parámetro.
     *
     * @param PFamilia de la familia de producto sobre el que se realizará la consulta.
     * @return Lista de Familias de  Productos cuyo familia producto coincide con el parámetro de entrada.
     */
    @Override
    public List<FamiliaProducto> findListByFamily(Long PFamilia) {
        return this.repository.findListByFamily(PFamilia);
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de Datos">

    /**
     * Método que Guarda la información de la Familia Producto que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PFamiliaProducto Entidad FamiliaProducto que se desea almacenar.
     * @return FamiliaProduct con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public FamiliaProducto save(FamiliaProducto PFamiliaProducto) {

        return repository.save(PFamiliaProducto);
    }

    /**
     * Método que Guarda los cambios de la información de la FamiliaProducto e que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador de la Entidad FamiliaProducto que se desea Actualizar.
     * @param PFamiliaProducto Entidad FamiliaProducto que se desea Actualizar.
     * @return FamiliaProducto con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public FamiliaProducto update(Long PId, FamiliaProducto PFamiliaProducto) {

        FamiliaProducto VDevolucion;
        Optional<FamiliaProducto> VFamiliaProducto;

        try{
            VFamiliaProducto = repository.findById(PId);

            if(!VFamiliaProducto.isEmpty()){
                PFamiliaProducto.setId(VFamiliaProducto.get().getId());

                VDevolucion = repository.save(PFamiliaProducto);
            }else{
                VDevolucion =null;
            }
        }catch (Exception ex){
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que elimina la Familia Producto que se introduce por parámetro de la Base de Datos
     *
     * @param PId Identificador de la FamiliaProducto a que se desea Eliminar.
     * @return Sí se ha realizado correctamente la operación o no
     */
    @Override
    public boolean delete(Long PId) {
        boolean VDevolucion;
        Optional<FamiliaProducto> VFamilia;

        if (this.securityCtrl.isAdministrator()){
            VFamilia = this.findById(PId);

            if (!VFamilia.isEmpty()){
                VFamilia.get().setFechaEliminacion(LocalDateTime.now());
                VDevolucion = (this.save(VFamilia.get())!=null);
            }else{
                VDevolucion=false;
            }
        }else{
            VDevolucion=false;
        }

        return VDevolucion;
    }

// </editor-fold>

}
