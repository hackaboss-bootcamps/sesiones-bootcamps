package com.grupo2.aap.Entity.Fidelizacion;

import com.grupo2.aap.Entity.Ventas.Factura;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que implementa la Entidad Participacion. Esta clase contendrá la información básica y las operaciones
 * Básicas con dicha información.
 *
 * */
@Entity
@Table (name = "participaciones")
public class Participacion {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Id de la Entidad */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    /** Número de Participación*/
    @Column (name = "numero",nullable = false)
    private int numero;

    /** Fecha de Generación de la Participación */
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "factura_generacion", nullable = false)
    private Factura facturaGeneracion;

    /** Factura en la que se aplica la participación premiada */
    @ManyToOne(fetch = FetchType.EAGER, optional = true)
    @JoinColumn(name = "factura_aplicacion", nullable = true)
    private Factura facturaAplicacion;

    /** Sorteo al que pertenece la participación */
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "sorteo", nullable = false)
    private Sorteo sorteo;

    /** Fecha en la que se guarda la fecha máxima en la que se puede cobrar.
     * En caso de que no sea premiada permanecerá a NULL */
    @Column (name = "fecha_max_validez",nullable = true)
    private LocalDate fechaMaxValidez;

    /** Fecha de anulación de la Participación */
    @Column (name = "fecha_anulacion",nullable = true)
    private LocalDateTime fechaAnulacion;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Encapsulamiento">

    /**
     * Método que Devuelve el Id de la Participación.
     *
     * @return Id de la Participación.
     */
    public long getId() {
        return id;
    }

    /**
     * Método que Introduce el Id de la Participación.
     *
     * @param id de la Participación.
     *
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * Método que Devuelve el Numero de la Participación.
     *
     * @return Numero de la Participación.
     */
    public int getNumero() {
        return numero;
    }

    /**
     * Método que Introduce el número de la Participación.
     *
     * @param numero de la Participación.
     *
     */
    public void setNumero(int numero) {
        this.numero = numero;
    }

    /**
     * Método que Devuelve la Factura que ha generado la Participación.
     *
     * @return Factura de Generación de la Participación.
     */
    public Factura getFacturaGeneracion() {
        return facturaGeneracion;
    }

    /**
     * Método que Introduce la Factura que generó la Participación.
     *
     * @param facturaGeneracion de la Participación.
     *
     */
    public void setFacturaGeneracion(Factura facturaGeneracion) {
        this.facturaGeneracion = facturaGeneracion;
    }

    /**
     * Método que Devuelve la Factura en la que se ha aplicado la Participación.
     *
     * @return Factura de Aplicación de la Participación.
     */
    public Factura getFacturaAplicacion() {
        return facturaAplicacion;
    }

    /**
     * Método que Introduce la Factura que aplicó la Participación.
     *
     * @param facturaAplicacion de la Participación.
     *
     */
    public void setFacturaAplicacion(Factura facturaAplicacion) {
        this.facturaAplicacion = facturaAplicacion;
    }

    /**
     * Método que Devuelve el Sorteo de la Participación.
     *
     * @return Sorteo de la Participación.
     */
    public Sorteo getSorteo() {
        return sorteo;
    }

    /**
     * Método que Introduce el Sorteo de la Participación.
     *
     * @param sorteo de la Participación.
     *
     */
    public void setSorteo(Sorteo sorteo) {
        this.sorteo = sorteo;
    }

    /**
     * Método que Devuelve la Fecha máxima de validez de la Participación.
     *
     * @return Fecha Máxima de Validez de la Participación.
     */
    public LocalDate getFechaMaxValidez() {
        return fechaMaxValidez;
    }

    /**
     * Método que Introduce la Fecha máxima de Validez para cobrar la Participación.
     *
     * @param fechaMaxValidez de la Participación.
     *
     */
    public void setFechaMaxValidez(LocalDate fechaMaxValidez) {
        this.fechaMaxValidez = fechaMaxValidez;
    }

    /**
     * Método que Devuelve la Fecha de Anulación de la Participación.
     *
     * @return Fecha de Anulación de la Participación.
     */
    public LocalDateTime getFechaAnulacion() {
        return fechaAnulacion;
    }

    /**
     * Método que Introduce la Fecha Anulación la Participación.
     *
     * @param fechaAnulacion de la Participación.
     *
     */
    public void setFechaAnulacion(LocalDateTime fechaAnulacion) {
        this.fechaAnulacion = fechaAnulacion;
    }

    /**
     * Método que Devuelve si la Participación ha resultado ganadora o no
     *
     * @return si/no Ganadora.
     */
    public boolean getGanadora(){
        return (this.fechaMaxValidez!=null);
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de Datos">

    /**
     * Método que Clona la información de otra entidad participación en sí misma.
     *
     * @param PParticipacionClonar Participación cuyos parámetros se desean clonar
     * @return Sí se ha realizado correctamente o no la operación.
     */
    public boolean clone(Participacion PParticipacionClonar){
        boolean VDevolucion;

        try{
            this.setId(PParticipacionClonar.getId());
            this.setNumero(PParticipacionClonar.getNumero());
            this.setFacturaGeneracion(PParticipacionClonar.getFacturaGeneracion());
            this.setFacturaAplicacion(PParticipacionClonar.getFacturaAplicacion());
            this.setSorteo(PParticipacionClonar.getSorteo());
            this.setFechaMaxValidez(PParticipacionClonar.getFechaMaxValidez());
            this.setFechaAnulacion(PParticipacionClonar.getFechaAnulacion());
            VDevolucion = true;

        }catch (Exception ex){
            VDevolucion = false;
        }

        return VDevolucion;
    }

// </editor-fold>

}
