
package com.grupo2.aap.Service.Fidelizacion;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Fidelizacion.Participacion;
import com.grupo2.aap.Entity.Fidelizacion.Sorteo;
import com.grupo2.aap.Entity.Ventas.Cliente;
import com.grupo2.aap.Entity.Ventas.Factura;
import com.grupo2.aap.IRepository.Fidelizacion.IParticipacionRepository;
import com.grupo2.aap.Iservice.Fidelizacion.IParticipacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que contiene el Servicio de sobre el Repositorio Participaciones
 *
 * */

@Service
public class ParticipacionService implements IParticipacionService {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Repositorio de Partipicpaciones */
    @Autowired
    private IParticipacionRepository repository;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos para el Control de la Seguridad">

    /** Sistema de Control de la Seguridad que controlará los accesos por parte de los usuarios y
     * las actividades realizadas por los mismos */
    private SecurityCtrl securityCtrl;


    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    @Override
    public void setSecurityCtrl(SecurityCtrl securityCtrl) {
        this.securityCtrl = securityCtrl;
    }


// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Consultas">

    /**
     * Método que devuelve todos los Sorteos de la Base de Datos
     *
     * @return Lista de Sorteos de la Base de Datos
     */
    @Override
     public List<Participacion> all() { return repository.findAll();}

    /**
     * Método que devuelve la Participación cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador de la Participación del que se quiere obtener la información
     * @return PArticipación que cumple con los requisitos de búsqueda.
     */
    @Override
    public Optional<Participacion> findById(Long PId) {
        return repository.findById(PId);
    }

    /**
     * Método que encuentra la lista de Participaciones que tengan como número el
     * que se introduce par parámetro
     *
     * @param PNumero Número de la Participación sobre el que se realizará la consulta.
     * @return Lista de Participaciones con el número introducido
     */
    @Override
    public List<Participacion> findByNumber(Integer PNumero) {
        return repository.findByNumber(PNumero);
    }

    /**
     * Método que encuentra la lista de Participaciones que se hayan aplicado a la factura que se
     * introduce por parámetro
     *
     * @param PIdFactura Identificador de la Factura sobre la que se aplicó la Participación
     * @return Lista de Participaciones que se han aplicado a la Factura introducida
     */
    @Override
    public List<Participacion> findByApplicationInvoice(Long PIdFactura) {
        return repository.findByApplicationInvoice(PIdFactura);
    }

    /**
     * Método que encuentra la lista de Participaciones que se hayan generadas por la factura introducida
     *
     * @param PIdFactura Identificador de la Factura que generó las participaciones
     * @return Lista de Participaciones que se han Generadas por la Factura introducida
     */
    @Override
    public List<Participacion> findByGenerationInvoice(Long PIdFactura) {
        return repository.findByGenerationInvoice(PIdFactura);
    }

    /**
     * Método que encuentra la lista de Participaciones que son válidas entre las fechas que se introducen
     * por parámetro
     *
     * @param PFechaInicio Fecha de Acotación inicial del intervalo de tiempo
     * @param PFechaFin Fecha de Acotación final del intervalo de tiempo
     * @return Lista de Participaciones que son válidas en el intervalo de tiempo introducido
     */
    @Override
    public List<Participacion> findByMaxValidityDate(LocalDateTime PFechaInicio,LocalDateTime PFechaFin) {
        return repository.findByMaxValidityDate(PFechaInicio,PFechaFin);
    }

    /**
     * Método que encuentra la lista de Participaciones que han sido candeladas entre las fechas que se introducen
     * por parámetro
     *
     * @param PFechaInicio Fecha de Acotación inicial del intervalo de tiempo
     * @param PFechaFin Fecha de Acotación final del intervalo de tiempo
     * @return Lista de Participaciones que han sido canceladas en el intervalo de tiempo introducido
     */
    @Override
    public List<Participacion> findByCancelDate(LocalDateTime PFechaInicio,LocalDateTime PFechaFin) {
        return repository.findByCancelDate(PFechaInicio,PFechaFin);
    }

    /**
     * Método que encuentra la lista de Participaciones del Sorteo que se introduce por parámetro
     *
     * @param PSorteo Sorteo del que se quiere saber la lista de participaciones
     * @return Lista de Participaciones del sorteo introducido
     */
    @Override
    public List<Participacion> findByDraw(Long PSorteo){
        return repository.findByDraw(PSorteo);
    }

    /**
     * Método que encuentra la lista de Participaciones ganadoras del sorteo introducido.
     *
     * @param PSorteo Sorteo del que se quiere saber la lista de participaciones ganadoras
     * @return Lista de Participaciones ganadoras del sorteo introducido
     */
    @Override
    public List<Participacion> findByWinnersDraw(Long PSorteo){
        return repository.findByWinnersDraw(PSorteo);
    }


// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de la Persistencia">

    /**
     * Método que Marca como premiada la participación que se introduce por parámetro
     *
     * @param PParticipacion Participación que va a ser marcada como ganadora
     * @param PFechaMaxValidez Fecha máxima en la que se puede hacer efectiva la participación
     * @return Si se ha realizado correctamente la operación o no
     */
    @Override
    public boolean premiar(Participacion PParticipacion, LocalDate PFechaMaxValidez) {
        boolean VDevolucion;
        Participacion VParticipacion;
        Integer VNuevoNumero;

        try{
            if (PParticipacion!=null){
                PParticipacion.setFechaMaxValidez(PFechaMaxValidez);
                VDevolucion=(this.save(PParticipacion)!=null);
            }else{
                VDevolucion=false;
            }


        }catch (Exception ex){
            VDevolucion=false;
        }

        return VDevolucion;
    }

    /**
     * Método que genera una participación del sorteo que se introduce por parámetro y que relaciona
     * con la factura introducida
     *
     * @param PSorteo Sorteo al que debe pertenecer la Participación
     * @param PFacturaGeneracion Factura por la cual se ha generado la participacióny a la cual queda viculada
     * @return PArticipación válida para el sorteo introducido
     */
    @Override
    public Participacion generar(Sorteo PSorteo, Factura PFacturaGeneracion) {
        Participacion VDevolucion;
        Participacion VParticipacion;
        Integer VNuevoNumero;

        try{
            VNuevoNumero=repository.findNewNumber(PSorteo.getId());

            VParticipacion=new Participacion();
            VParticipacion.setNumero(VNuevoNumero);
            VParticipacion.setSorteo(PSorteo);
            VParticipacion.setFacturaGeneracion(PFacturaGeneracion);

            VDevolucion=this.save(VParticipacion);

        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    /**
     * Método que Guarda la información de la participación que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PParticipacion Participación que se desea guardar
     * @return Participacion con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public Participacion save(Participacion PParticipacion) {
        Participacion VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion=repository.save(PParticipacion);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

    /**
     * Método que Guarda los cambios de la información de la Participación que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador de la Entidad Participación que se desea Actualizar.
     * @param PParticipacion Entidad Participación que se desea Actualizar.
     * @return Sorteo con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public Participacion update(Long PId, Participacion PParticipacion) {
        Participacion VDevolucion;
        Optional<Participacion> VParticipacion;

        try{
            if (this.securityCtrl.isAdministrator()){
                VParticipacion = repository.findById(PId);

                if(!VParticipacion.isEmpty()){
                    PParticipacion.setId(VParticipacion.get().getId());

                    VDevolucion = repository.save(PParticipacion);
                }else{
                    VDevolucion =null;
                }

            }else{
                VDevolucion=null;
            }
        }catch (Exception ex){
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que cancela la participación que se introduce por parámetro de la Base de Datos
     *
     * @param PId Identificador de la participación que se desea cancelar.
     * @return Sí se ha realizado o no correctamente la operacion
     */
    @Override
    public boolean delete(Long PId) {
        boolean VDevolucion;
        Optional<Participacion> VParticipacion;

        if (this.securityCtrl.isAdministrator()){
            VParticipacion = this.findById(PId);

            if (!VParticipacion.isEmpty()){
                VParticipacion.get().setFechaAnulacion(LocalDateTime.now());
                VDevolucion = (this.save(VParticipacion.get())!=null);
            }else{
                VDevolucion=false;
            }
        }else{
            VDevolucion=false;
        }

        return VDevolucion;
    }

// </editor-fold>

}

