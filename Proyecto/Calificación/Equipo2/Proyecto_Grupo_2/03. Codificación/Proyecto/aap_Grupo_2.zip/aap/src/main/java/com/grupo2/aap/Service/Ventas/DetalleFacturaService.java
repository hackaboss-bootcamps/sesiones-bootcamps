package com.grupo2.aap.Service.Ventas;

import com.grupo2.aap.Entity.Ventas.DetalleFactura;
import com.grupo2.aap.IRepository.Ventas.IDetalleFacturaRepository;
import com.grupo2.aap.Iservice.Ventas.IDetalleFacturaService;
import com.grupo2.aap.Iservice.Ventas.IProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que contiene el Servicio de sobre el Repositorio Detalles de Facturas
 *
 * */
@Service
public class DetalleFacturaService implements IDetalleFacturaService {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Repositorio de Detalles de Factura*/
    @Autowired
    private IDetalleFacturaRepository repository;

    /** Servicio de Productos*/
    @Autowired
    private IProductoService productService;


// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Consultas">

    /**
     * Método que devuelve todos los Detalles de Factura de la Base de Datos.
     *
     * @return Lista de Detalle de Factura de la Base de Datos.
     */
    @Override
    public List<DetalleFactura> all() {
        return repository.findAll();
    }

    /**
     * Método que devuelve el Detalle de Factura cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador del Detalle de Factura del que se quiere obtener la información.
     * @return Lista de Detalle de Factura que cumple con los requisitos de búsqueda.
     */
    @Override
    public Optional<DetalleFactura> findById(Long PId) {
        return repository.findById(PId);
    }

    /**
     * Método que encuentra la lista de detalle factura cuyo Identificador de Factura es la que se introduce
     * por parámetro.
     *
     * @param PIdFactura Identificador de la Factura sobre la que se realizará la consulta.
     * @return Lista de Detalles De Factura cuyo Detalle de Factura coincide con el parámetro de entrada.
     */
    @Override
    public List<DetalleFactura> findByInvoice(Long PIdFactura) {
        return this.repository.findListByInvoice(PIdFactura);
    }

    /**
     * Método que encuentra la lista de detalles factura cuyo Atributo Producto es el que se introduce
     * por parámetro.
     *
     * @param PProducto Producto sobre la que se realizará la consulta.
     * @return Lista de Detalle De Factura cuyo Producto coincide con el parámetro de entrada.
     */
    @Override
    public List<DetalleFactura> findByProduct(Long PProducto) {
        return this.repository.findByProduct(PProducto);
    }

    /**
     * Método que encuentra la lista de detalles factura cuyo Atributo Cantidad es el que se introduce
     * por parámetro.
     *
     * @param PCantidadInicio Cantidad Inicial sobre la que se realizará la consulta.
     * @param PCantidadFin Cantidad Final sobre la que se realizará la consulta.
     * @return Lista de Detalle De Factura cuya CantidadInicio y CantidadFin coincide con los parámetros de entrada.
     */
    @Override
    public List<DetalleFactura> findByAmount(Integer PCantidadInicio, Integer PCantidadFin) {
        return this.repository.findByAmount(PCantidadInicio,PCantidadFin);
    }


// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de Datos">
    /**
     * Método que Guarda la información del Detalle de Factura que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PDetalleFactura Entidad Detalle Factura que se desea Almacenar.
     * @return DetalleFactura con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public DetalleFactura save(DetalleFactura PDetalleFactura) {
        DetalleFactura VDevolucion;

        try{
            VDevolucion=repository.save(PDetalleFactura);
        }catch (Exception ex){
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que Guarda la información de los Detalles de Factura que se introducen por parámetro en la
     * Base de Datos
     *
     * @param detallesFactura Entidades Detalles Factura que se desea Almacenar.
     * @return DetalleFactura con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public List<DetalleFactura> batchSave(List<DetalleFactura> detallesFactura) {
        List<DetalleFactura> VDevolucion = new ArrayList<DetalleFactura>();
        DetalleFactura VDetalleFacturaAux;
        int VIndice;

        try{
            for (VIndice=0;VIndice<detallesFactura.size();VIndice++){
                VDetalleFacturaAux=detallesFactura.get(VIndice);
                this.productService.updateStorage(VDetalleFacturaAux.getProducto().getId(),
                        VDetalleFacturaAux.getCantidad());
                VDevolucion.add(this.save(VDetalleFacturaAux));

            }

        }catch (Exception ex){
            VDevolucion=null;
        }
        return VDevolucion;
    }

    /**
     * Método que Guarda los cambios de la información de Detalle Factura que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador de la Entidad DetalleFactura que se desea Actualizar.
     * @param PDetalleFactura  Entidad DetalleFactura que se desea Actualizar.
     * @return DetalleFactura con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public DetalleFactura update(Long PId, DetalleFactura PDetalleFactura) {
        DetalleFactura VDevolucion;
        DetalleFactura VDetalleFacturaActualizada = new DetalleFactura();
        Optional<DetalleFactura> VDetalleFactura;

        try{
            VDetalleFactura = repository.findById(PId);

            if(!VDetalleFactura.isEmpty()){
                VDetalleFacturaActualizada.clone(PDetalleFactura);
                VDetalleFacturaActualizada.setId(VDetalleFactura.get().getId());

                VDevolucion = repository.save(VDetalleFacturaActualizada);
            }else{
                VDevolucion = null;
            }
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    /**
     * Método que elimina el detalle de factura que se introduce por parámetro de la Base de Datos
     *
     * @param PId Identificador de la Entidad DetalleFactura que se desea Eliminar.
     */
    @Override
    public boolean delete(Long PId) {
        boolean VDevolucion;

        try {
            repository.deleteById(PId);
            VDevolucion=true;
        }catch (Exception ex){
            VDevolucion=false;
        }

        return VDevolucion;
    }

// </editor-fold>

}
