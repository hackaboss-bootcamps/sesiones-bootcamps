package com.grupo2.aap.IRepository.Seguridad.LogsSeguridad;

import com.grupo2.aap.Entity.Seguridad.LogsSeguridad.SecLogAdministracion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que permite la ejecución de las cláusulas SQL necesarias para servir de repositorio de
 * la entidad SecLogAdministracion
 * */
@Repository
public interface ISecLogAdministracionRepository extends JpaRepository<SecLogAdministracion,Long> {

    /**
     * Método que encuentra la lista de sec_log_sorteos cuya operacion es la que se introduce
     * por parámetro.
     *
     * @param POperacion Operacion de sec_log_sorteos sobre la que se realizará la consulta.
     * @return Lista de sec_log_sorteos cuya operacion coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM sec_log_Administracion " +
            "WHERE operacion = :operacion", nativeQuery = true)
    List<SecLogAdministracion> findListByOperation(@Param("operacion") Long POperacion);

    /**
     * Método que encuentra la lista de sec_log_sorteos cuyo tipo de entidad es el que se introduce
     * por parámetro.
     *
     * @param PTipoEntidad Tipo de entidad de sec_log_sorteos sobre el que se realizará la consulta.
     * @return Lista de sec_log_sorteos cuyo tipo de entidad coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM sec_log_Administracion " +
            "WHERE tipo_entidad = :tipoEntidad", nativeQuery = true)
    List<SecLogAdministracion> findListByTypeOfEntity(@Param("tipoEntidad") Long PTipoEntidad);

    /**
     * Método que encuentra la lista de sec_log_sorteos cuya entidad es la que se introduce
     * por parámetro.
     *
     * @param PEntidad Entidad de sec_log_sorteos sobre la que se realizará la consulta.
     * @return Lista de sec_log_sorteos cuya entidad coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM sec_log_Administracion " +
            "WHERE entidad = :entidad", nativeQuery = true)
    List<SecLogAdministracion> findListByEntity(@Param("entidad") Long PEntidad);

    /**
     * Método que encuentra la lista de sec_log_sorteos cuya fecha de inicio y fecha final son las que se introducen
     * por parámetro.
     *
     * @param PFechaInicio Fecha inicial de sec_log_sorteos sobre la que se realizará la consulta.
     * @param PFechaFin Fecha final de sec_log_sorteos sobre la que se realizará la consulta.
     * @return Lista de sec_log_sorteos cuyas fechas de inicio y fechas finales coinciden con los parámetros de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM sec_log_Administracion " +
            "WHERE fecha BETWEEN fechaInicio AND fechaFin", nativeQuery = true)
    List<SecLogAdministracion> findByDate(@Param("fechaInicio") LocalDateTime PFechaInicio, @Param("fechaFin") LocalDateTime PFechaFin);

    /**
     * Método que encuentra la lista de sec_log_sorteos cuyo usuario es la que se introduce
     * por parámetro.
     *
     * @param PUsuario Usuario de sec_log_sorteos sobre la que se realizará la consulta.
     * @return Lista de sec_log_sorteos cuyo usuario coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM sec_log_Administracion " +
            "WHERE usuario = :usuario", nativeQuery = true)
    List<SecLogAdministracion> findListByUser(@Param("usuario") Long PUsuario);

    /**
     * Método que encuentra la lista de sec_log_sorteos cuyo mensaje es la que se introduce
     * por parámetro.
     *
     * @param PMensaje Mensaje de sec_log_sorteos sobre el que se realizará la consulta.
     * @return Lista de sec_log_sorteos cuyo mensaje coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM sec_log_Administracion " +
            "WHERE mensaje LIKE %:mensaje%", nativeQuery = true)
    List<SecLogAdministracion> findListByMessage(@Param("mensaje") String PMensaje);


}
