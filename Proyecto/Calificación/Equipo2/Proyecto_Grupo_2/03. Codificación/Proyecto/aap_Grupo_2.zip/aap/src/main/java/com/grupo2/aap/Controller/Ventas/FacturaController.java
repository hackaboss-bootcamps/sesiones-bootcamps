package com.grupo2.aap.Controller.Ventas;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Component.SecuritySession;
import com.grupo2.aap.Entity.Ventas.Cliente;
import com.grupo2.aap.Entity.Ventas.Factura;
import com.grupo2.aap.Entity.Ventas.FacturaExtendida;
import com.grupo2.aap.Entity.Ventas.FacturaSimplificada;
import com.grupo2.aap.Iservice.Ventas.IFacturaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/factura")
public class FacturaController {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    @Autowired
    private IFacturaService service;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos Controladores de Conexión">


    @GetMapping("/ID")
    public Optional<Factura> show(@RequestParam Long id) {
        return service.findById(id);
    }

    @GetMapping("/NU")
    public List<Factura> findByNumber(@RequestParam Long numero) {
        return service.findListByNumber(numero);
    }

    @GetMapping("/FE")
    public List<Factura> findByDate(@RequestParam String fechaInicio,
                                    @RequestParam String fechaFin) {
        List<Factura> VDevolucion;
        DateTimeFormatter VFormateador = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        LocalDateTime VFechaInicio;
        LocalDateTime VFechaFin;

        try{
            fechaInicio=fechaInicio+" 00:00";
            fechaFin=fechaFin+" 00:00";
            VFechaInicio=LocalDateTime.parse(fechaInicio, VFormateador);
            VFechaFin=LocalDateTime.parse(fechaFin, VFormateador);

            VDevolucion=service.findByDate(VFechaInicio,VFechaFin);
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @GetMapping("/FP")
    public List<Factura> findByWay2Way(@RequestParam Long formaPago) {
        return service.findByWay2Pay(formaPago);
    }

    @GetMapping("/OB")
    public List<Factura> findByRemarks(@RequestParam String observaciones) {
        return service.findByRemarks(observaciones);
    }

    @GetMapping("/CL")
    public List<Factura> findByClient(@RequestParam Long idCliente) {
        return service.findByClient(idCliente);
    }

    @GetMapping("/FEXTID")
    public FacturaExtendida findExtInvoiceById(@RequestParam Long id) {
        return service.findExtInvoiceById(id);
    }

    @GetMapping("/APA")
    public FacturaExtendida aplicarParticipacion(@RequestParam Long idFactura,
                                                 @RequestParam Long idParticipacion, HttpSession sesion) {

        FacturaExtendida VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=this.service.aplicarParticipacion(idFactura,idParticipacion);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }


    @PostMapping("/GF")
    @ResponseStatus(code = HttpStatus.CREATED)
    public Factura generarFactura(@RequestBody Factura factura, HttpSession sesion) {
        Factura VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.generarFactura(factura);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @PostMapping("/GFE")
    @ResponseStatus(code = HttpStatus.CREATED)
    public boolean generarFacturaExtendida(@RequestBody FacturaExtendida factura, HttpSession sesion) {
        boolean VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.generarFactura(factura);
        }else{
            VDevolucion=false;
        }

        return VDevolucion;
    }


    @PostMapping("/GFP")
    @ResponseStatus(code = HttpStatus.CREATED)
    public Factura generarFacturaConParticipacion(@RequestBody Factura factura, HttpSession sesion) {
        Factura VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.generarFactura(factura);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @PostMapping("/SA")
    @ResponseStatus(code = HttpStatus.CREATED)
    public Factura save(@RequestBody Factura factura, HttpSession sesion) {
        Factura VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.save(factura);
        }else{
            VDevolucion=null;
        }
        return VDevolucion;
    }

    @PutMapping()
    @ResponseStatus(code = HttpStatus.ACCEPTED)
    public Factura update(@RequestParam Long id, @RequestBody Factura factura, HttpSession sesion) {
        Factura VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.update(id, factura);
        }else{
            VDevolucion=null;
        }
        return VDevolucion;
    }

    @DeleteMapping()
    @ResponseStatus(code = HttpStatus.ACCEPTED)
    public boolean delete(@RequestParam Long id, HttpSession sesion) {
        boolean VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.delete(id);
        }else{
            VDevolucion=false;
        }

        return VDevolucion;
    }
// </editor-fold>

}
