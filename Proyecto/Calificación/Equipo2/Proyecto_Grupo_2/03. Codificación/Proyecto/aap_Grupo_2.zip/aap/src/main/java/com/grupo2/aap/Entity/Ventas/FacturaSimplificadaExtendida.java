package com.grupo2.aap.Entity.Ventas;

import com.grupo2.aap.Iservice.Ventas.IDetalleFacturaSimplificadaService;
import com.grupo2.aap.Iservice.Ventas.IFacturaSimplificadaService;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que implementa una configuración para unir los dotos de la Entidad FacturaSimplificada con los datos de la
 * Entidad DetalleFacturaSimplificada
 *
 * */
public class FacturaSimplificadaExtendida extends FacturaSimplificada {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Servicio de FacturaSimplificada que será usado para el tratamiento de los datos de Facturas*/
    private IFacturaSimplificadaService facturaSimplificadaService;

    /** Servicio de DetalleFacturaSimplificada que será usado para el tratamiento de los datos de los
     * Detalles Facturas Simplificadas*/
    private IDetalleFacturaSimplificadaService detalleFacturaSimplificadaService;

    /** Lista de Detalles de la Factura*/
    List<DetalleFacturaSimplificada> detalleFacturaSimplificada=null;


// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Constructores de la Clase">

    /**
     * Constructor nulo de la clase necesario para que el controlador cargue correctamente el Objeto
     */
    public FacturaSimplificadaExtendida(){

    }

    /**
     * Constructor en el que se introducen los parámetros básicos de configuración de servicios
     *
     * @param PFacturaSimplificada Factura simplificada sobre la que se trabajará y que provee
     *                             de vínculo con el Repositorio
     * @param PDetalleFacturaSimplificadaService Servicio de Detalles de Factura Simplificada
     *
     */
    public FacturaSimplificadaExtendida(FacturaSimplificada PFacturaSimplificada,
                                        IDetalleFacturaSimplificadaService PDetalleFacturaSimplificadaService){

        this.clone(PFacturaSimplificada);
        this.detalleFacturaSimplificadaService=PDetalleFacturaSimplificadaService;
    }

    /**
     * Constructor en el que se introducen los parámetros básicos de configuración de servicios junto
     * con la Factura sobre que la se va a trabajar y con la que se estable el vínculo con el Repositorio.
     *
     * @param PFactura Factura simplificada sobre la que se trabajará y que provee
     *                             de vínculo con el Repositorio
     * @param PFacturaSimplificadaService Servicio de Factura Simplificada
     * @param PDetalleFacturaSimplificadaService Servicio de Detalles de Factura Simplificada
     *
     */
    public FacturaSimplificadaExtendida(FacturaSimplificada PFactura,
                                        IFacturaSimplificadaService PFacturaSimplificadaService,
                                        IDetalleFacturaSimplificadaService PDetalleFacturaSimplificadaService){

        this.clone(PFactura);
        this.setServices(PFacturaSimplificadaService,
                         PDetalleFacturaSimplificadaService);

    }


// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Encapsulamiento">

    /**
     * Método que se encarga de introducir de forma confiable los Servicios dentro
     * del Objeto
     *
     * @param PFacturaSimpificadaService Servicio de Factura Simplificada
     * @param PDetalleFacturaSimplificadaService Servicio de Detalles de Factura Simplificada
     *
     */
    public boolean setServices(IFacturaSimplificadaService PFacturaSimpificadaService,
                               IDetalleFacturaSimplificadaService PDetalleFacturaSimplificadaService){
        boolean VDevolucion;

        try{
            this.facturaSimplificadaService=PFacturaSimpificadaService;
            this.detalleFacturaSimplificadaService=PDetalleFacturaSimplificadaService;

            VDevolucion=true;
        }catch (Exception ex){
            VDevolucion=false;
        }

        return VDevolucion;
    }

    /**
     * Método que devuelve el detalle de la factura. La carga de la lista de detalles de factura
     * siempre es bajo demanda.
     *
     * @return Devuelve la lista de Detalles de la Factura.
     *                  null: En caso de error
     */
    public List<DetalleFacturaSimplificada> getDetalleFacturaSimplificada() {
        List<DetalleFacturaSimplificada> VDevolucion;

        try{
            if (detalleFacturaSimplificada==null){
                this.detalleFacturaSimplificada=detalleFacturaSimplificadaService.findByInvoice(this.getId());
            }
            if (this.detalleFacturaSimplificada!=null){
                VDevolucion=this.detalleFacturaSimplificada;
            }else{
                VDevolucion=null;
            }
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    /**
     * Método que Permite la introducción de los Detalles de la Factura desde otro objeto
     *
     * @param detalleFacturaSimplificada Lista de Detalles de Factura que se desean incluir
     */
    public void setDetalleFacturaSimplificada(List<DetalleFacturaSimplificada> detalleFacturaSimplificada) {
        this.detalleFacturaSimplificada = detalleFacturaSimplificada;
    }

    /**
     * Método que devuelve el Total de la Factura teniendo en cuenta todos los descuentos e impuestos.
     * En este método también se toma en cuenta sí a la factura se le quiere compensar con participaciones
     * premiadas
     *
     * @return Devuelve el Valor total de la Factura
     *              null: En caso de error
     */
    public Double getTotalFacturaSimplificada(){
        Double VDevolucion;

        try{
            if (this.getDetalleFacturaSimplificada()!=null){
                VDevolucion=calcularTotalLineasFacturaSimplificada();

                VDevolucion=Double.valueOf(Math.round(VDevolucion.doubleValue()*100.0)/100.0);
            }else{
                VDevolucion=0.0;
            }

        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }


// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Registro en Persistencia">

    /**
     * Método que Guarda los datos Generales de la Factura en la capa de persistencia
     *
     * @return Devuelve si se ha realizado correctamente la operación o no
     */
    public boolean save(){
        boolean VDevolucion;
        FacturaSimplificada VFactura;
        int VIndice;

        try{
            VFactura=new FacturaSimplificada();
            VFactura.clone(this);

            VFactura=this.facturaSimplificadaService.save(VFactura);
            if (VFactura!=null){
                this.setId(VFactura.getId());
                VDevolucion=(this.saveDetallesFactura()==true);
            }else{
                VDevolucion=false;
            }
        }catch (Exception ex){
            VDevolucion=false;
        }

        return VDevolucion;
    }

    /**
     * Método que Guarda los datos de los detalles de la Factura en la capa de persistencia
     *
     * @return Devuelve si se ha realizado correctamente la operación o no
     */
    public boolean saveDetallesFactura(){
        boolean VDevolucion=true;
        int VIndice;

        try{
            if (this.detalleFacturaSimplificada!=null){
                for (VIndice=0;VIndice<this.detalleFacturaSimplificada.size();VIndice++){
                    VDevolucion=VDevolucion && this.saveDetalleFactura(this.detalleFacturaSimplificada.get(VIndice));
                }
            }else{
                VDevolucion=false;
            }
        }catch (Exception ex){
            VDevolucion=false;
        }

        return VDevolucion;
    }

    /**
     * Método que Guarda un detalle de la factura en en la capa de persistencia
     *
     * @param PDetalleFacturaSimplificada Detalle de Factura que se desea guardar
     * @return Devuelve si se ha realizado correctamente la operación o no
     */
    private boolean saveDetalleFactura(DetalleFacturaSimplificada PDetalleFacturaSimplificada){
        boolean VDevolucion;

        try{
            PDetalleFacturaSimplificada.setFactura(this);
            this.detalleFacturaSimplificadaService.save(PDetalleFacturaSimplificada);

            VDevolucion=true;
        }catch (Exception ex){
            VDevolucion=false;
        }

        return VDevolucion;
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Herramientas de la Clase">

    /**
     * Método que se encarga de calcular el total de los Detalles de Factura
     *
     * @return Valor del los productos del detalle de la factura.
     */
    private Double calcularTotalLineasFacturaSimplificada(){
        Double VDevolucion=0.0;
        int VIndice;
        DetalleFacturaSimplificada VDetalleFacturaSimplificadaAux;

        try{
            for (VIndice=0;VIndice<this.detalleFacturaSimplificada.size();VIndice++){
                VDetalleFacturaSimplificadaAux=this.detalleFacturaSimplificada.get(VIndice);

                VDevolucion=VDevolucion+this.CalcularTotalLinea(VDetalleFacturaSimplificadaAux);
            }

        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    /**
     * Método que se encarga de calcular el Valor de una línea en concreta de los Detalles de Factura
     *
     * @param PDetalleFacturaSimplificada Detalle factura de la que se desea calcular el total teniendo en cuenta
     *                                    los productos con descuento que se introducen a través del otro parámetro.
     *
     * @return Valor del detalle de la factura.
     */
    private Double CalcularTotalLinea(DetalleFacturaSimplificada PDetalleFacturaSimplificada){
        Double VDevolucion;
        Double VTotalParcialBase;
        Double VDtoAux;
        Double VIvaAux;

        try{
            VTotalParcialBase=PDetalleFacturaSimplificada.getCantidad()*PDetalleFacturaSimplificada.getPrecioUnitario();

            VDtoAux=(VTotalParcialBase)*(Double.valueOf(PDetalleFacturaSimplificada.getDtoPorcentaje())/100);
            VTotalParcialBase=VTotalParcialBase-VDtoAux;

            VIvaAux=(VTotalParcialBase)*(Double.valueOf(PDetalleFacturaSimplificada.getIva())/100);

            VDevolucion=(VTotalParcialBase+VIvaAux);
        }catch (Exception ex){
            VDevolucion = -1.0;
        }

        return VDevolucion;
    }

// </editor-fold>


}
