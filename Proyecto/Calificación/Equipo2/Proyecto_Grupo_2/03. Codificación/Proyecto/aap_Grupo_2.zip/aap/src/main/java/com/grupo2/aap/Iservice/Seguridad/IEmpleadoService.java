package com.grupo2.aap.Iservice.Seguridad;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Seguridad.Empleado;

import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que será de obligada implementación por parte del servicio asociado.
 *
 * */
public interface IEmpleadoService {

    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    void setSecurityCtrl(SecurityCtrl securityCtrl);

    /**
     * Método que devuelve el empleados cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador del empleado del que se quiere obtener la información
     * @return Empleado que cumple con los requisitos de búsqueda.
     */
    Optional<Empleado> findById(Long PId);

    /**
     * Método que encuentra la lista de empleados cuyo Atributo nombre contenga
     * el nombre o cadena de caracteres que se introduce por parámetro.
     *
     * @param PNombreEmpleado Nombre del empleado sobre el que se realizará la consulta.
     * @return Lista de Empleados cuyo Nombre contenga con el parámetro de entrada.
     */
    List<Empleado> findListByName(String PNombreEmpleado);

    /**
     * Método que encuentra la lista de empleados cuyo Atributo dirección contenga
     * la dirección o cadena de caracteres que se introduce por parámetro.
     *
     * @param PDireccion Dirección del empleado sobre el que se realizará la consulta.
     * @return Lista de Empleados cuya Dirección contenga con el parámetro de entrada.
     */
    List<Empleado> findListByAddress(String PDireccion);

    /**
     * Método que encuentra la lista de empleados cuyo Atributo provincia contenga
     * la provincia o cadena de caracteres que se introduce por parámetro.
     *
     * @param PProvince Provincia del empleado sobre el que se realizará la consulta.
     * @return Lista de empleados cuya provincia contenga con el parámetro de entrada.
     */
    List<Empleado> findListByProvince(String PProvince);

    /**
     * Método que encuentra la lista de empleados cuyo Atributo poblacion contenga
     * la Poblacion o cadena de caracteres que se introduce por parámetro.
     *
     * @param PTown Poblacion del empleado sobre el que se realizará la consulta.
     * @return Lista de empleados cuya poblacion contenga con el parámetro de entrada.
     */
    List<Empleado> findListByTown(String PTown);

    /**
     * Método que encuentra la lista de empleados cuyo Atributo Codigo Postal contenga
     * el Codigo Postal o cadena de caracteres que se introduce por parámetro.
     *
     * @param PPostalCode Codigo Postal del empleado sobre el que se realizará la consulta.
     * @return Lista de Empleados cuyo Codigo Postal contenga con el parámetro de entrada.
     */
    List<Empleado> findListByPostalCode(String PPostalCode);

    /**
     * Método que encuentra la lista de empleados cuyo Atributo email contenga
     * el email o cadena de caracteres que se introduce por parámetro.
     *
     * @param PEMail EMail del empleado sobre el que se realizará la consulta.
     * @return Lista de empleados cuyo EMail contenga con el parámetro de entrada.
     */
    List<Empleado> findListByEMail(String PEMail);

    /**
     * Método que Guarda la información del Empleado que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PEmpleado Entidad Empleado que se desea almacenar.
     * @return Empleado con los datos que han sido guardados en la Base de Datos
     */
    Empleado save(Empleado PEmpleado);

    /**
     * Método que Guarda los cambios de la información del empleado que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador de la Entidad Empleado que se desea Actualizar.
     * @param PEmpleado Entidad Empleado que se desea Actualizar.
     * @return Empleado con los datos que han sido guardados en la Base de Datos
     */
    Empleado update(Long PId, Empleado PEmpleado);

    /**
     * Método que elimina el Empleado que se introduce por parámetro de la Base de Datos
     *
     * @param PId Identificador del Empleado que se desea Eliminar.
     * @return Si se ha realizado correctamente la operación o no
     */
    boolean delete(Long PId);

}
