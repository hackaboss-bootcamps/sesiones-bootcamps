package com.grupo2.aap.Controller.Ventas;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Component.SecuritySession;
import com.grupo2.aap.Entity.Ventas.Cliente;
import com.grupo2.aap.Iservice.Ventas.IClienteService;
import jdk.jshell.spi.ExecutionControlProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/cliente")
public class ClienteController {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    @Autowired
    private IClienteService service;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos Controladores de Conexión">


    @GetMapping("/ID")
    public Optional<Cliente> show(@RequestParam Long id, HttpSession sesion) {
        Optional<Cliente> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findById(id);
        }else{
            VDevolucion=null;
        }
        return VDevolucion;
    }


    @GetMapping("/DN")
    public List<Cliente> findByDni(@RequestParam String dni, HttpSession sesion) {
        List<Cliente> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByDni(dni);
        }else{
            VDevolucion=null;
        }
        return VDevolucion;
    }


    @GetMapping("/NO")
    public List<Cliente> findByName(@RequestParam String nombre, HttpSession sesion) {
        List<Cliente> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByName(nombre);
        }else{
            VDevolucion=null;
        }
        return VDevolucion;
    }


    @GetMapping("/DI")
    public List<Cliente> findByAddress(@RequestParam String direccion, HttpSession sesion) {
        List<Cliente> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByAddress(direccion);
        }else{
            VDevolucion=null;
        }
        return VDevolucion;
    }


    @GetMapping("/PR")
    public List<Cliente> findByProvince(@RequestParam String provincia, HttpSession sesion) {
        List<Cliente> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByProvince(provincia);
        }else{
            VDevolucion=null;
        }
        return VDevolucion;
    }


    @GetMapping("/PO")
    public List<Cliente> findByPoblacion(@RequestParam String poblacion, HttpSession sesion) {
        List<Cliente> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByTown(poblacion);
        }else{
            VDevolucion=null;
        }
        return VDevolucion;
    }


    @GetMapping("/CP")
    public List<Cliente> findByPostalCode(@RequestParam String codPostal, HttpSession sesion) {
        List<Cliente> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByPostalCode(codPostal);
        }else{
            VDevolucion=null;
        }
        return VDevolucion;
    }


    @GetMapping("/EM")
    public List<Cliente> findByEmail(@RequestParam String email, HttpSession sesion) {
        List<Cliente> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByEMail(email);
        }else{
            VDevolucion=null;
        }
        return VDevolucion;
    }


    @PostMapping
    @ResponseStatus(code = HttpStatus.CREATED)
    public Cliente save(@RequestBody Cliente cliente, HttpSession sesion) {
        Cliente VDevolucion;
        SecurityCtrl VSecurityCtrl;

        try{
            VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
            if (VSecurityCtrl!=null){
                service.setSecurityCtrl(VSecurityCtrl);
                VDevolucion=service.save(cliente);
            }else{
                VDevolucion=null;
            }
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }


    @PutMapping()
    @ResponseStatus(code = HttpStatus.ACCEPTED)
    public Cliente update(@RequestParam Long id, @RequestBody Cliente cliente, HttpSession sesion) {
        Cliente VDevolucion;
        SecurityCtrl VSecurityCtrl;

        try{
            VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
            if (VSecurityCtrl!=null){
                service.setSecurityCtrl(VSecurityCtrl);
                VDevolucion=service.update(id, cliente);
            }else{
                VDevolucion = null;
            }
        }catch (Exception ex){
            VDevolucion = null;
        }

        return VDevolucion;
    }


    @DeleteMapping()
    @ResponseStatus(code = HttpStatus.ACCEPTED)
    public boolean delete(@RequestParam Long id, HttpSession sesion) {
        boolean VDevolucion;
        SecurityCtrl VSecurityCtrl;

        try{
            VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
            if (VSecurityCtrl!=null){
                service.setSecurityCtrl(VSecurityCtrl);

                VDevolucion=service.delete(id);
            }else{
                VDevolucion=false;
            }
        }catch (Exception ex){
            VDevolucion=false;
        }

        return VDevolucion;
    }
// </editor-fold>

}
