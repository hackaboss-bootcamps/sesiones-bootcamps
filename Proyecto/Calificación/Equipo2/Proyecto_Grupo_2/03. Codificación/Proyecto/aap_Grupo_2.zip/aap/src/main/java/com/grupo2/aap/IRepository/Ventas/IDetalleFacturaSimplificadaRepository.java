package com.grupo2.aap.IRepository.Ventas;
import com.grupo2.aap.Entity.Ventas.DetalleFactura;
import com.grupo2.aap.Entity.Ventas.DetalleFacturaSimplificada;
import com.grupo2.aap.Entity.Ventas.FacturaSimplificada;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que permite la ejecución de las cláusulas SQL necesarias para servir de repositorio de
 * la entidad DetalleFacturaSimplificada.
 *
 * */
@Repository
public interface IDetalleFacturaSimplificadaRepository  extends JpaRepository<DetalleFacturaSimplificada,Long> {

    /**
     * Método que encuentra la lista de detalles facturas simplificadas cuyo Atributo Factura es la que se introduce
     * por parámetro.
     *
     * @param PFactura Factura sobre la que se realizará la consulta.
     * @return Lista de Detalle De Factura Simplificada cuya Factura coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM detalles_facturas_simplificadas " +
            "WHERE factura = :factura", nativeQuery = true)
    List<DetalleFacturaSimplificada> findListByInvoice(@Param("factura") Long PFactura);

    /**
     * Método que encuentra la lista de detalles facturas simplificadas cuyo Atributo Producto es el que se introduce
     * por parámetro.
     *
     * @param PProducto Producto sobre el que se realizará la consulta.
     * @return Lista de Detalle De Factura Simplificada cuyo Producto coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM detalles_facturas_simplificadas " +
            "WHERE producto = :producto", nativeQuery = true)
    List<DetalleFacturaSimplificada> findByProduct(@Param("producto") Long PProducto);

    /**
     * Método que encuentra la lista de detalles facturas simplificadas cuyo Atributo Cantidad es el que se introduce
     * por parámetro.
     *
     * @param PCantidadInicio Cantidad Inicial sobre la que se realizará la consulta.
     * @param PCantidadFin Cantidad Final sobre la que se realizará la consulta.
     * @return Lista de Detalle De Factura Simplificada cuya CantidadInicio y CantidadFin coincide con los parámetros de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM detalles_facturas_simplificadas " +
            "WHERE cantidad BETWEEN cantidadInicio AND cantidadFin", nativeQuery = true)
    List<DetalleFacturaSimplificada> findByAmount(@Param("cantidadInicio") Integer PCantidadInicio,
                                      @Param("cantidadFin") Integer PCantidadFin);

}