package com.grupo2.aap.Iservice.Seguridad.LogsSeguridad;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Seguridad.LogsSeguridad.SecLogAdministracion;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que será de obligada implementación por parte del servicio asociado.
 *
 * */
public interface ISecLogAdministracionService {

    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    void setSecurityCtrl(SecurityCtrl securityCtrl);

    /**
     * Método que devuelve todos los log de administracion de seguridad de la Base de Datos
     *
     * @return Lista de log de administracion de seguridad de la Base de Datos
     */
    List<SecLogAdministracion> all();

    /**
     * Método que devuelve el log de administracion de seguridad cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador del log de administracion de seguridad del que se quiere obtener la información
     * @return Log de administracion de seguridad que cumple con los requisitos de búsqueda.
     */
    Optional<SecLogAdministracion> findById(Long PId);

    /**
     * Método que encuentra la lista de log de administracion de seguridad cuya operacion es la que se introduce
     * por parámetro.
     *
     * @param POperacion Operacion del log de administracion de seguridad sobre el que se realizará la consulta.
     * @return Lista de log de administracion de seguridad cuya operacion coincide con el parámetro de entrada.
     */
    List<SecLogAdministracion> findListByOperation(Long POperacion);

    /**
     * Método que encuentra la lista de log de administracion de seguridad cuyo tipo de entidad es el que se introduce
     * por parámetro.
     *
     * @param PTipoEntidad Tipo de entidad del log de administracion de seguridad sobre el que se realizará la consulta.
     * @return Lista de log de administracion de seguridad cuyo tipo de entidad coincide con el parámetro de entrada.
     */
    List<SecLogAdministracion> findListByTypeOfEntity(Long PTipoEntidad);

    /**
     * Método que encuentra la lista de log de administracion de seguridad cuya entidad es la que se introduce
     * por parámetro.
     *
     * @param PEntidad Entidad del log de administracion de seguridad sobre la que se realizará la consulta.
     * @return Lista de log de administracion de seguridad cuya entidad coincide con el parámetro de entrada.
     */
    List<SecLogAdministracion> findListByEntity(Long PEntidad);

    /**
     * Método que encuentra la lista de log de administracion de seguridad cuya fecha inicial y fecha final son las que se introducen
     * por parámetro.
     * @param PFechaInicio Fecha inicial del log de administracion de seguridad sobre la que se realizará la consulta.
     * @param PFechaFin Fecha final del log de administracion de seguridad sobre la que se realizará la consulta.
     * @return Lista de log de administracion de seguridad cuyas fechas iniciales y fechas finales coincide con el parámetro de entrada.
     */
    List<SecLogAdministracion> findByDate(LocalDateTime PFechaInicio, LocalDateTime PFechaFin);

    /**
     * Método que encuentra la lista de log de administracion de seguridad cuyo usuario es el que se introduce
     * por parámetro.
     *
     * @param PUsuario Usuario del log de administracion de seguridad sobre el que se realizará la consulta.
     * @return Lista de log de administracion de seguridad cuyo usuario coincide con el parámetro de entrada.
     */
    List<SecLogAdministracion> findListByUser(Long PUsuario);

    /**
     * Método que encuentra la lista de log de administracion de seguridad cuyo mensaje es el que se introduce
     * por parámetro.
     *
     * @param PMensaje Mensaje del log de administracion de seguridad sobre el que se realizará la consulta.
     * @return Lista de log de administracion de seguridad cuyo mensaje coincide con el parámetro de entrada.
     */
    List<SecLogAdministracion> findListByMessage(String PMensaje);

    /**
     * Método que Guarda la información del log de administracion de seguridad que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PSecLogAdministracion Entidad del log de administracion de seguridad que se desea almacenar.
     * @return Log de administracion de seguridad con los datos que han sido guardados en la Base de Datos
     */
    SecLogAdministracion save(SecLogAdministracion PSecLogAdministracion);

}
