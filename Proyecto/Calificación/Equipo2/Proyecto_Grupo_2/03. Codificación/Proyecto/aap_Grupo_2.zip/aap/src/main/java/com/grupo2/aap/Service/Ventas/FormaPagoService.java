package com.grupo2.aap.Service.Ventas;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Ventas.FormaPago;
import com.grupo2.aap.IRepository.Ventas.IFormaPagoRepository;
import com.grupo2.aap.Iservice.Ventas.IFormaPagoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que contiene el Servicio de sobre el Repositorio Formas de Pago
 *
 * */
@Service
public class FormaPagoService implements IFormaPagoService {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    @Autowired
    private IFormaPagoRepository repository;

    /** Sistema de Control de la Seguridad que controlará los accesos por parte de los usuarios y
     * las actividades realizadas por los mismos */
    private SecurityCtrl securityCtrl;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Encapsulamiento">


    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    @Override
    public void setSecurityCtrl(SecurityCtrl securityCtrl) {
        this.securityCtrl = securityCtrl;
    }


// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Consultas">

    /**
     * Método que devuelve todas las Formas de Pago de la Base de Datos
     *
     * @return Lista de Forma de Pago de la Base de Datos
     */
    @Override
    public List<FormaPago> all() {
        return repository.findAll();
    }

    /**
     * Método que devuelve la forma pago cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador de la forma pago de la que se quiere obtener la información
     * @return Forma Pago que cumple con los requisitos de búsqueda.
     */
    @Override
    public Optional<FormaPago> findById(Long PId) {
        Optional<FormaPago> VDevolucion;

        try{
            VDevolucion = repository.findById(PId);
        }catch (Exception ex){
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista Formas de  Pago cuyo Atributo FormaPago contenga
     * el Nombre o cadena de caracteres que se introduce por parámetro.
     *
     * @param PNombre FormaPago de la familia de Formas de Pago sobre el que se realizará la consulta.
     * @return Lista de Forma Pago cuyo nombre contenga con el parámetro de entrada.
     */
    @Override
    public List<FormaPago> findByName(String PNombre) {
        List<FormaPago> VDevolucion;

        try{
            VDevolucion = repository.findByName(PNombre);

        }catch (Exception ex){
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista Formas de  Pago cuyo Atributo FormaPago contenga
     * el Nombre o cadena de caracteres que se introduce por parámetro.
     *
     * @param PFormaPago FormaPago de la familia de Formas de Pago sobre el que se realizará la consulta.
     * @return Lista de Forma Pago cuyo nombre contenga con el parámetro de entrada.
     */
    @Override
    public List<FormaPago> findListByName(String PFormaPago) {
        return repository.findByName(PFormaPago);
    }


// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de Datos">

    /**
     * Método que Guarda la información de la Forma Pago que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PFormaPago Entidad FormaPago que se desea almacenar.
     * @return Forma Pago con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public FormaPago save(FormaPago PFormaPago) {
        return repository.save(PFormaPago);
    }

    /**
     * Método que Guarda los cambios de la información de la FormaPago e que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador de la Entidad FormaPago que se desea Actualizar.
     * @param PFormaPago Entidad FormaPago que se desea Actualizar.
     */
    @Override
    public void update(Long PId, FormaPago PFormaPago) {
        FormaPago VFormaPagoActualizado = new FormaPago();
        Optional<FormaPago> VFormaPago;

        VFormaPago = repository.findById(PId);

        if(VFormaPago.isEmpty()){
            System.out.println("Dato no encontrado");
        }else{
            VFormaPagoActualizado.clone(VFormaPago.get());

            repository.save(VFormaPagoActualizado);
        }
    }

    /**
     * Método que elimina la Forma Pago que se introduce por parámetro de la Base de Datos
     *
     * @param PId Identificador de la Forma Pago  que se desea Eliminar.
     */
    @Override
    public void delete(Long PId) {
        repository.deleteById(PId);
    }

// </editor-fold>

}
