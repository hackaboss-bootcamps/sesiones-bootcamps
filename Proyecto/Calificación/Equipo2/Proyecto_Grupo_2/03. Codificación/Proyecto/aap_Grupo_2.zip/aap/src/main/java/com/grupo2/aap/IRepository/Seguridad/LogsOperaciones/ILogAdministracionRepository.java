package com.grupo2.aap.IRepository.Seguridad.LogsOperaciones;

import com.grupo2.aap.Entity.Seguridad.LogsOperaciones.LogAdministracion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que permite la ejecución de las cláusulas SQL necesarias para servir de repositorio de
 * la entidad LogAdministracion
 * */
@Repository
public interface ILogAdministracionRepository extends JpaRepository<LogAdministracion,Long> {

    /**
     * Método que encuentra la lista de log_sorteos cuya operacion es la que se introduce
     * por parámetro.
     *
     * @param POperacion Operacion de log_sorteos sobre la que se realizará la consulta.
     * @return Lista de log_sorteos cuya operacion coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM log_sorteos " +
            "WHERE operacion = :operacion", nativeQuery = true)
    List<LogAdministracion> findListByOperation(@Param("operacion") Long POperacion);

    /**
     * Método que encuentra la lista de log_sorteos cuyo tipo de entidad es el que se introduce
     * por parámetro.
     *
     * @param PTipoEntidad Tipo de Entidad de log_sorteos sobre el que se realizará la consulta.
     * @return Lista de log_sorteos cuyo tipo de entidad con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM log_sorteos " +
            "WHERE tipo_entidad = :tipoEntidad", nativeQuery = true)
    List<LogAdministracion> findListByTypeOfEntity(@Param("tipoEntidad") Long PTipoEntidad);

    /**
     * Método que encuentra la lista de log_sorteos cuya entidad es el que se introduce
     * por parámetro.
     *
     * @param PEntidad Entidad de log_sorteos sobre la que se realizará la consulta.
     * @return Lista de log_sorteos cuya Entidad coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM log_sorteos " +
            "WHERE entidad = :entidad", nativeQuery = true)
    List<LogAdministracion> findListByEntity(@Param("entidad") Long PEntidad);

    /**
     * Método que encuentra la lista de log_sorteos cuya fecha de inicio y fecha final es la que se introduce
     * por parámetro.
     *
     * @param PFechaInicio Fecha de inicio de log_sorteos sobre la que se realizará la consulta.
     * @param PFechaFin Fecha final de log_sorteos sobre la que se realizará la consulta.
     * @return Lista de log_sorteos cuya fecha está entre la Fecha de inicio y la fecha final.
     */
    @Query(value = "SELECT  * " +
            "FROM log_sorteos " +
            "WHERE fecha BETWEEN fechaInicio AND fechaFin", nativeQuery = true)
    List<LogAdministracion> findByDate(@Param("fechaInicio") LocalDateTime PFechaInicio, @Param("fechaFin") LocalDateTime PFechaFin);

    /**
     * Método que encuentra la lista de log_sorteos cuyo usuario es el que se introduce
     * por parámetro.
     *
     * @param PUsuario Usuario de log_sorteos sobre el que se realizará la consulta.
     * @return Lista de log_sorteos cuyo usuario coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM log_sorteos " +
            "WHERE usuario = :usuario", nativeQuery = true)
    List<LogAdministracion> findListByUser(@Param("usuario") Long PUsuario);

    /**
     * Método que encuentra la lista de log_sorteos cuyo mensaje es el que se introduce
     * por parámetro.
     *
     * @param PMensaje Mensaje de log_sorteos sobre el que se realizará la consulta.
     * @return Lista de log_sorteos cuyo mensaje coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM log_sorteos " +
            "WHERE mensaje LIKE %:mensaje%", nativeQuery = true)
    List<LogAdministracion> findListByMessage(@Param("mensaje") String PMensaje);


}
