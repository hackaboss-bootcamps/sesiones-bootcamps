package com.grupo2.aap.Entity.Component;

import javax.persistence.*;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que mantiene la abstracción de los atributos referentes a los datos personales. Datos que
 * deben ser especialmente protegidos en el sistema.
 *
 *
 * */

@MappedSuperclass
public class PersonalData {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Identificador de la entidad */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    /** DNI de la entidad */
    @Column(name = "dni",nullable = false,unique = true,length = 10)
    private String dni;

    /** Nombre de la entidad */
    @Column(name = "nombre",nullable = false,length = 50)
    private String nombre;

    /** Primer Apellido de la entidad */
    @Column(name = "apellido1",nullable = false,length = 50)
    private String apellido1;

    /** Segundo Apellido de la entidad */
    @Column(name = "apellido2",nullable = false,length = 50)
    private String apellido2;

    /** Dirección de la entidad */
    @Column(name = "direccion",nullable = false,length = 150)
    private String direccion;

    /** Provincia de la entidad */
    @Column(name = "provincia",nullable = false,length = 50)
    private String provincia;

    /** Población de la entidad */
    @Column(name = "poblacion",nullable = false,length = 50)
    private String poblacion;

    /** Código Postal de la entidad */
    @Column(name = "cod_postal",nullable = false,length = 5)
    private String codPostal;

    /** EMail de la entidad */
    @Column(name = "email",nullable = false,length = 150)
    private String email;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Encapsulamiento">


    /**
     * Método que devuelve el Identificador de la entidad
     *
     * @return Identificador de la Entidad
     */
    public long getId() {
        return id;
    }

    /**
     * Método que Introduce el Identificador de la entidad
     *
     * @param id Identificador de la Entidad
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * Método que devuelve el Dni de la entidad
     *
     * @return Dni de la Entidad
     */
    public String getDni() {
        return dni;
    }

    /**
     * Método que Introduce el Identificador de la entidad
     *
     * @param dni Identificador de la Entidad
     */
    public void setDni(String dni) {
        this.dni = dni;
    }

    /**
     * Método que devuelve el Nombre de la entidad
     *
     * @return Nombre de la Entidad
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Método que Introduce el Identificador de la entidad
     *
     * @param nombre Nombre de la Entidad
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Método que devuelve el Primer Apellido de la entidad
     *
     * @return Primer Apellido de la Entidad
     */
    public String getApellido1() {
        return apellido1;
    }

    /**
     * Método que Introduce el Identificador de la entidad
     *
     * @param apellido1 Primer Apellido de la Entidad
     */
    public void setApellido1(String apellido1) {
        this.apellido1 = apellido1;
    }

    /**
     * Método que devuelve el Segundo Apellido de la entidad
     *
     * @return Segundo Apellido de la Entidad
     */
    public String getApellido2() {
        return apellido2;
    }

    /**
     * Método que Introduce el Identificador de la entidad
     *
     * @param apellido2 Segundo Apellido de la Entidad
     */
    public void setApellido2(String apellido2) {
        this.apellido2 = apellido2;
    }

    /**
     * Método que devuelve la Dirección de la entidad
     *
     * @return Dirección de la Entidad
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * Método que Introduce el Identificador de la entidad
     *
     * @param direccion Direccion de la Entidad
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    /**
     * Método que devuelve la Provincia de la entidad
     *
     * @return Provincia de la Entidad
     */
    public String getProvincia() {
        return provincia;
    }

    /**
     * Método que Introduce el Identificador de la entidad
     *
     * @param provincia Provincia de la Entidad
     */
    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    /**
     * Método que devuelve la Población de la entidad
     *
     * @return Población de la Entidad
     */
    public String getPoblacion() {
        return poblacion;
    }

    /**
     * Método que Introduce el Identificador de la entidad
     *
     * @param poblacion Población de la Entidad
     */
    public void setPoblacion(String poblacion) {
        this.poblacion = poblacion;
    }

    /**
     * Método que devuelve el Código Postal de la entidad
     *
     * @return Código Postal de la Entidad
     */
    public String getCodPostal() {
        return codPostal;
    }

    /**
     * Método que Introduce el Identificador de la entidad
     *
     * @param codPostal CP de la Entidad
     */
    public void setCodPostal(String codPostal) {
        this.codPostal = codPostal;
    }

    /**
     * Método que devuelve el EMail de la entidad
     *
     * @return EMail de la Entidad
     */
    public String getEmail() {
        return email;
    }

    /**
     * Método que Introduce el Identificador de la entidad
     *
     * @param email EMail de la Entidad
     */
    public void setEmail(String email) {
        this.email = email;
    }


// </editor-fold>

}
