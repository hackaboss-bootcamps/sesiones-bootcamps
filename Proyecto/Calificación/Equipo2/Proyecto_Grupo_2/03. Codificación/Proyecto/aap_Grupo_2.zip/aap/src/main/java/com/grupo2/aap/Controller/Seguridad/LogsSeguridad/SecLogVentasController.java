package com.grupo2.aap.Controller.Seguridad.LogsSeguridad;

import com.grupo2.aap.Entity.Seguridad.LogsSeguridad.SecLogVentas;
import com.grupo2.aap.Iservice.Seguridad.LogsSeguridad.ISecLogVentasService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/seclogventas")
public class SecLogVentasController {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    @Autowired
    private ISecLogVentasService service;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos Controladores de Conexión">

    @GetMapping("/ID")
    public Optional<SecLogVentas> show(@RequestParam Long id) {
        return service.findById(id);
    }

    @GetMapping("/OP")
    public List<SecLogVentas> findByOperation(@RequestParam Long operation) {
        return service.findListByOperation(operation);
    }
    @GetMapping("/TE")
    public List<SecLogVentas> findListByTypeOfEntity(@RequestParam Long tipoentidad) {
        return service.findListByTypeOfEntity(tipoentidad);
    }
    @GetMapping("/EN")
    public List<SecLogVentas> findListByEntity(@RequestParam Long entidad) {
        return service.findListByEntity(entidad);
    }
    @GetMapping("/FE")
    public List<SecLogVentas> findByDate(@RequestParam LocalDateTime fechaInicio,
                                         @RequestParam LocalDateTime fechaFin) {
        return service.findByDate(fechaInicio,fechaFin);
    }
    @GetMapping("/US")
    public List<SecLogVentas> findListByUser(@RequestParam Long usuario){
        return service.findListByUser(usuario);
    }

    @GetMapping("/ME")
    public List<SecLogVentas> findListByMessage(@RequestParam String message) {
        return service.findListByMessage(message);
    }
    @PostMapping
    @ResponseStatus(code = HttpStatus.CREATED)
    public SecLogVentas save(@RequestBody SecLogVentas seclogventas) {
        return service.save(seclogventas);
    }

// </editor-fold>

}