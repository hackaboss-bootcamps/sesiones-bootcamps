package com.grupo2.aap.Service.Ventas;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Fidelizacion.Participacion;
import com.grupo2.aap.Entity.Ventas.Cliente;
import com.grupo2.aap.Entity.Ventas.Factura;
import com.grupo2.aap.Entity.Ventas.FacturaExtendida;
import com.grupo2.aap.IRepository.Ventas.IFacturaRepository;
import com.grupo2.aap.Iservice.Fidelizacion.IParticipacionService;
import com.grupo2.aap.Iservice.Fidelizacion.ISorteoService;
import com.grupo2.aap.Iservice.Ventas.IDetalleFacturaService;
import com.grupo2.aap.Iservice.Ventas.IFacturaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que contiene el Servicio de sobre el Repositorio Detalles de Facturas
 *
 * */
@Service
public class FacturaService implements IFacturaService {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    @Autowired
    private IFacturaRepository repository;

    @Autowired
    private IDetalleFacturaService detalleFacturaService;

    @Autowired
    private ISorteoService sorteoService;

    @Autowired
    private IParticipacionService participacionService;


    /** Sistema de Control de la Seguridad que controlará los accesos por parte de los usuarios y
     * las actividades realizadas por los mismos */
    private SecurityCtrl securityCtrl;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Encapsulamiento">


    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    @Override
    public void setSecurityCtrl(SecurityCtrl securityCtrl) {
        this.securityCtrl = securityCtrl;
        this.sorteoService.setSecurityCtrl(this.securityCtrl);
        this.participacionService.setSecurityCtrl(this.securityCtrl);
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Consultas">

    /**
     * Método que devuelve todas las Facturas de la Base de Datos
     *
     * @return Lista de Facturas de la Base de Datos
     */
    @Override
    public List<Factura> all() {
        return repository.findAll();
    }

    /**
     * Método que devuelve la factura cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador de la factura  de la que se quiere obtener la información
     * @return Factura que cumple con los requisitos de búsqueda.
     */
    @Override
    public Optional<Factura> findById(Long PId) {
        return repository.findById(PId);
    }

    /**
     * Método que encuentra la lista de facturas cuyo Atributo Número es el que se introduce
     * por parámetro.
     *
     * @param PNumero Número sobre el que se realizará la consulta.
     * @return Lista de Factura  cuyo Número contenga con el parámetro de entrada.
     */
    @Override
    public List<Factura> findListByNumber(Long PNumero) {
        return this.repository.findByNumber(PNumero);
    }

    /**
     * Método que encuentra la lista de facturas cuyo Atributo Fecha es el que se introduce
     * por parámetro.
     *
     * @param PFechaInicio Fecha Inicial sobre la que se realizará la consulta
     * @param PFechaFin Fecha Final sobre la que se realizará la consulta
     * @return Lista de Facturas cuya FechaInicio y FechaFin coincide con los parámetros de entrada.
     */
    @Override
    public List<Factura> findByDate(LocalDateTime PFechaInicio, LocalDateTime PFechaFin) {
        return this.repository.findByDate(PFechaInicio,PFechaFin);
    }

    /**
     * Método que encuentra la lista de facturas cuyo Atributo Forma de Pago es el que se introduce
     * por parámetro.
     *
     * @param PFormaPago Forma de Pago sobre la que se realizará la consulta.
     * @return Lista de Facturas  cuya Forma de Pago contenga con el parámetro de entrada.
     */
    @Override
    public List<Factura> findByWay2Pay(Long PFormaPago) {
        return this.repository.findByFormaWay2Pay(PFormaPago);
    }

    /**
     * Método que encuentra la lista de facturas cuyo Atributo Observaciones contenga
     * las Observaciones o cadena de caracteres que se introduce por parámetro.
     *
     * @param PObservaciones Observaciones sobre la que se realizará la consulta.
     * @return Lista de Facturas  cuyas Observaciones contenga con el parámetro de entrada.
     */
    @Override
    public List<Factura> findByRemarks(String PObservaciones) {
        return this.repository.findByRemarks(PObservaciones);
    }

    /**
     * Método que encuentra la lista de facturas cuyo Atributo Cliente es el que se introduce
     * por parámetro.
     *
     * @param PIdCliente Id Cliente sobre el que se realizará la consulta.
     * @return Lista de Facturas  cuyo IdCliente coincide con el parámetro de entrada.
     */
    @Override
    public List<Factura> findByClient(Long PIdCliente) {
        return this.repository.findByClient(PIdCliente);
    }

    /**
     * Método que devuelve la FacturaExtendida cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador de la factura  de la que se quiere obtener la información
     * @return Factura Extendida que cumple con los requisitos de búsqueda.
     */
    @Override
    public FacturaExtendida findExtInvoiceById(Long PId) {
        FacturaExtendida VDevolucion;
        Optional<Factura> VFactura;

        try{
            VFactura=this.repository.findById(PId);
            if (!VFactura.isEmpty()){
                VDevolucion=new FacturaExtendida(VFactura.get(),this,
                                                    this.detalleFacturaService,
                                                    this.participacionService,
                                                    this.sorteoService);
            }else{
                VDevolucion=null;
            }

        }catch (Exception ex){
            VDevolucion=null;
        }


        return VDevolucion;
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de Datos">

    // <editor-fold defaultstate="collapsed" desc="Métodos de Generación de Facturas">

    /**
     * Método que Genera una factura en función del Objeto que se introduce por parámetro
     *
     * @param PFactura Objeto Factura que contiene los datos de la Nueva Factura
     * @return Imagen de la factura que se ha dado de alta en la Capa de Persistencia
     */
    @Override
    public Factura generarFactura(Factura PFactura){
        Long VNumeroFactura;
        Factura VDevolucion;

        try{
            VNumeroFactura = repository.findInvoiceNextNumber();
            PFactura.setNumero(VNumeroFactura);

            VDevolucion=this.save(PFactura);
            if (VDevolucion!=null){
                this.sorteoService.setSecurityCtrl(this.securityCtrl);
                this.sorteoService.generarParticipacion(PFactura);
            }

        }catch (Exception ex){
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que Genera una factura Extendida en función del Objeto que se introduce por parámetro
     *
     * @param PFactura Objeto Factura Extendida que contiene los datos de la Nueva Factura
     * @return Imagen de la factura Extendida que se ha dado de alta en la Capa de Persistencia
     */
    @Override
    public boolean generarFactura(FacturaExtendida PFactura){
        Long VNumeroFactura;
        boolean VDevolucion;

        try{
            VNumeroFactura = repository.findInvoiceNextNumber();
            PFactura.setNumero(VNumeroFactura);
            PFactura.setServices(this,
                                    this.detalleFacturaService,
                                    this.participacionService,
                                    this.sorteoService);

            if (PFactura.save()==true){
                this.sorteoService.generarParticipacion(PFactura);
                VDevolucion = true;
            }else{
                VDevolucion=false;
            }

        }catch (Exception ex){
            VDevolucion = false;
        }

        return VDevolucion;
    }

    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Métodos de Aplicación de Participaciones">

    /**
     * Método que Aplica una participación premiada a la Factura cuyo Id se introduce por parámetro
     *
     * @param PIdFactura Identificador de la Factura a la que se le va a aplicar el premio.
     * @param PIdParticipacion Participación que se aplicará a la factura que se introduce por parámetro.
     * @return Factura Extendia con los beneficios del sorteo aplicados.
     */
    @Override
    public FacturaExtendida aplicarParticipacion(Long PIdFactura,Long PIdParticipacion){
        FacturaExtendida VDevolucion;
        Optional<Factura> VFactura;

        try{
            VFactura=this.repository.findById(PIdFactura);
            if (!VFactura.isEmpty()){
                VDevolucion=this.aplicarParticipacion(VFactura.get(),PIdParticipacion);
            }else{
                VDevolucion=null;
            }
        }catch (Exception ex){
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que Aplica una participación premiada a la Factura cuyo Id se introduce por parámetro
     *
     * @param PFactura Objeto Factura a la que se le va a aplicar el premio.
     * @param PIdParticipacion Participación que se aplicará a la factura que se introduce por parámetro.
     * @return Factura Extendia con los beneficios del sorteo aplicados.
     */
    @Override
    public FacturaExtendida aplicarParticipacion(Factura PFactura,Long PIdParticipacion){
        FacturaExtendida VDevolucion;
        Optional<Participacion> VParticipacion;

        try{
            VParticipacion = participacionService.findById(PIdParticipacion);
            if (!VParticipacion.isEmpty()){
                if (VParticipacion.get().getGanadora()){
                    if (VParticipacion.get().getFechaMaxValidez().isAfter(LocalDate.now())){
                        VParticipacion.get().setFacturaAplicacion(PFactura);
                        if (this.participacionService.save(VParticipacion.get())!=null){
                            VDevolucion=new FacturaExtendida(PFactura,this,
                                                                this.detalleFacturaService,
                                                                this.participacionService,
                                                                this.sorteoService);
                        }else{
                            VDevolucion=null;
                        }
                    }else{
                        VDevolucion=null;
                    }
                }else{
                    VDevolucion=null;
                }
            }else{
                VDevolucion=null;
            }
        }catch (Exception ex){
            VDevolucion = null;
        }

        return VDevolucion;
    }

    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Métodos de Operaciones Básicas">

    /**
     * Método que Guarda la información de la Factura que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PFactura Entidad Factura que se desea almacenar.
     * @return Factura con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public Factura save(Factura PFactura) {
        Factura VDevolucion;

        try{
            if (PFactura.getFecha()==null){
                PFactura.setFecha(LocalDateTime.now());
            }
            VDevolucion=repository.save(PFactura);
        }catch (Exception ex){
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que Guarda la información de la Factura y sus Detalles que se introducen por parámetro en la
     * Base de Datos
     *
     * @param PFactura Entidad FacturaExtendida que se desea almacenar.
     * @return Factura con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public FacturaExtendida save(FacturaExtendida PFactura) {
        FacturaExtendida VDevolucion;

        try{
            if (PFactura.getFecha()==null){
                PFactura.setFecha(LocalDateTime.now());
            }
            if (repository.save(PFactura)!=null){
                if (PFactura.saveDetallesFactura()==true){
                    VDevolucion=PFactura;
                }else{
                    VDevolucion=null;
                }
            }else{
                VDevolucion=null;
            }
        }catch (Exception ex){
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que Guarda los cambios de la información de la Factura e que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador de la Entidad Factura que se desea Actualizar.
     * @param PFactura Entidad Factura que se desea Actualizar.
     * @return Factura con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public Factura update(Long PId, Factura PFactura) {
        Factura VDevolucion;
        Factura VFacturaActualizada = new Factura();
        Optional<Factura> VFactura;

        try{
            VFactura = repository.findById(PId);

            if(!VFactura.isEmpty()){

                VFacturaActualizada.clone(PFactura);
                VFacturaActualizada.setId(VFactura.get().getId());

                VDevolucion=repository.save(VFacturaActualizada);
            }else{
                VDevolucion=null;
            }
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    /**
     * Método que elimina la Factura  que se introduce por parámetro de la Base de Datos
     *
     * @param PId Identificador de la Factura que se desea Eliminar.
     */
    @Override
    public boolean delete(Long PId) {
        boolean VDevolucion;
        Optional<Factura> VFactura;

        try {
            VFactura = repository.findById(PId);

            if (!VFactura.isEmpty()){

                VFactura.get().setFechaAnulacion(LocalDateTime.now());
                VDevolucion=(this.save(VFactura.get())!=null);
            }else{
                VDevolucion=false;
            }
        }catch (Exception ex){
            VDevolucion=false;
        }

        return VDevolucion;
    }

    // </editor-fold>

// </editor-fold>


}
