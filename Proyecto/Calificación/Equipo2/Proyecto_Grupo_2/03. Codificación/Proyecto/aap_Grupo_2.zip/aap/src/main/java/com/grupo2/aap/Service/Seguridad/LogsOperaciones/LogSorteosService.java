package com.grupo2.aap.Service.Seguridad.LogsOperaciones;
import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Seguridad.LogsOperaciones.LogSorteos;
import com.grupo2.aap.Entity.Seguridad.LogsOperaciones.LogSorteos;
import com.grupo2.aap.IRepository.Seguridad.LogsOperaciones.ILogSorteosRepository;
import com.grupo2.aap.Iservice.Seguridad.LogsOperaciones.ILogSorteosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que contiene el Servicio de sobre el Repositorio LogSorteos
 *
 * */
@Service
public class LogSorteosService implements ILogSorteosService {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Repositorio de LogSorteos*/
    @Autowired
    private ILogSorteosRepository repository;

    /** Sistema de Control de la Seguridad que controlará los accesos por parte de los usuarios y
     * las actividades realizadas por los mismos */
    private SecurityCtrl securityCtrl;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos para el Control de la Seguridad">


    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    @Override
    public void setSecurityCtrl(SecurityCtrl securityCtrl) {
        this.securityCtrl = securityCtrl;
    }


// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Consultas">

    /**
     * Método que devuelve todos los log de sorteos de la Base de Datos
     *
     * @return Lista de log de sorteos de la Base de Datos
     */
    @Override
    public List<LogSorteos> all(){
        List<LogSorteos> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = repository.findAll();
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que devuelve el log de sorteos cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador del log de sorteos del que se quiere obtener la información
     * @return Log de sorteos que cumple con los requisitos de búsqueda.
     */
    @Override
    public Optional<LogSorteos> findById(Long PId){
        Optional<LogSorteos> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion=repository.findById(PId);
        }else{
            VDevolucion=Optional.empty();
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de log de sorteos cuya operacion es la que se introduce
     * por parámetro.
     *
     * @param POperacion Operacion del log de sorteos sobre el que se realizará la consulta.
     * @return Lista de log de sorteos cuya operacion coincide con el parámetro de entrada.
     */
    @Override
    public List<LogSorteos> findListByOperation(Long POperacion){
        List<LogSorteos> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByOperation(POperacion);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de log de sorteos cuyo tipo de entidad es el que se introduce
     * por parámetro.
     *
     * @param PTipoEntidad Tipo de entidad del log de sorteos sobre el que se realizará la consulta.
     * @return Lista de log de sorteos cuyo tipo de entidad coincide con el parámetro de entrada.
     */
    @Override
    public List<LogSorteos> findListByTypeOfEntity(Long PTipoEntidad){
        List<LogSorteos> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByTypeOfEntity(PTipoEntidad);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de log de sorteos cuya entidad es la que se introduce
     * por parámetro.
     *
     * @param PEntidad Entidad del log de sorteos sobre la que se realizará la consulta.
     * @return Lista de log de sorteos cuya entidad coincide con el parámetro de entrada.
     */
    @Override
    public List<LogSorteos> findListByEntity(Long PEntidad){
        List<LogSorteos> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByEntity(PEntidad);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de log de sorteos cuya fecha inicial y fecha final son las que se introducen
     * por parámetro.
     * @param PFechaInicio Fecha inicial del log de sorteos sobre la que se realizará la consulta.
     * @param PFechaFin Fecha final del log de sorteos sobre la que se realizará la consulta.
     * @return Lista de log de sorteos cuyas fechas iniciales y fechas finales coincide con el parámetro de entrada.
     */
    @Override
    public List<LogSorteos> findByDate(LocalDateTime PFechaInicio, LocalDateTime PFechaFin){
        List<LogSorteos> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findByDate(PFechaInicio,PFechaFin);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de log de sorteos cuyo usuario es el que se introduce
     * por parámetro.
     *
     * @param PUsuario Usuario del log de sorteos sobre el que se realizará la consulta.
     * @return Lista de log de sorteos cuyo usuario coincide con el parámetro de entrada.
     */
    @Override
    public List<LogSorteos> findListByUser(Long PUsuario){
        List<LogSorteos> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByUser(PUsuario);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de log de sorteos cuyo mensaje es el que se introduce
     * por parámetro.
     *
     * @param PMensaje Mensaje del log de sorteos sobre el que se realizará la consulta.
     * @return Lista de log de sorteos cuyo mensaje coincide con el parámetro de entrada.
     */
    @Override
    public List<LogSorteos> findListByMessage(String PMensaje){
        List<LogSorteos> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByMessage(PMensaje);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }
// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de la Persistencia">

    /**
     * Método que Guarda la información del log de sorteos que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PLogSorteos Entidad del log de sorteos que se desea almacenar.
     * @return Log de sorteos con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public LogSorteos save(LogSorteos PLogSorteos){
        LogSorteos VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion=repository.save(PLogSorteos);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

// </editor-fold>

}


