package com.grupo2.aap.Controller.Seguridad.LogsOperaciones;


import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Component.SecuritySession;
import com.grupo2.aap.Entity.Seguridad.LogsOperaciones.LogAdministracion;
import com.grupo2.aap.Entity.Ventas.Cliente;
import com.grupo2.aap.Iservice.Seguridad.LogsOperaciones.ILogAdministracionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/logadministracion")
public class LogAdministracionController {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    @Autowired
    private ILogAdministracionService service;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos Controladores de Conexión">

    @GetMapping("/ID")
    public Optional<LogAdministracion> show(@RequestParam Long id, HttpSession sesion) {
        Optional<LogAdministracion> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findById(id);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @GetMapping("/OP")
    public List<LogAdministracion> findByOperation(@RequestParam Long operation, HttpSession sesion) {
        List<LogAdministracion> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByOperation(operation);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }


    @GetMapping("/TE")
    public List<LogAdministracion> findListByTypeOfEntity(@RequestParam Long tipoEntidad, HttpSession sesion) {
        List<LogAdministracion> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByTypeOfEntity(tipoEntidad);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }


    @GetMapping("/EN")
    public List<LogAdministracion> findListByEntity(@RequestParam Long entidad, HttpSession sesion) {
        List<LogAdministracion> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByEntity(entidad);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }


    @GetMapping("/FE")
    public List<LogAdministracion> findByDate(@RequestParam LocalDateTime fechaInicio,
                                              @RequestParam LocalDateTime fechaFin,
                                              HttpSession sesion) {
        List<LogAdministracion> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findByDate(fechaInicio,fechaFin);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }


    @GetMapping("/US")
    public List<LogAdministracion> findListByUser(@RequestParam Long usuario,
                                                  HttpSession sesion){
        List<LogAdministracion> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByUser(usuario);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }


    @GetMapping("/ME")
    public List<LogAdministracion> findListByMessage(@RequestParam String mensaje,
                                                     HttpSession sesion) {
        List<LogAdministracion> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByMessage(mensaje);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

// </editor-fold>

}
