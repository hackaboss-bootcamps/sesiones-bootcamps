package com.grupo2.aap.Controller.Ventas;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Component.SecuritySession;
import com.grupo2.aap.Entity.Ventas.Producto;
import com.grupo2.aap.Iservice.Ventas.IProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/producto")
public class ProductoController {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    @Autowired
    private IProductoService service;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos Controladores de Conexión">


    @GetMapping("/ID")
    public Optional<Producto> show(@RequestParam Long id) {
        return service.findById(id);
    }

    @GetMapping("/NO")
    public List<Producto> findByName(@RequestParam String nombre) {
        return service.findByName(nombre);
    }

    @GetMapping("/CA")
    public List<Producto> findByAmount(@RequestParam Integer cantidadInicio,
                                       @RequestParam Integer cantidadFin,
                                       HttpSession sesion) {
        List<Producto> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        try{
            VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
            if (VSecurityCtrl!=null){
                service.setSecurityCtrl(VSecurityCtrl);
                VDevolucion=service.findByAmount(cantidadInicio,cantidadFin);
            }else{
                VDevolucion=null;
            }
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @GetMapping("/CB")
    public List<Producto> findByCodBarras(@RequestParam String codBarras) {
        return service.findByCodBarras(codBarras);
    }

    @GetMapping("/OB")
    public List<Producto> findByRemarks(@RequestParam String observaciones, HttpSession sesion) {
        List<Producto> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        try{
            VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
            if (VSecurityCtrl!=null){
                service.setSecurityCtrl(VSecurityCtrl);
                VDevolucion=service.findByRemarks(observaciones);
            }else{
                VDevolucion=null;
            }
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @GetMapping("/PR")
    public List<Producto> findByPrice(@RequestParam String precioUnitarioInicio,
                                      @RequestParam String precioUnitarioFin,
                                      HttpSession sesion) {

        List<Producto> VDevolucion;
        SecurityCtrl VSecurityCtrl;
        Double VPrecioUnitarioInicio;
        Double VPrecioUnitarioFin;


        try{
            VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
            if (VSecurityCtrl!=null){

                VPrecioUnitarioInicio=Double.valueOf(precioUnitarioInicio);
                VPrecioUnitarioFin=Double.valueOf(precioUnitarioFin);

                service.setSecurityCtrl(VSecurityCtrl);
                VDevolucion=service.findByPrice(VPrecioUnitarioInicio,VPrecioUnitarioFin);
            }else{
                VDevolucion=null;
            }
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }


    @GetMapping("/IV")
    public List<Producto> findByIva(@RequestParam Integer ivaInicio,
                                    @RequestParam Integer ivaFin,
                                    HttpSession sesion) {

        List<Producto> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        try{
            VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
            if (VSecurityCtrl!=null){
                service.setSecurityCtrl(VSecurityCtrl);
                VDevolucion=service.findByIva(ivaInicio,ivaFin);
            }else{
                VDevolucion=null;
            }
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @GetMapping("/FA")
    public List<Producto> findByFamily(@RequestParam Long familiaProducto) {
        return service.findByFamily(familiaProducto);
    }

    @PostMapping
    @ResponseStatus(code = HttpStatus.CREATED)
    public Producto save(@RequestBody Producto producto, HttpSession sesion) {
        Producto VDevolucion;
        SecurityCtrl VSecurityCtrl;

        try{
            VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
            if (VSecurityCtrl!=null){
                service.setSecurityCtrl(VSecurityCtrl);
                VDevolucion=service.save(producto);
            }else{
                VDevolucion=null;
            }
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @PutMapping()
    @ResponseStatus(code = HttpStatus.ACCEPTED)
    public Producto update(@RequestParam Long id,
                           @RequestBody Producto producto,
                           HttpSession sesion) {

        Producto VDevolucion;
        SecurityCtrl VSecurityCtrl;

        try{
            VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
            if (VSecurityCtrl!=null){
                service.setSecurityCtrl(VSecurityCtrl);
                VDevolucion=service.update(id, producto);
            }else{
                VDevolucion = null;
            }
        }catch (Exception ex){
            VDevolucion = null;
        }

        return VDevolucion;
    }


    @DeleteMapping()
    @ResponseStatus(code = HttpStatus.ACCEPTED)
    public boolean delete(@RequestParam Long id, HttpSession sesion) {
        boolean VDevolucion;
        SecurityCtrl VSecurityCtrl;

        try{
            VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
            if (VSecurityCtrl!=null){
                service.setSecurityCtrl(VSecurityCtrl);

                VDevolucion=service.delete(id);
            }else{
                VDevolucion=false;
            }
        }catch (Exception ex){
            VDevolucion=false;
        }

        return VDevolucion;
    }
// </editor-fold>

}
