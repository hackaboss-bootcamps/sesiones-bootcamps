package com.grupo2.aap.Entity.Ventas;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que implementa la Entidad de FamiliaProducto. Esta clase contendrá la información básica y las operaciones
 * Básicas con dicha información.
 *
 * */
@Entity
@Table (name = "familias_productos")
public class FamiliaProducto {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Id de la Familia de Productos */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Nombre de la Familia de Productos */
    @Column (name = "nombre",nullable = false,unique = true,length = 50)
    private String nombre;

    /** Familia Padre de la Familia de Productos */
    @ManyToOne(fetch = FetchType.EAGER, optional = true)
    @JoinColumn(name = "familia_padre", nullable = true)
    private FamiliaProducto familiaPadre;

    /** Fecha en la que se ha eliminado la Familia de Productos */
    @Column (name = "fecha_eliminacion",nullable = true)
    private LocalDateTime fechaEliminacion;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Encapsulamiento">

    /**
     * Método que Devuelve el Id de la Familia de Productos
     *
     * @return Id de la Familia de Productos.
     */
    public long getId() {
        return id;
    }

    /**
     * Método que Introduce el Id de la Familia de Productos.
     *
     * @param id de la Familia de Productos.
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * Método que Devuelve el Nombre de lla Familia de Productos
     *
     * @return Nombre de la Familia de Productos.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Método que Introduce el Nombre de la Familia de Productos.
     *
     * @param nombre de la Familia de Productos.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Método que Devuelve la Familia Padre de la Familia de Productos
     *
     * @return Familia Padre de la Familia de Productos.
     */
    public FamiliaProducto getFamiliaPadre() {
        return familiaPadre;
    }

    /**
     * Método que Introduce la Familia Padre de la Familia de Productos.
     *
     * @param familiaPadre de la Familia de Productos.
     */
    public void setFamiliaPadre(FamiliaProducto familiaPadre) {
        this.familiaPadre = familiaPadre;
    }

    /**
     * Método que Devuelve La FEcha de Eliminación de la Familia de Productos
     *
     * @return Fecha de Eliminación de la Familia de Productos.
     */
    public LocalDateTime getFechaEliminacion() {
        return fechaEliminacion;
    }

    /**
     * Método que Introduce la Fecha de Eliminación de la Familia de Productos.
     *
     * @param fechaEliminacion de Eliminación de la Familia de Productos.
     */
    public void setFechaEliminacion(LocalDateTime fechaEliminacion) {
        this.fechaEliminacion = fechaEliminacion;
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de Datos">

    /**
     * Método que Clona la información de otra entidad familiaproducto en sí misma.
     *
     * @param PFamiliaProductoClonar FamiliaProducto cuyos parámetros se desean clonar.
     * @return Sí se ha realizado correctamente o no la operación.
     */
    public boolean clone(FamiliaProducto PFamiliaProductoClonar){
        boolean VDevolucion;

        try{
            this.setNombre(PFamiliaProductoClonar.getNombre());
            this.setFamiliaPadre(PFamiliaProductoClonar.getFamiliaPadre());
            this.setFechaEliminacion(PFamiliaProductoClonar.getFechaEliminacion());

            VDevolucion = true;
        }catch (Exception ex){
            VDevolucion = false;
        }

        return VDevolucion;
    }

// </editor-fold>


}
