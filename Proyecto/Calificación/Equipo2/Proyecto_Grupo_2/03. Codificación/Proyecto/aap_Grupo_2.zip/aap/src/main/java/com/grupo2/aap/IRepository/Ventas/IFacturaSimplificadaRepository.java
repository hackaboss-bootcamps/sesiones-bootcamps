
package com.grupo2.aap.IRepository.Ventas;
import com.grupo2.aap.Entity.Ventas.Factura;
import com.grupo2.aap.Entity.Ventas.FacturaSimplificada;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que permite la ejecución de las cláusulas SQL necesarias para servir de repositorio de
 * la entidad FacturaSimplificada.
 *
 * */
@Repository
public interface IFacturaSimplificadaRepository extends JpaRepository<FacturaSimplificada,Long> {

    /**
     * Método que Devuelve el número de factura que tiene que llevar una Nueva Factura.
     *
     * @return Nuevo Número para una Factura Nueva
     */
    @Query(value = "SELECT  MAX(numero)+1 AS NextInvoiceNumber " +
            "FROM facturas_simplificadas", nativeQuery = true)
    Long findInvoiceNextNumber();

    /**
     * Método que encuentra la lista de facturas simplificadas cuyo Atributo Número es el que se introduce
     * por parámetro.
     *
     * @param PNumero Número sobre el que se realizará la consulta.
     * @return Lista de Facturas Simplificadas cuyo Número coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM facturas_simplificadas " +
            "WHERE numero = :numero", nativeQuery = true)
    List<FacturaSimplificada> findListByNumber(@Param("numero") Long PNumero);

    /**
     * Método que encuentra la lista de facturas simplificadas cuyo Atributo Fecha es el que se introduce
     * por parámetro.

     *
     * @param PFechaInicio Fecha Inicial sobre la que se realizará la consulta
     * @param PFechaFin Fecha Final sobre la que se realizará la consulta
     * @return Lista de Facturas Simplificadas cuya FechaInicio y FechaFin coincide con los parámetros de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM facturas_simplificadas " +
            "WHERE fecha BETWEEN :fechaInicio AND :fechaFin", nativeQuery = true)
    List<FacturaSimplificada> findByDate(@Param("fechaInicio") LocalDateTime PFechaInicio, @Param("fechaFin") LocalDateTime PFechaFin);

    /**
     * Método que encuentra la lista de facturas simplificadas cuyo Atributo Forma de Pago es el que se introduce
     * por parámetro.
     *
     * @param PFormaPago Forma de Pago sobre la que se realizará la consulta.
     * @return Lista de Facturas Simplificadas  cuya Forma de Pago coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM facturas_simplificadas " +
            "WHERE forma_pago = :formaPago", nativeQuery = true)
    List<FacturaSimplificada> findByFormaWay2Pay(@Param("formaPago") Long PFormaPago);

    /**
     * Método que encuentra la lista de facturas simplificadas cuyo Atributo Observaciones contenga
     * las Observaciones o cadena de caracteres que se introduce por parámetro.
     *
     * @param PObservaciones Observaciones sobre la que se realizará la consulta.
     * @return Lista de Facturas Simplificadas  cuyas Observaciones contenga con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM facturas_simplificadas " +
            "WHERE observaciones LIKE %:observaciones%", nativeQuery = true)
    List<FacturaSimplificada> findByRemarks(@Param("observaciones") String PObservaciones);

}