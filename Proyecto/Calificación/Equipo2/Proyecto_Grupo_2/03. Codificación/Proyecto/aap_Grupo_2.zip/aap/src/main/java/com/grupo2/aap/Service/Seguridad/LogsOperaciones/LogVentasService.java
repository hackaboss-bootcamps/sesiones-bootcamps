package com.grupo2.aap.Service.Seguridad.LogsOperaciones;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Seguridad.LogsOperaciones.LogVentas;
import com.grupo2.aap.Entity.Seguridad.LogsOperaciones.LogVentas;
import com.grupo2.aap.IRepository.Seguridad.LogsOperaciones.ILogVentasRepository;
import com.grupo2.aap.Iservice.Seguridad.LogsOperaciones.ILogVentasService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que contiene el Servicio de sobre el Repositorio LogVentas
 *
 * */
@Service
public class LogVentasService implements ILogVentasService {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Repositorio de LogVentas*/
    @Autowired
    private ILogVentasRepository repository;


    /** Sistema de Control de la Seguridad que controlará los accesos por parte de los usuarios y
     * las actividades realizadas por los mismos */
    private SecurityCtrl securityCtrl;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos para el Control de la Seguridad">


    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    @Override
    public void setSecurityCtrl(SecurityCtrl securityCtrl) {
        this.securityCtrl = securityCtrl;
    }


// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Consultas">

    /**
     * Método que devuelve todos los log de ventas de la Base de Datos
     *
     * @return Lista de log de ventas de la Base de Datos
     */
    @Override
    public List<LogVentas> all(){
        List<LogVentas> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = repository.findAll();
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que devuelve el log de ventas cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador del log de ventas del que se quiere obtener la información
     * @return Log de ventas que cumple con los requisitos de búsqueda.
     */
    @Override
    public Optional<LogVentas> findById(Long PId){
        Optional<LogVentas> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion=repository.findById(PId);
        }else{
            VDevolucion=Optional.empty();
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de log de ventas cuya operacion es la que se introduce
     * por parámetro.
     *
     * @param POperacion Operacion del log de ventas sobre el que se realizará la consulta.
     * @return Lista de log de ventas cuya operacion coincide con el parámetro de entrada.
     */
    @Override
    public List<LogVentas> findListByOperation(Long POperacion){
        List<LogVentas> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByOperation(POperacion);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de log de ventas cuyo tipo de entidad es el que se introduce
     * por parámetro.
     *
     * @param PTipoEntidad Tipo de entidad del log de ventas sobre el que se realizará la consulta.
     * @return Lista de log de ventas cuyo tipo de entidad coincide con el parámetro de entrada.
     */
    @Override
    public List<LogVentas> findListByTypeOfEntity(Long PTipoEntidad){
        List<LogVentas> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByTypeOfEntity(PTipoEntidad);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de log de ventas cuya entidad es la que se introduce
     * por parámetro.
     *
     * @param PEntidad Entidad del log de ventas sobre la que se realizará la consulta.
     * @return Lista de log de ventas cuya entidad coincide con el parámetro de entrada.
     */
    @Override
    public List<LogVentas> findListByEntity(Long PEntidad){
        List<LogVentas> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByEntity(PEntidad);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de log de ventas cuya fecha inicial y fecha final son las que se introducen
     * por parámetro.
     * @param PFechaInicio Fecha inicial del log de ventas sobre la que se realizará la consulta.
     * @param PFechaFin Fecha final del log de ventas sobre la que se realizará la consulta.
     * @return Lista de log de ventas cuyas fechas iniciales y fechas finales coincide con el parámetro de entrada.
     */
    @Override
    public List<LogVentas> findByDate(LocalDateTime PFechaInicio, LocalDateTime PFechaFin){
        List<LogVentas> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findByDate(PFechaInicio,PFechaFin);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de log de ventas cuyo usuario es el que se introduce
     * por parámetro.
     *
     * @param PUsuario Usuario del log de ventas sobre el que se realizará la consulta.
     * @return Lista de log de ventas cuyo usuario coincide con el parámetro de entrada.
     */
    @Override
    public List<LogVentas> findListByUser(Long PUsuario){
        List<LogVentas> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByUser(PUsuario);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de log de ventas cuyo mensaje es el que se introduce
     * por parámetro.
     *
     * @param PMensaje Mensaje del log de ventas sobre el que se realizará la consulta.
     * @return Lista de log de ventas cuyo mensaje coincide con el parámetro de entrada.
     */
    @Override
    public List<LogVentas> findListByMessage(String PMensaje){
        List<LogVentas> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByMessage(PMensaje);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }
// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de la Persistencia">

    /**
     * Método que Guarda la información del log de ventas que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PLogVentas Entidad del log de ventas que se desea almacenar.
     * @return Log de ventas con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public LogVentas save(LogVentas PLogVentas){
        LogVentas VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion=repository.save(PLogVentas);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

// </editor-fold>

}