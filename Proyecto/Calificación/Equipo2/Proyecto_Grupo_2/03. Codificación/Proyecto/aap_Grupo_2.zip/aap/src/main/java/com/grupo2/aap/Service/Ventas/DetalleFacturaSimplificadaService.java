package com.grupo2.aap.Service.Ventas;

import com.grupo2.aap.Entity.Ventas.*;
import com.grupo2.aap.IRepository.Ventas.IDetalleFacturaSimplificadaRepository;
import com.grupo2.aap.Iservice.Ventas.IDetalleFacturaSimplificadaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que contiene el Servicio de sobre el Repositorio Detalles de Facturas
 *
 * */
@Service
public class DetalleFacturaSimplificadaService implements IDetalleFacturaSimplificadaService {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Repositorio de DetalleFacturaSimplificada*/
    @Autowired
    private IDetalleFacturaSimplificadaRepository repository;


// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Consultas">

    /**
     * Método que devuelve todos los Detalles de Factura Simplificada de la Base de Datos
     *
     * @return Lista de Detalle de Factura Simplificada de la Base de Datos
     */
    @Override
    public List<DetalleFacturaSimplificada> all() {
        return repository.findAll();
    }

    /**
     * Método que devuelve el Detalle de Factura Simplificada cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador del Detalle de Factura Simplificada del que se quiere obtener la información
     * @return Lista de Detalle de Factura Simplificada que cumple con los requisitos de búsqueda.
     */
    @Override
    public Optional<DetalleFacturaSimplificada> findById(Long PId) {
        return repository.findById(PId);
    }

    /**
     * Método que encuentra la lista de detalle factura simplificada cuyo Atributo Factura es el que se introduce
     * por parámetro.
     *
     * @param PFactura Detalle de la Factura Simplificada sobre la que se realizará la consulta.
     * @return Lista de Detalle De Factura Simplificada cuyo DetalleFacturaSimplificado coincide con el parámetro de entrada.
     */
    @Override
    public List<DetalleFacturaSimplificada> findByInvoice(Long PFactura) {
        return this.repository.findListByInvoice(PFactura);
    }

    /**
     * Método que encuentra la lista de detalle factura simplificada cuyo Atributo Producto es el que se introduce
     * por parámetro.
     *
     * @param PProducto Producto sobre la que se realizará la consulta.
     * @return Lista de Detalle De Factura Simplificada cuyo Producto coincide con el parámetro de entrada.
     */
    @Override
    public List<DetalleFacturaSimplificada> findByProduct(Long PProducto) {
        return this.repository.findByProduct(PProducto);
    }

    /**
     * Método que encuentra la lista de detalle factura simplificada cuyo Atributo Cantidad es el que se introduce
     * por parámetro.
     *
     * @param PCantidadInicio Cantidad Inicial sobre la que se realizará la consulta.
     * @param PCantidadFin Cantidad Final sobre la que se realizará la consulta.
     * @return Lista de Detalle De Factura Simplificada cuya CantidadInicio y CantidadFin coincide con los parámetros de entrada.
     */
    @Override
    public List<DetalleFacturaSimplificada> findByAmount(Integer PCantidadInicio, Integer PCantidadFin) {
        return this.findByAmount(PCantidadInicio,PCantidadFin);
    }


// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de Datos">

    /**
     * Método que Guarda la información del Detalle de Factura Simplificada que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PDetalleFacturaSimplificada Entidad DetalleFacturaSimplificada que se desea almacenar.
     * @return DetalleFacturaSimplificada con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public DetalleFacturaSimplificada save(DetalleFacturaSimplificada PDetalleFacturaSimplificada) {
        DetalleFacturaSimplificada VDevolucion;

        try{
            VDevolucion=repository.save(PDetalleFacturaSimplificada);
        }catch (Exception ex){
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que Guarda la información de los Detalles de Factura Simplificada que se introduce por parámetro en la
     * Base de Datos
     *
     * @param detallesFacturaSimplificada Entidad DetalleFacturaSimplificada que se desea almacenar.
     * @return DetallesFacturaSimplificada con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public List<DetalleFacturaSimplificada> batchSave(List<DetalleFacturaSimplificada> detallesFacturaSimplificada) {
        List<DetalleFacturaSimplificada> VDevolucion = new ArrayList<DetalleFacturaSimplificada>();
        int VIndice;

        try{
            for (VIndice=0;VIndice<detallesFacturaSimplificada.size();VIndice++){
                VDevolucion.add(this.save(detallesFacturaSimplificada.get(VIndice)));
            }

        }catch (Exception ex){
            VDevolucion=null;
        }
        return VDevolucion;
    }

    /**
     * Método que Guarda los cambios de la información de Detalle Factura Simplificada que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador de la Entidad DetalleFacturaSimplificada que se desea Actualizar.
     * @param PDetalleFacturaSimplificada de la Entidad DetalleFacturaSimplificada que se desea Actualizar.
     * @return DetalleFacturaSimplificada con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public DetalleFacturaSimplificada update(Long PId, DetalleFacturaSimplificada PDetalleFacturaSimplificada) {
        DetalleFacturaSimplificada VDevolucion;
        DetalleFacturaSimplificada VDetalleFacturaSimplificadaActualizada = new DetalleFacturaSimplificada();
        Optional<DetalleFacturaSimplificada> VDetalleFacturaSimplificada;

        try{
            VDetalleFacturaSimplificada = repository.findById(PId);

            if(!VDetalleFacturaSimplificada.isEmpty()){
                VDetalleFacturaSimplificadaActualizada.clone(PDetalleFacturaSimplificada);
                VDetalleFacturaSimplificadaActualizada.setId(VDetalleFacturaSimplificada.get().getId());

                VDevolucion = repository.save(VDetalleFacturaSimplificadaActualizada);
            }else{
                VDevolucion = null;
            }
        }catch (Exception ex){
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que Elimina la información del Detalle de Factura Simplificada que se introduce por parámetro de la Base de Datos
     *
     * @param PId Identificador de la Entidad DetalleFacturaSimplificada que se desea Eliminar.
     */
    @Override
    public boolean delete(Long PId) {
        boolean VDevolucion;

        try{
            repository.deleteById(PId);

            VDevolucion=true;
        }catch (Exception ex){
            VDevolucion = false;
        }

        return VDevolucion;
    }

// </editor-fold>

}
