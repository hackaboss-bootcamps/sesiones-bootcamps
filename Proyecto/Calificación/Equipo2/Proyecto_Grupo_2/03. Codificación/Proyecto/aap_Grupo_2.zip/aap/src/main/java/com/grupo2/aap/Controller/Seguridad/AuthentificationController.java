package com.grupo2.aap.Controller.Seguridad;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Seguridad.Empleado;
import com.grupo2.aap.Iservice.Seguridad.IEmpleadoService;
import com.grupo2.aap.Iservice.Seguridad.IUsuarioService;
import com.grupo2.aap.Iservice.Seguridad.LogsOperaciones.ILogAdministracionService;
import com.grupo2.aap.Iservice.Seguridad.LogsOperaciones.ILogSorteosService;
import com.grupo2.aap.Iservice.Seguridad.LogsOperaciones.ILogVentasService;
import com.grupo2.aap.Iservice.Seguridad.LogsSeguridad.ISecLogAdministracionService;
import com.grupo2.aap.Iservice.Seguridad.LogsSeguridad.ISecLogSorteosService;
import com.grupo2.aap.Iservice.Seguridad.LogsSeguridad.ISecLogVentasService;
import com.grupo2.aap.Iservice.Seguridad.MaestrasSeguridad.ILogOperacionesService;
import com.grupo2.aap.Iservice.Seguridad.MaestrasSeguridad.ILogTipoEntidadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/autentificacion")
public class AuthentificationController {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    @Autowired
    private IEmpleadoService service;

    @Autowired
    private IUsuarioService userService;

    @Autowired
    private ILogAdministracionService logAdministracionService;

    @Autowired
    private ILogSorteosService logSorteosService;

    @Autowired
    private ILogVentasService logVentasService;

    @Autowired
    private ISecLogAdministracionService secLogAdministracionService;

    @Autowired
    private ISecLogSorteosService secLogSorteosService;

    @Autowired
    private ISecLogVentasService secLogVentasService;

    @Autowired
    private ILogOperacionesService logOperacionesService;

    @Autowired
    private ILogTipoEntidadService logTipoEntidadService;


// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos Controladores de Conexión">

    @GetMapping("/AU")
    public boolean autentificacion(@RequestParam String nombreUsuario, @RequestParam String password, HttpSession sesion) {
        boolean VDevolucion;
        SecurityCtrl VControlSeguridad = new SecurityCtrl(this.userService,this.logAdministracionService,
                                                            this.logSorteosService,this.logVentasService,
                                                            this.secLogAdministracionService,
                                                            this.secLogSorteosService,
                                                            this.secLogVentasService,
                                                            this.logOperacionesService,
                                                            this.logTipoEntidadService);

        try{
            if (VControlSeguridad.autentificar(nombreUsuario,password)==true){
                sesion.setAttribute("SeguridadCtrl",VControlSeguridad);

                VDevolucion = true;
            }else{
                VDevolucion = false;
            }
        }catch (Exception ex){
            VDevolucion=false;
        }
        return VDevolucion;
    }

    @GetMapping("/CL")
    public boolean cerrarSesion(HttpSession sesion) {
        boolean VDevolucion;

        try{
            if (sesion.getAttribute("SeguridadCtrl") != null){
                sesion.removeAttribute("SeguridadCtrl");
            }
            VDevolucion=true;
        }catch (Exception ex){
            VDevolucion=false;
        }
        return VDevolucion;
    }

    @GetMapping("/CO")
    public boolean comprobarAutentificacion(HttpSession sesion) {
        boolean VDevolucion;
        SecurityCtrl VControlSeguridad;

        try{
            VControlSeguridad=(SecurityCtrl) sesion.getAttribute("SeguridadCtrl");
            if (VControlSeguridad!=null){
                VDevolucion=VControlSeguridad.isAdministrator();
            }else{
                VDevolucion=false;
            }
        }catch (Exception ex){
            VDevolucion = false;
        }

        return VDevolucion;
    }
// </editor-fold>

}
