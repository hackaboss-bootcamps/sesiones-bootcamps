package com.grupo2.aap.Component;

import javax.servlet.http.HttpSession;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que facilitará la extracción de forma rápida y segura del Sistema de Control de Seguridad de la
 * información almacenada en la sesión
 *
 * */
public class SecuritySession {

// <editor-fold defaultstate="collapsed" desc="Constantes">

    public final static int NO_DEFINIDO=0;
    public final static int ADMINISTRADOR=1;
    public final static int NO_ADMINISTRADOR=2;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Encapsulado de Acceso Rápido al Control de Seguridad">


    /**
     * Método que extrae de la sesión el Sistema de Control de la Seguridad.
     *
     * @param  PSesion Sesión activa del sistema
     *
     * @return Sistema de Control de Seguridad
     */
    public static SecurityCtrl getSecurityCtrl(HttpSession PSesion){
        SecurityCtrl VDevolucion;

        try{
            VDevolucion=(SecurityCtrl)PSesion.getAttribute("SeguridadCtrl");
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    /**
     * Método que extrae el Nombre del Usuario del Sistema de Control de la Seguridad.
     *
     * @param  PSesion Sesión activa del sistema
     *
     * @return Nombre del Usuario
     */
    public static String getUserName(HttpSession PSesion){
        SecurityCtrl controlSeguridad;
        String VDevolucion;

        controlSeguridad= getSecurityCtrl(PSesion);
        if (controlSeguridad!=null){
            VDevolucion = controlSeguridad.getUserName();
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

    /**
     * Método que extrae el Rol del Usuario del Sistema de Control de la Seguridad.
     *
     * @param  PSesion Sesión activa del sistema
     *
     * @return Rol del Usuario (Ver Constantes)
     */
    public static int rol(HttpSession PSesion){
        SecurityCtrl controlSeguridad;
        int VDevolucion;

        controlSeguridad= getSecurityCtrl(PSesion);
        if (controlSeguridad!=null){
            if (controlSeguridad.isAdministrator()){
                VDevolucion = ADMINISTRADOR;
            }else{
                VDevolucion = NO_ADMINISTRADOR;
            }
        }else{
            VDevolucion=NO_DEFINIDO;
        }

        return VDevolucion;
    }

// </editor-fold>

}
