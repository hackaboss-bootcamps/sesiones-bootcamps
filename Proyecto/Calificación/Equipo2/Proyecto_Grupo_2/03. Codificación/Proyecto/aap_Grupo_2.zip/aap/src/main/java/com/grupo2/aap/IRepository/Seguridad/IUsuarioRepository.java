package com.grupo2.aap.IRepository.Seguridad;

import com.grupo2.aap.Entity.Seguridad.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que permite la ejecución de las cláusulas SQL necesarias para servir de repositorio de
 * la entidad Usuario
 *
 * */
@Repository
public interface IUsuarioRepository extends JpaRepository<Usuario,Long> {

    /**
     * Método que encuentra la lista de usuarios cuyo empleado es el que se introduce
     * por parámetro.
     *
     * @param PEmpleado Empleado del usuario sobre el que se realizará la consulta.
     * @return Lista de usuario cuyo empleado coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM usuarios " +
            "WHERE empleado = :empleado " +
            "AND fecha_eliminacion IS NULL", nativeQuery = true)
    List<Usuario> findByEmployee(@Param("empleado") Long PEmpleado);

    /**
     * Método que encuentra la lista de usuarios cuyo nombre de usuario es el que se introduce
     * por parámetro.
     *
     * @param PNombreUsuario Nombre de usuario del usuario sobre el que se realizará la consulta.
     * @return Lista de usuarios cuyo nombre de usuario coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM usuarios " +
            "WHERE nombre_usuario = :nombreUsuario " +
            "AND fecha_eliminacion IS NULL", nativeQuery = true)
    List<Usuario> findByName(@Param("nombreUsuario") String PNombreUsuario);

    /**
     * Método que encuentra la lista de usuarios cuyo administrador es el que se introduce
     * por parámetro.
     *
     * @param PAdministrador Administrador del usuario sobre el que se realizará la consulta.
     * @return Lista de usuarios cuyo administrador coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM usuarios " +
            "WHERE administrador = :administrador " +
            "AND fecha_eliminacion IS NULL", nativeQuery = true)
    List<Usuario> findByRol(@Param("administrador") Boolean PAdministrador);

    /**
     * Método que encuentra la lista de usuarios cuyo nombre de usuario y contraseña son los que se introducen
     * por parámetro.
     *
     * @param PNombreUsuario Nombre de usuario del usuario sobre el que se realizará la consulta.
     * @param PContrasenha Contraseña del usuario sobre el que se realizará la consulta.
     * @return Lista de usuario cuyo nombre de usuario y contraseña coinciden con los parámetros de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM usuarios " +
            "WHERE nombre_usuario = :nombre " +
            "AND password = :password " +
            "AND fecha_eliminacion IS NULL", nativeQuery = true)
    Optional<Usuario> authenticate(@Param("nombre") String PNombreUsuario,
                                   @Param("password") String PContrasenha);

}
