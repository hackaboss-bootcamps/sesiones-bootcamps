package com.grupo2.aap.Controller.Ventas;

import com.grupo2.aap.Entity.Ventas.DetalleFacturaSimplificada;
import com.grupo2.aap.Iservice.Ventas.IDetalleFacturaSimplificadaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/dfacturasimplificada")
public class DetalleFacturaSimplificadaController {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    @Autowired
    private IDetalleFacturaSimplificadaService service;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos Controladores de Conexión">


    @GetMapping("/ID")
    public Optional<DetalleFacturaSimplificada> show(@RequestParam Long id) {
        return service.findById(id);
    }

    @GetMapping("/FA")
    public List<DetalleFacturaSimplificada> findByInvoice(@RequestParam Long numero) {
        return service.findByInvoice(numero);
    }

    @GetMapping("/PO")
    public List<DetalleFacturaSimplificada> findByProduct(@RequestParam Long producto) {
        return service.findByProduct(producto);
    }

    @GetMapping("/CA")
    public List<DetalleFacturaSimplificada> findByAmount(@RequestParam Integer cantidadInicio,@RequestParam Integer cantidadFin) {
        return service.findByAmount(cantidadInicio,cantidadFin);
    }

    @PostMapping("/BS")
    @ResponseStatus(code = HttpStatus.CREATED)
    public List<DetalleFacturaSimplificada> batchSave(@RequestBody List<DetalleFacturaSimplificada> detallesFacturaSimplificada) {
        return service.batchSave(detallesFacturaSimplificada);
    }

    @PostMapping("/SA")
    @ResponseStatus(code = HttpStatus.CREATED)
    public DetalleFacturaSimplificada save(@RequestBody DetalleFacturaSimplificada detalleFactura) {
        return service.save(detalleFactura);
    }

    @PutMapping()
    @ResponseStatus(code = HttpStatus.ACCEPTED)
    public DetalleFacturaSimplificada update(@RequestParam Long id, @RequestBody DetalleFacturaSimplificada detalleFactura) {
        return service.update(id, detalleFactura);
    }

    @DeleteMapping()
    @ResponseStatus(code = HttpStatus.ACCEPTED)
    public boolean delete(@RequestParam Long id) {
        return service.delete(id);
    }
// </editor-fold>

}
