package com.grupo2.aap.Controller.Fidelizacion;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Component.SecuritySession;
import com.grupo2.aap.Entity.Fidelizacion.DetalleSorteo;
import com.grupo2.aap.Iservice.Fidelizacion.IDetalleSorteoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/dsorteo")
public class DetalleSorteoController {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    @Autowired
    private IDetalleSorteoService service;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos Controladores de Conexión">

    @GetMapping("/ID")
    public Optional<DetalleSorteo> show(@RequestParam Long id) {
        Optional<DetalleSorteo> VDevolucion;

        try{
            VDevolucion=service.findById(id);
        }catch (Exception ex){
            VDevolucion=Optional.empty();
        }

        return VDevolucion;
    }

    @GetMapping("/SO")
    public List<DetalleSorteo> findBySorteo(@RequestParam Long idSorteo) {
        List<DetalleSorteo> VDevolucion;

        try{
            VDevolucion=service.findBySorteo(idSorteo);
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @GetMapping("/PO")
    public List<DetalleSorteo> findByProduct(@RequestParam Long idProducto) {
        List<DetalleSorteo> VDevolucion;

        try{
            VDevolucion=service.findByProduct(idProducto);
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @GetMapping("/DT")
    public List<DetalleSorteo> findByDto(@RequestParam Integer dtoInicio,@RequestParam Integer dtoFin) {
        List<DetalleSorteo> VDevolucion;

        try{
            VDevolucion=service.findByDto(dtoInicio,dtoFin);
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @PostMapping("/SA")
    @ResponseStatus(code = HttpStatus.CREATED)
    public DetalleSorteo save(@RequestBody DetalleSorteo detalleSorteo, HttpSession sesion) {
        DetalleSorteo VDevolucion;
        SecurityCtrl VSecurityCtrl;

        try{
            VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
            if (VSecurityCtrl!=null){
                service.setSecurityCtrl(VSecurityCtrl);
                VDevolucion=service.save(detalleSorteo);
            }else{
                VDevolucion=null;
            }
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @PutMapping()
    @ResponseStatus(code = HttpStatus.ACCEPTED)
    public DetalleSorteo update(@RequestParam Long id,
                                @RequestBody DetalleSorteo detalleSorteo,
                                HttpSession sesion) {
        DetalleSorteo VDevolucion;
        SecurityCtrl VSecurityCtrl;

        try{
            VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
            if (VSecurityCtrl!=null){
                service.setSecurityCtrl(VSecurityCtrl);
                VDevolucion=service.update(id, detalleSorteo);
            }else{
                VDevolucion = null;
            }
        }catch (Exception ex){
            VDevolucion = null;
        }

        return VDevolucion;
    }

    @DeleteMapping()
    @ResponseStatus(code = HttpStatus.ACCEPTED)
    public boolean delete(@RequestParam Long id, HttpSession sesion) {
        boolean VDevolucion;
        SecurityCtrl VSecurityCtrl;

        try{
            VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
            if (VSecurityCtrl!=null){
                service.setSecurityCtrl(VSecurityCtrl);

                VDevolucion=service.delete(id);
            }else{
                VDevolucion=false;
            }
        }catch (Exception ex){
            VDevolucion=false;
        }

        return VDevolucion;
    }
// </editor-fold>

}
