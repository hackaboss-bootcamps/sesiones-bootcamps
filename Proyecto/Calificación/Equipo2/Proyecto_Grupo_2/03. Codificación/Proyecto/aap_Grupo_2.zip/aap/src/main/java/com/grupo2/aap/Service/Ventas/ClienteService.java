package com.grupo2.aap.Service.Ventas;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Ventas.Cliente;
import com.grupo2.aap.IRepository.Ventas.IClienteRepository;
import com.grupo2.aap.Iservice.Ventas.IClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que contiene el Servicio de sobre el Repositorio Clientes
 *
 * */
@Service
public class ClienteService implements IClienteService {


// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Repositorio de Cliente sobre el cual se efectuarán todas las operaciones principales */
    @Autowired
    private IClienteRepository repository;

    /** Sistema de Control de la Seguridad que controlará los accesos por parte de los usuarios y
     * las actividades realizadas por los mismos */
    private SecurityCtrl securityCtrl;


// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Encapsulamiento">


    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    @Override
    public void setSecurityCtrl(SecurityCtrl securityCtrl) {
        this.securityCtrl = securityCtrl;
    }


// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Consultas">

    /**
     * Método que devuelve todos los Clientes de la Base de Datos
     *
     * @return Lista de Clientes de la Base de Datos
     */
    @Override
    public List<Cliente> all() {
        return repository.findAll();
    }

    /**
     * Método que devuelve el cliente cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador del Cliente del que se quiere obtener la información
     * @return Cliente que cumple con los requisitos de búsqueda.
     */
    @Override
    public Optional<Cliente> findById(Long PId) {
        Optional<Cliente> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion=repository.findById(PId);
        }else{
            VDevolucion=Optional.empty();
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de clientes cuyo DNI es el que se introduce
     * por parámetro.
     *
     * @param PDni DNi del cliente sobre el que se realizará la consulta.
     * @return Lista de Clientes cuyo DNI coincide con el parámetro de entrada.
     */
    @Override
    public List<Cliente> findListByDni(String PDni) {
        return repository.findListByDni(PDni);
    }


    /**
     * Método que encuentra la lista de clientes cuyo Atributo nombre contenga
     * el nombre o cadena de caracteres que se introduce por parámetro.
     *
     * @param PNombreCliente Nombre del cliente sobre el que se realizará la consulta.
     * @return Lista de Clientes cuyo Nombre contenga con el parámetro de entrada.
     */
    @Override
    public List<Cliente> findListByName(String PNombreCliente) {
        List<Cliente> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = repository.findListByName(PNombreCliente);
        }else{
            VDevolucion = null;
        }
        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de clientes cuyo Atributo dirección contenga
     * la dirección o cadena de caracteres que se introduce por parámetro.
     *
     * @param PDireccion Dirección del cliente sobre el que se realizará la consulta.
     * @return Lista de Clientes cuya Dirección contenga con el parámetro de entrada.
     */
    @Override
    public List<Cliente> findListByAddress(String PDireccion) {
        List<Cliente> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = repository.findListByAddress(PDireccion);
        }else{
            VDevolucion = null;
        }
        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de clientes cuyo Atributo provincia contenga
     * la provincia o cadena de caracteres que se introduce por parámetro.
     *
     * @param PProvince Provincia del cliente sobre el que se realizará la consulta.
     * @return Lista de Clientes cuya provincia contenga con el parámetro de entrada.
     */
    @Override
    public List<Cliente> findListByProvince(String PProvince) {
        List<Cliente> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = repository.findListByProvince(PProvince);
        }else{
            VDevolucion = null;
        }
        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de clientes cuyo Atributo poblacion contenga
     * la Poblacion o cadena de caracteres que se introduce por parámetro.
     *
     * @param PTown Poblacion del cliente sobre el que se realizará la consulta.
     * @return Lista de Clientes cuya poblacion contenga con el parámetro de entrada.
     */
    @Override
    public List<Cliente> findListByTown(String PTown) {
        List<Cliente> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = repository.findListByTown(PTown);
        }else{
            VDevolucion = null;
        }
        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de clientes cuyo Atributo Codigo Postal contenga
     * el Codigo Postal o cadena de caracteres que se introduce por parámetro.
     *
     * @param PPostalCode Codigo Postal del cliente sobre el que se realizará la consulta.
     * @return Lista de Clientes cuyo Codigo Postal contenga con el parámetro de entrada.
     */
    @Override
    public List<Cliente> findListByPostalCode(String PPostalCode) {
        List<Cliente> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = repository.findListByPostalCode(PPostalCode);
        }else{
            VDevolucion = null;
        }
        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de clientes cuyo Atributo email contenga
     * el email o cadena de caracteres que se introduce por parámetro.
     *
     * @param PEMail EMail del cliente sobre el que se realizará la consulta.
     * @return Lista de Clientes cuyo EMail contenga con el parámetro de entrada.
     */
    @Override
    public List<Cliente> findListByEMail(String PEMail) {
        List<Cliente> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = repository.findListByEmail(PEMail);
        }else{
            VDevolucion = null;
        }
        return VDevolucion;
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de Datos">


    /**
     * Método que Guarda la información del Cliente que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PCliente Entidad Cliente que se desea almacenar.
     * @return Cliente con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public Cliente save(Cliente PCliente) {
        return repository.save(PCliente);
    }

    /**
     * Método que Guarda los cambios de la información del Cliente que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador de la Entidad Cliente que se desea Actualizar.
     * @param PCliente Entidad Cliente que se desea Actualizar.
     * @return Cliente con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public Cliente update(Long PId, Cliente PCliente) {
        Cliente VDevolucion;
        Optional<Cliente> VCliente;

        try{
            VCliente = repository.findById(PId);

            if(!VCliente.isEmpty()){
                PCliente.setId(VCliente.get().getId());

                VDevolucion = repository.save(PCliente);
            }else{
                VDevolucion =null;
            }
        }catch (Exception ex){
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que elimina el Cliente que se introduce por parámetro de la Base de Datos
     *
     * @param PId Identificador del Cliente que se desea Eliminar.
     * @return Sí se ha realizado o no correctamente la operacion
     */
    @Override
    public boolean delete(Long PId) {
        boolean VDevolucion;
        Optional<Cliente> VCliente;

        if (this.securityCtrl.isAdministrator()){
            VCliente = this.findById(PId);

            if (!VCliente.isEmpty()){
                VCliente.get().setFechaEliminacion(LocalDateTime.now());
                VDevolucion = (this.save(VCliente.get())!=null);
            }else{
                VDevolucion=false;
            }
        }else{
            VDevolucion=false;
        }

        return VDevolucion;
    }

// </editor-fold>

}
