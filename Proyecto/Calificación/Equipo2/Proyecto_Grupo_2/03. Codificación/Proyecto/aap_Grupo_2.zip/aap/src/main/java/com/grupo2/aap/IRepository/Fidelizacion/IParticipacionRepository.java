package com.grupo2.aap.IRepository.Fidelizacion;

import com.grupo2.aap.Entity.Fidelizacion.Participacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que permite la ejecución de las cláusulas SQL necesarias para servir de repositorio de
 * la entidad Participación.
 *
 * */
@Repository
public interface IParticipacionRepository extends JpaRepository<Participacion,Long> {
    /**
     * Método que encuentra la lista de participacion cuyo Atributo Numero es el que se introduce
     * por parámetro.
     *
     * @param PNumero Número sobre el que se realizará la consulta.
     * @return Lista de Participación cuyo Número coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT * " +
            "FROM participaciones " +
            "WHERE numero = :numero",nativeQuery = true)
    List<Participacion> findByNumber(@Param("numero") Integer PNumero);

    /**
     * Método que encuentra la lista de participacion cuyo Atributo Factura Aplicación es el que se introduce
     * por parámetro.
     *
     * @param PIdFactura Identificador de la Factura en la que se aplicado la Participación
     * @return Lista de Participación cuyo Número coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT * " +
            "FROM participaciones " +
            "WHERE factura_aplicacion = :idFactura",nativeQuery = true)
    List<Participacion> findByApplicationInvoice(@Param("idFactura") Long PIdFactura);

    /**
     * Método que encuentra la lista de participacion cuyo Atributo Factura Generación es el que se introduce
     * por parámetro.
     *
     * @param PIdFactura Identificador de la Factura que ha generado la participación
     * @return Lista de Participación cuyo Número coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT * " +
            "FROM participaciones " +
            "WHERE factura_generacion = :idFactura",nativeQuery = true)
    List<Participacion> findByGenerationInvoice(@Param("idFactura") Long PIdFactura);

    /**
     * Método que encuentra la lista de detalle sorteo  cuyo Atributo Fecha Máxima Validez es el que se introduce
     * por parámetro.
     *
     * @param PFechaInicio Fecha Inicial sobre la que se realizará la consulta.
     * @param PFechaFin Fecha Final sobre la que se realizará la consulta.
     * @return Lista de Participación  cuya FechaInicio y FechaFin coincide con los parámetros de entrada.
     */
    @Query(value = "SELECT * " +
            "FROM participaciones " +
            "WHERE (fecha_max_validez BETWEEN :fechaInicio AND :fechaFin)",nativeQuery = true)
    List<Participacion> findByMaxValidityDate(@Param("fechaInicio") LocalDateTime PFechaInicio, @Param("fechaFin") LocalDateTime PFechaFin);

    /**
     * Método que encuentra la lista de detalle sorteo  cuyo Atributo Fecha Anulación es el que se introduce
     * por parámetro.
     *
     * @param PFechaInicio Fecha Inicial sobre la que se realizará la consulta.
     * @param PFechaFin Fecha Final sobre la que se realizará la consulta.
     * @return Lista de Participación  cuya FechaInicio y FechaFin coincide con los parámetros de entrada.
     */
    @Query(value = "SELECT * " +
            "FROM participaciones " +
            "WHERE (fecha_anulacion BETWEEN :fechaInicio AND :fechaFin)",nativeQuery = true)
    List<Participacion> findByCancelDate(@Param("fechaInicio") LocalDateTime PFechaInicio, @Param("fechaFin") LocalDateTime PFechaFin);

    /**
     * Método que encuentra la lista de participacion cuyo Atributo Sorteo es el que se introduce
     * por parámetro.
     *
     * @param PSorteo sorteo sobre el que se realizará la consulta.
     * @return Lista de Participación cuyo Sorteo coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT * " +
            "FROM participaciones " +
            "WHERE sorteo = :sorteo",nativeQuery = true)
    List<Participacion> findByDraw(@Param("sorteo") Long PSorteo);

    /**
     * Método que encuentra la lista de participaciones que han sido premiadas en el Sorteo
     * que se introduce por parámetro.
     *
     * @param PSorteo sorteo sobre el que se realizará la consulta.
     * @return Lista de Participaciones que han sido premiadas
     */
    @Query(value = "SELECT * " +
            "FROM participaciones " +
            "WHERE sorteo = :sorteo AND NOT fecha_max_validez IS NULL",nativeQuery = true)
    List<Participacion> findByWinnersDraw(@Param("sorteo") Long PSorteo);

    /**
     * Método que Devuelve el número de la Siguiente Participación; con el objetivo
     * de que no se dupliquen
     *
     * @param PSorteo sorteo sobre el que se realizará la consulta.
     * @return Número nuevo que debe llevar una nueva participación para que no se repita.
     */
    @Query(value = "SELECT MAX(numero)+1 AS NuevoNumero " +
            "FROM participaciones " +
            "WHERE sorteo = :sorteo",nativeQuery = true)
    Integer findNewNumber(@Param("sorteo") Long PSorteo);


}