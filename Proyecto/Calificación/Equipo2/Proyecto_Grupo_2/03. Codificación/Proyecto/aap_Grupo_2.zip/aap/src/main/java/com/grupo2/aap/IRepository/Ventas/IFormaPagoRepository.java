package com.grupo2.aap.IRepository.Ventas;

import com.grupo2.aap.Entity.Ventas.FormaPago;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que permite la ejecución de las cláusulas SQL necesarias para servir de repositorio de
 * la entidad Forma Pago.
 *
 * */
@Repository
public interface IFormaPagoRepository extends JpaRepository<FormaPago,Long> {

    /**
     * Método que encuentra la lista Formas de  Pago cuyo Atributo Nombre contenga
     * el Nombre o cadena de caracteres que se introduce por parámetro.
     *
     * @param PNombre Nombre de la familia de Formas de Pago sobre el que se realizará la consulta.
     * @return Lista de Forma Pago cuyo nombre contenga con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM formas_pago " +
            "WHERE nombre LIKE %:nombre%", nativeQuery = true)
    List<FormaPago> findByName(@Param("nombre") String PNombre);


}
