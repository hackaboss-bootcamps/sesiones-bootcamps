package com.grupo2.aap.Iservice.Ventas;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Ventas.Component.DetalleFacturaData;
import com.grupo2.aap.Entity.Ventas.Factura;
import com.grupo2.aap.Entity.Ventas.FacturaExtendida;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que será de obligada implementación por parte del servicio asociado.
 *
 * */
public interface IFacturaService {

    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    void setSecurityCtrl(SecurityCtrl securityCtrl);

    /**
     * Método que devuelve todas las Facturas de la Base de Datos
     *
     * @return Lista de Facturas de la Base de Datos
     */
    List<Factura> all();

    /**
     * Método que devuelve la factura cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador de la factura  de la que se quiere obtener la información
     * @return Factura que cumple con los requisitos de búsqueda.
     */
    Optional<Factura> findById(Long PId);

    /**
     * Método que encuentra la lista de facturas cuyo Atributo Número es el que se introduce
     * por parámetro.
     *
     * @param PNumero Número sobre el que se realizará la consulta.
     * @return Lista de Factura  cuyo Número contenga con el parámetro de entrada.
     */
    List<Factura> findListByNumber(Long PNumero);

    /**
     * Método que encuentra la lista de facturas cuyo Atributo Fecha es el que se introduce
     * por parámetro.
     *
     * @param PFechaInicio Fecha Inicial sobre la que se realizará la consulta
     * @param PFechaFin Fecha Final sobre la que se realizará la consulta
     * @return Lista de Facturas cuya FechaInicio y FechaFin coincide con los parámetros de entrada.
     */
    List<Factura> findByDate(LocalDateTime PFechaInicio, LocalDateTime PFechaFin);

    /**
     * Método que encuentra la lista de facturas cuyo Atributo Forma de Pago es el que se introduce
     * por parámetro.
     *
     * @param PFormaPago Forma de Pago sobre la que se realizará la consulta.
     * @return Lista de Facturas  cuya Forma de Pago contenga con el parámetro de entrada.
     */
    List<Factura> findByWay2Pay(Long PFormaPago);

    /**
     * Método que encuentra la lista de facturas cuyo Atributo Observaciones contenga
     * las Observaciones o cadena de caracteres que se introduce por parámetro.
     *
     * @param PObservaciones Observaciones sobre la que se realizará la consulta.
     * @return Lista de Facturas  cuyas Observaciones contenga con el parámetro de entrada.
     */
    List<Factura> findByRemarks(String PObservaciones);

    /**
     * Método que encuentra la lista de facturas cuyo Atributo Cliente es el que se introduce
     * por parámetro.
     *
     * @param PIdCliente Id Cliente sobre el que se realizará la consulta.
     * @return Lista de Facturas  cuyo IdCliente coincide con el parámetro de entrada.
     */
    List<Factura> findByClient(Long PIdCliente);

    /**
     * Método que devuelve la FacturaExtendida cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador de la factura  de la que se quiere obtener la información
     * @return Factura Extendida que cumple con los requisitos de búsqueda.
     */
    FacturaExtendida findExtInvoiceById(Long PId);

    /**
     * Método que Genera una factura en función del Objeto que se introduce por parámetro
     *
     * @param PFactura Objeto Factura que contiene los datos de la Nueva Factura
     * @return Imagen de la factura que se ha dado de alta en la Capa de Persistencia
     */
    Factura generarFactura(Factura PFactura);

    /**
     * Método que Genera una factura Extendida en función del Objeto que se introduce por parámetro
     *
     * @param PFactura Objeto Factura Extendida que contiene los datos de la Nueva Factura
     * @return Imagen de la factura Extendida que se ha dado de alta en la Capa de Persistencia
     */
    boolean generarFactura(FacturaExtendida PFactura);

    /**
     * Método que Aplica una participación premiada a la Factura cuyo Id se introduce por parámetro
     *
     * @param PIdFactura Identificador de la Factura a la que se le va a aplicar el premio.
     * @param PIdParticipacion Participación que se aplicará a la factura que se introduce por parámetro.
     * @return Factura Extendia con los beneficios del sorteo aplicados.
     */
    FacturaExtendida aplicarParticipacion(Long PIdFactura,Long PIdParticipacion);

    /**
     * Método que Aplica una participación premiada a la Factura cuyo Id se introduce por parámetro
     *
     * @param PFactura Objeto Factura a la que se le va a aplicar el premio.
     * @param PIdParticipacion Participación que se aplicará a la factura que se introduce por parámetro.
     * @return Factura Extendia con los beneficios del sorteo aplicados.
     */
    FacturaExtendida aplicarParticipacion(Factura PFactura,Long PIdParticipacion);

    /**
     * Método que Guarda la información de la Factura que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PFactura Entidad Factura que se desea almacenar.
     * @return Factura con los datos que han sido guardados en la Base de Datos
     */
    Factura save(Factura PFactura);

    /**
     * Método que Guarda la información de la Factura y sus Detalles que se introducen por parámetro en la
     * Base de Datos
     *
     * @param PFactura Entidad FacturaExtendida que se desea almacenar.
     * @return Factura con los datos que han sido guardados en la Base de Datos
     */
    FacturaExtendida save(FacturaExtendida PFactura);

    /**
     * Método que Guarda los cambios de la información de la Factura e que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador de la Entidad Factura que se desea Actualizar.
     * @param PFactura Entidad Factura que se desea Actualizar.
     * @return Factura con los datos que han sido guardados en la Base de Datos
     */
    Factura update(Long PId, Factura PFactura);

    /**
     * Método que elimina la Factura  que se introduce por parámetro de la Base de Datos
     *
     * @param PId Identificador de la Factura que se desea Eliminar.
     */
    boolean delete(Long PId);


}
