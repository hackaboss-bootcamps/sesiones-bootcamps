package com.grupo2.aap.Controller.Ventas;

import com.grupo2.aap.Entity.Ventas.DetalleFactura;
import com.grupo2.aap.Iservice.Ventas.IDetalleFacturaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/dfactura")
public class DetalleFacturaController {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    @Autowired
    private IDetalleFacturaService service;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos Controladores de Conexión">


    @GetMapping("/ID")
    public Optional<DetalleFactura> show(@RequestParam Long id) {
        return service.findById(id);
    }

    @GetMapping("/FA")
    public List<DetalleFactura> findByInvoice(@RequestParam Long numero) {
        return service.findByInvoice(numero);
    }

    @GetMapping("/PO")
    public List<DetalleFactura> findByProduct(@RequestParam Long producto) {
        return service.findByProduct(producto);
    }

    @GetMapping("/CA")
    public List<DetalleFactura> findByAmount(@RequestParam Integer cantidadInicio,@RequestParam Integer cantidadFin) {
        return service.findByAmount(cantidadInicio,cantidadFin);
    }

    @PostMapping("/BS")
    @ResponseStatus(code = HttpStatus.CREATED)
    public List<DetalleFactura> batchSave(@RequestBody List<DetalleFactura> detallesFactura) {
        return service.batchSave(detallesFactura);
    }

    @PostMapping("/SA")
    @ResponseStatus(code = HttpStatus.CREATED)
    public DetalleFactura save(@RequestBody DetalleFactura detalleFactura) {
        return service.save(detalleFactura);
    }

    @PutMapping()
    @ResponseStatus(code = HttpStatus.ACCEPTED)
    public DetalleFactura update(@RequestParam Long id, @RequestBody DetalleFactura detalleFactura) {
        return service.update(id, detalleFactura);
    }

    @DeleteMapping()
    @ResponseStatus(code = HttpStatus.ACCEPTED)
    public boolean delete(@RequestParam Long id) {
        return service.delete(id);
    }

// </editor-fold>

}
