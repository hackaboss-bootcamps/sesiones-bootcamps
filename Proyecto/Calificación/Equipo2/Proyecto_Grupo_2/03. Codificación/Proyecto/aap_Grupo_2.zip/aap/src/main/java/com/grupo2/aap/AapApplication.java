package com.grupo2.aap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Este programa se ha realizado como Proyecto final del Curso de Java de HackaBoss
 * La Aplicación trata de dar respuesta a las necesidades de una tienda a la cual hay que proveer de un sistema
 * en red confiable y con diversidad de opciones. Entre esta opciones destacan la gestión de acceso, las ventas y
 * los métodos de fidelizacion mediante sorteos.
 *
 *@autor Francisco Javier Ferreiros Lopez
 *@autor Inaki Suarez Valdivielso
 *@autor Jose Luis Zaragoza Castro
 *@version 1.0
 *
 */
@SpringBootApplication
public class AapApplication {

	public static void main(String[] args) {
		SpringApplication.run(AapApplication.class, args);
	}

}
