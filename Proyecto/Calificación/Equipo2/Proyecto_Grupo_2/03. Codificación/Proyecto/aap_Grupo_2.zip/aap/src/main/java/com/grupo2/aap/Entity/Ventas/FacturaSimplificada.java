package com.grupo2.aap.Entity.Ventas;

import com.grupo2.aap.Entity.Ventas.Component.FacturaData;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que implementa la Entidad de FacturaSimplificada. Esta clase contendrá la información básica y las operaciones
 * Básicas con dicha información.
 *
 * */
@Entity
@Table(name="facturas_simplificadas")
public class FacturaSimplificada extends FacturaData {

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de Datos">

    /**
     * Método que Clona la información de otra entidad facturasimplificada en sí misma.
     *
     * @param PFacturaSimplificadaClonar FacturaSimplificada cuyos parámetros se desean clonar.
     * @return Sí se ha realizado correctamente o no la operación.
     */
    public boolean clone(FacturaSimplificada PFacturaSimplificadaClonar){
        boolean VDevolucion;

        try{
            super.clone(PFacturaSimplificadaClonar);

            VDevolucion=true;
        }catch (Exception ex){
            VDevolucion=false;
        }

        return VDevolucion;
    }

// </editor-fold>


}