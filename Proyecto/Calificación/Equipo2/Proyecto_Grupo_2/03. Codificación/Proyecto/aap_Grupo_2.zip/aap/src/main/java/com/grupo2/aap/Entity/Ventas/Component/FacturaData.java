package com.grupo2.aap.Entity.Ventas.Component;

import com.grupo2.aap.Entity.Ventas.FacturaSimplificada;
import com.grupo2.aap.Entity.Ventas.FormaPago;
import com.sun.xml.bind.v2.runtime.unmarshaller.DefaultValueLoaderDecorator;

import java.security.Timestamp;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;


@MappedSuperclass



public  class FacturaData {

    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "numero", unique = true, nullable = false)
    private Long numero;

    @Column(name = "fecha",nullable = false)
    private LocalDateTime fecha;

    @Column(name = "dto_porcentaje",  nullable = true)
    private Integer dtoPorcentaje=0;

    @Column(name = "observaciones", nullable = true)
    private String observaciones;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "forma_pago", nullable = false)
    private FormaPago formaPago;

    @Column(name = "fecha_anulacion", nullable = true)
    private LocalDateTime fechaAnulacion;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getNumero() {
        return numero;
    }

    public void setNumero(Long numero) {
        this.numero = numero;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }

    public Integer getDtoPorcentaje() {
        return dtoPorcentaje;
    }

    public void setDtoPorcentaje(Integer dtoPorcentaje) {
        this.dtoPorcentaje = dtoPorcentaje;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public FormaPago getFormaPago() {
        return formaPago;
    }

    public void setFormaPago(FormaPago formaPago) {
        this.formaPago = formaPago;
    }

    public LocalDateTime getFechaAnulacion() {
        return fechaAnulacion;
    }

    public void setFechaAnulacion(LocalDateTime fechaAnulacion) {
        this.fechaAnulacion = fechaAnulacion;
    }


    public boolean clone(FacturaData PFacturaClonar){
        boolean VDevolucion;

        try{
            this.setId(PFacturaClonar.getId());
            this.setNumero(PFacturaClonar.getNumero());
            this.setFecha(PFacturaClonar.getFecha());
            this.setDtoPorcentaje(PFacturaClonar.getDtoPorcentaje());
            this.setFormaPago(PFacturaClonar.getFormaPago());
            this.setFechaAnulacion(PFacturaClonar.getFechaAnulacion());

            VDevolucion = true;
        }catch (Exception ex){
            VDevolucion = false;
        }

        return VDevolucion;
    }

}

