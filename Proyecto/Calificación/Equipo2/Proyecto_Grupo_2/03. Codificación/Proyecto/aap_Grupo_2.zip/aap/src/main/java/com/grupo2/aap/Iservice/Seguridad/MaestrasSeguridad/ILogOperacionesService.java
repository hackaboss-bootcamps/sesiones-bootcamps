package com.grupo2.aap.Iservice.Seguridad.MaestrasSeguridad;

import com.grupo2.aap.Entity.Seguridad.MaestrasSeguridad.LogOperaciones;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que será de obligada implementación por parte del servicio asociado.
 *
 * */
public interface ILogOperacionesService {

    /**
     * Método que devuelve todas las Operaciones de seguridad de la Base de Datos
     *
     * @return Lista de log de Operaciones de seguridad de la Base de Datos
     */
    List<LogOperaciones> all();

    /**
     * Método que devuelve Operación de seguridad cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador del log de ventas de seguridad del que se quiere obtener la información
     * @return Lista de Operaicones de seguridad que cumple con los requisitos de búsqueda.
     */
    Optional<LogOperaciones> findById(Long PId);

    /**
     * Método que devuelve Operación de seguridad cuyo Nombre Coincide total o parcialmente con el
     * introducir por parámetro.
     *
     * @param PNombre Nombre de la Operación que se desea consultar
     * @return Lista de Operaciones de seguridad que cumple con los requisitos de búsqueda.
     */
    List<LogOperaciones> findListByName(String PNombre);

    /**
     * Método que Guarda la información de la Operación de seguridad que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PLogOperacion Entidad del log de Operación de seguridad que se desea almacenar.
     * @return Operación de seguridad que se ha guardado
     */
    LogOperaciones save(LogOperaciones PLogOperacion);

    /**
     * Método que Actualiza la información de la Operación de seguridad que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador de la Operación de Seguridad que se desea Actualizar.
     * @param PLogOperacion Entidad del log de Operaciónn de seguridad que se desea almacenar.
     */
    void update(Long PId, LogOperaciones PLogOperacion);

    /**
     * Método que Elimina la información de la Operación de seguridad que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador de la Operación de Seguridad que se desea Eliminar.
     */
    void delete(Long PId);


}
