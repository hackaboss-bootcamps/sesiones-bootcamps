package com.grupo2.aap.IRepository.Ventas;

import com.grupo2.aap.Entity.Ventas.FamiliaProducto;
import com.grupo2.aap.Entity.Ventas.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que permite la ejecución de las cláusulas SQL necesarias para servir de repositorio de
 * la entidad Familia Producto.
 *
 * */
@Repository
public interface IFamiliaProductoRepository extends JpaRepository<FamiliaProducto,Long> {

    /**
     * Método que encuentra la lista familia productos cuyo Atributo Nombre contenga
     * el Nombre o cadena de caracteres que se introduce por parámetro.
     *
     * @param PNombre Nombre de la familia de producto sobre el que se realizará la consulta.
     * @return Lista de Familias de  Productos cuyo nombre contenga con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM familias_productos " +
            "WHERE nombre LIKE %:nombre% " +
                    "AND fecha_eliminacion IS NULL", nativeQuery = true)
    List<FamiliaProducto> findListByName(@Param("nombre") String PNombre);

    /**
     * Método que encuentra la lista familia productos cuyo Atributo FamiliaPadre es el que se introduce
     *por parámetro.
     *
     * @param familiaProducto de la familia de producto sobre el que se realizará la consulta.
     * @return Lista de Familias de  Productos cuyo familia producto coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM familias_productos " +
            "WHERE familia_padre = familiaProducto " +
            "AND fecha_eliminacion IS NULL", nativeQuery = true)
    List<FamiliaProducto> findListByFamily(@Param("familiaProducto") Long familiaProducto);


}
