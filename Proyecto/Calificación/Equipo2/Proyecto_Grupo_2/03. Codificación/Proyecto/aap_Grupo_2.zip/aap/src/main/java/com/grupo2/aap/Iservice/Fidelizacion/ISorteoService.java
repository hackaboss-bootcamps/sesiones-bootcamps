package com.grupo2.aap.Iservice.Fidelizacion;


import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Fidelizacion.DetalleSorteo;
import com.grupo2.aap.Entity.Fidelizacion.Participacion;
import com.grupo2.aap.Entity.Fidelizacion.Sorteo;
import com.grupo2.aap.Entity.Ventas.Factura;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que será de obligada implementación por parte del servicio asociado.
 *
 * */
public interface ISorteoService {


// <editor-fold defaultstate="collapsed" desc="Métodos para el Control de la Seguridad">

    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    void setSecurityCtrl(SecurityCtrl securityCtrl);

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Consultas">

    /**
     * Método que devuelve todos los Sorteos de la Base de Datos
     *
     * @return Lista de Sorteos de la Base de Datos
     */
    List<Sorteo> all();

    /**
     * Método que devuelve el Sorteo cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador del Sorteo del que se quiere obtener la información
     * @return Sorteo que cumple con los requisitos de búsqueda.
     */
    Optional<Sorteo> findById(Long PId);

    /**
     * Método que encuentra la lista de Sorteos cuyo Atributo nombre contenga
     * el nombre o cadena de caracteres que se introduce por parámetro.
     *
     * @param PNombre Nombre del Sorteo sobre el que se realizará la consulta.
     * @return Lista de Sorteos cuyo Nombre contenga con el parámetro de entrada.
     */
    List<Sorteo> findByNombre(String PNombre);

    /**
     * Método que encuentra la lista de Sorteos Cuya Fecha de Creación
     * está entre la Fecha de Inicio y de Fin
     *
     * @param PFechaInicio Fecha de Inicio sobre la que se quiere hacer la consulta
     * @param PFechaFin Fecha de Fin sobre la que se quiere hacer la consulta
     * @return Lista de Sorteos que cumplan la condición
     */
    List<Sorteo> findByCreationDate(LocalDateTime PFechaInicio, LocalDateTime PFechaFin);

    /**
     * Método que encuentra la lista de Sorteos Cuya Fecha de Inicio
     * está entre la Fecha de Inicio y de Fin
     *
     * @param PFechaInicio Fecha de Inicio sobre la que se quiere hacer la consulta
     * @param PFechaFin Fecha de Fin sobre la que se quiere hacer la consulta
     * @return Lista de Sorteos que cumplan la condición
     */
    List<Sorteo> findByStartDate(LocalDateTime PFechaInicio, LocalDateTime PFechaFin);

    /**
     * Método que encuentra la lista de Sorteos Cuya Fecha de Finalización
     * está entre la Fecha de Inicio y de Fin
     *
     * @param PFechaInicio Fecha de Inicio sobre la que se quiere hacer la consulta
     * @param PFechaFin Fecha de Fin sobre la que se quiere hacer la consulta
     * @return Lista de Sorteos que cumplan la condición
     */
    List<Sorteo> findByFinalizeDate(LocalDateTime PFechaInicio, LocalDateTime PFechaFin);

    /**
     * Método que encuentra la lista de Sorteos Cuya Descuento por tarjeta de regalo
     * está entre el Dto de Inicio y de Fin
     *
     * @param PDtoInicio Valor del Descuento de Inicio sobre la que se quiere hacer la consulta
     * @param PDtoFin Valor del Descuento de Fin sobre la que se quiere hacer la consulta
     * @return Lista de Sorteos que cumplan la condición
     */
    List<Sorteo> findByDtoPresentCard(Double PDtoInicio,Double PDtoFin);

    /**
     * Método que encuentra la lista de Sorteos Cuya Descuento en factura
     * está entre el Dto de Inicio y de Fin
     *
     * @param PDtoInicio Valor del Descuento de Inicio sobre la que se quiere hacer la consulta
     * @param PDtoFin Valor del Descuento de Fin sobre la que se quiere hacer la consulta
     * @return Lista de Sorteos que cumplan la condición
     */
    List<Sorteo> findByDtoInvoice(Integer PDtoInicio,Integer PDtoFin);

    /**
     * Método que encuentra la lista de Sorteos cuyos días en la que la participación es válida
     * está entre el Número de Días de Inicio y de Fin
     *
     * @param PNumeroDiasInicio Número de días de Inicio sobre la que se quiere hacer la consulta
     * @param PNumeroDiasFin Número de días de Fin sobre la que se quiere hacer la consulta
     * @return Lista de Sorteos que cumplan la condición
     */
    List<Sorteo> findByDaysParticipation(Integer PNumeroDiasInicio, Integer PNumeroDiasFin);

    /**
     * Método que encuentra la lista de Sorteos cuyo número máximo de Ganadores
     * está entre el Número de Inicio y de Fin
     *
     * @param PNumeroInicio Número de Ganadores máximo de Inicio sobre la que se quiere hacer la consulta
     * @param PNumeroFin Número de Ganadores Máximo de Fin sobre la que se quiere hacer la consulta
     * @return Lista de Sorteos que cumplan la condición
     */
    List<Sorteo> findByMaxWinners(Integer PNumeroInicio,Integer PNumeroFin);

    /**
     * Método que encuentra la lista de Detalles de Sorteos cuyo Número de Sorteo es el que se introduce
     * por parámetro
     *
     * @param PSorteo Sorteo sobre el que se quiere consultar
     * @return Lista de Sorteos que cumplan la condición
     */
    List<DetalleSorteo> findDetallesSorteo(Sorteo PSorteo);

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de la Persistencia">

    // <editor-fold defaultstate="collapsed" desc="Gestión de Participaciones">

    /**
     * Método que premia las Participaciones que se introducen por parámetro
     *
     * @param PParticipacionesPremiadas Particiones premiadas
     * @param PSorteo Sorteo al cual pertenecen las participaciones
     * @return Lista de Participaciones premiadas con marca de Fecha de Máxima Validez
     */
    List<Participacion> premiarParticipaciones(List<Participacion> PParticipacionesPremiadas, Sorteo PSorteo);

    /**
     * Método que Genera una participación y le asigna la Factura por la cual se ha generado
     *
     * @param PFactura Factura que a generado la participación
     * @return Participación Generada
     */
    Participacion generarParticipacion(Factura PFactura);

    /**
     * Método que Genera una participación para el Sorteo que se introduce por parámetro y le
     * Asigna la Factura por la cual se ha generado
     *
     * @param PSorteo Sorteo para la cual es la participación
     * @param PFactura Factura que a generado la participación
     * @return Participación Generada
     */
    Participacion generarParticipacion(Sorteo PSorteo, Factura PFactura);

    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Herramientas de la Clase">

    /**
     * Método que realiza el sorteo aleatorio y devuelve la lista de Participaciones premiadas
     *
     * @return Lista de Participaciones Premiadas
     */
    List<Participacion> realizarSorteo();

    /**
     * Método que Guarda la información del Sorteo que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PSorteo Entidad Sorteo que se desea almacenar.
     * @return Sorteo con los datos que han sido guardados en la Base de Datos
     */
    Sorteo save(Sorteo PSorteo);

    /**
     * Método que Guarda los cambios de la información del Sorteo que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador de la Entidad Sorteo que se desea Actualizar.
     * @param PSorteo Entidad Sorteo que se desea Actualizar.
     * @return Sorteo con los datos que han sido guardados en la Base de Datos
     */
    Sorteo update(Long PId, Sorteo PSorteo);

    /**
     * Método que elimina el Sorteo que se introduce por parámetro de la Base de Datos
     *
     * @param PId Identificador del Sorteo que se desea Eliminar.
     * @return Sí se ha realizado o no correctamente la operacion
     */
    boolean delete(Long PId);

    // </editor-fold>

// </editor-fold>

}

