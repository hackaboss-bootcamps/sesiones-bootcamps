package com.grupo2.aap.Entity.Seguridad.MaestrasSeguridad;

import com.grupo2.aap.Entity.Seguridad.LogsOperaciones.LogAdministracion;

import javax.persistence.*;

@Entity
@Table(name="log_operaciones")
public class LogOperaciones {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "nombre",length = 50, nullable = false)

    private String nombre;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public boolean clone(LogOperaciones PLogClonar){
        boolean VDevolucion;

        try{
            this.setId(PLogClonar.getId());
            this.setNombre(PLogClonar.getNombre());

            VDevolucion = true;
        }catch (Exception ex){
            VDevolucion = false;
        }

        return VDevolucion;
    }

}