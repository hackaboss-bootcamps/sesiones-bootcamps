package com.grupo2.aap.IRepository.Ventas;

import com.grupo2.aap.Entity.Ventas.Factura;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que permite la ejecución de las cláusulas SQL necesarias para servir de repositorio de
 * la entidad Factura
 *
 * */
@Repository
public interface IFacturaRepository extends JpaRepository<Factura,Long> {

    /**
     * Método que encuentra en la lista de facturas el número de factura más alto al que le sumamos uno.
     *
     * @return El resultado de esta consulta será un número que representa el próximo número de factura que se puede asignar
     */
    @Query(value = "SELECT  MAX(numero)+1 AS NextInvoiceNumber " +
                        "FROM facturas", nativeQuery = true)
    Long findInvoiceNextNumber();

    /**
     * Método que encuentra la lista de facturas cuyo Atributo Número es el que se introduce
     * por parámetro.
     *
     * @param PNumero Número sobre el que se realizará la consulta.
     * @return Lista de Facturas  cuyo Número coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM facturas " +
            "WHERE numero = :numero", nativeQuery = true)
    List<Factura> findByNumber(@Param("numero") Long PNumero);

    /**
     * Método que encuentra la lista de facturas cuyo Atributo Fecha es el que se introduce
     * por parámetro.
     *
     * @param PFechaInicio Fecha Inicial sobre la que se realizará la consulta
     * @param PFechaFin Fecha Final sobre la que se realizará la consulta
     * @return Lista de Facturas cuya FechaInicio y FechaFin coincide con los parámetros de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM facturas " +
            "WHERE fecha BETWEEN :fechaInicio AND :fechaFin", nativeQuery = true)
    List<Factura> findByDate(@Param("fechaInicio") LocalDateTime PFechaInicio,@Param("fechaFin") LocalDateTime PFechaFin);

    /**
     * Método que encuentra la lista de facturas cuyo Atributo Forma de Pago es el que se introduce
     * por parámetro.
     *
     * @param PFormaPago Forma de Pago sobre la que se realizará la consulta.
     * @return Lista de Facturas  cuya Forma de Pago coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM facturas " +
            "WHERE forma_pago = :formaPago", nativeQuery = true)
    List<Factura> findByFormaWay2Pay(@Param("formaPago") Long PFormaPago);

    /**
     * Método que encuentra la lista de facturas cuyo Atributo Observaciones contenga
     * las Observaciones o cadena de caracteres que se introduce por parámetro.
     *
     * @param PObservaciones Observaciones sobre la que se realizará la consulta.
     * @return Lista de Facturas  cuyas Observaciones contenga con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM facturas " +
            "WHERE observaciones LIKE %:observaciones%", nativeQuery = true)
    List<Factura> findByRemarks(@Param("observaciones") String PObservaciones);

    /**
     * Método que encuentra la lista de facturas cuyo Atributo Cliente es el que se introduce
     * por parámetro.
     *
     * @param PIdCliente Id Cliente sobre el que se realizará la consulta.
     * @return Lista de Facturas  cuyo IdCliente coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT  * " +
            "FROM facturas " +
            "WHERE cliente = :cliente", nativeQuery = true)
    List<Factura> findByClient(@Param("cliente") Long PIdCliente);


}
