package com.grupo2.aap.Iservice.Seguridad.LogsSeguridad;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Seguridad.LogsSeguridad.SecLogVentas;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que será de obligada implementación por parte del servicio asociado.
 *
 * */
public interface ISecLogVentasService {

    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    void setSecurityCtrl(SecurityCtrl securityCtrl);

    /**
     * Método que devuelve todos los log de ventas de seguridad de la Base de Datos
     *
     * @return Lista de log de ventas de seguridad de la Base de Datos
     */
    List<SecLogVentas> all();

    /**
     * Método que devuelve el log de ventas de seguridad cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador del log de ventas de seguridad del que se quiere obtener la información
     * @return Log de ventas de seguridad que cumple con los requisitos de búsqueda.
     */
    Optional<SecLogVentas> findById(Long PId);

    /**
     * Método que encuentra la lista de log de ventas de seguridad cuya operacion es la que se introduce
     * por parámetro.
     *
     * @param POperacion Operacion del log de ventas de seguridad sobre el que se realizará la consulta.
     * @return Lista de log de ventas de seguridad cuya operacion coincide con el parámetro de entrada.
     */
    List<SecLogVentas> findListByOperation(Long POperacion);

    /**
     * Método que encuentra la lista de log de ventas de seguridad cuyo tipo de entidad es el que se introduce
     * por parámetro.
     *
     * @param PTipoEntidad Tipo de entidad del log de ventas de seguridad sobre el que se realizará la consulta.
     * @return Lista de log de ventas de seguridad cuyo tipo de entidad coincide con el parámetro de entrada.
     */
    List<SecLogVentas> findListByTypeOfEntity(Long PTipoEntidad);

    /**
     * Método que encuentra la lista de log de ventas de seguridad cuya entidad es la que se introduce
     * por parámetro.
     *
     * @param PEntidad Entidad del log de ventas de seguridad sobre la que se realizará la consulta.
     * @return Lista de log de ventas de seguridad cuya entidad coincide con el parámetro de entrada.
     */
    List<SecLogVentas> findListByEntity(Long PEntidad);

    /**
     * Método que encuentra la lista de log de ventas de seguridad cuya fecha inicial y fecha final son las que se introducen
     * por parámetro.
     * @param PFechaInicio Fecha inicial del log de ventas de seguridad sobre la que se realizará la consulta.
     * @param PFechaFin Fecha final del log de ventas de seguridad sobre la que se realizará la consulta.
     * @return Lista de log de ventas de seguridad cuyas fechas iniciales y fechas finales coincide con el parámetro de entrada.
     */
    List<SecLogVentas> findByDate(LocalDateTime PFechaInicio, LocalDateTime PFechaFin);

    /**
     * Método que encuentra la lista de log de ventas de seguridad cuyo usuario es el que se introduce
     * por parámetro.
     *
     * @param PUsuario Usuario del log de ventas de seguridad sobre el que se realizará la consulta.
     * @return Lista de log de ventas de seguridad cuyo usuario coincide con el parámetro de entrada.
     */
    List<SecLogVentas> findListByUser(Long PUsuario);

    /**
     * Método que encuentra la lista de log de ventas de seguridad cuyo mensaje es el que se introduce
     * por parámetro.
     *
     * @param PMensaje Mensaje del log de ventas de seguridad sobre el que se realizará la consulta.
     * @return Lista de log de ventas de seguridad cuyo mensaje coincide con el parámetro de entrada.
     */
    List<SecLogVentas> findListByMessage(String PMensaje);

    /**
     * Método que Guarda la información del log de ventas de seguridad que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PSecLogVentas Entidad del log de ventas de seguridad que se desea almacenar.
     * @return Log de ventas de seguridad con los datos que han sido guardados en la Base de Datos
     */
    SecLogVentas save(SecLogVentas PSecLogVentas);

}
