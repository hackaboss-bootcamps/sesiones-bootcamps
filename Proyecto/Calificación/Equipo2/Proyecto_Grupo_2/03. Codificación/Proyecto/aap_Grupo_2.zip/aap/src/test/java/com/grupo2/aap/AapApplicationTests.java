package com.grupo2.aap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AapApplicationTests {

	@Test
	void contextLoads() {
	}

}
