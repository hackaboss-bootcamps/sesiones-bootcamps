package com.grupo2.aap.Service.Seguridad.LogsOperaciones;


import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Seguridad.LogsOperaciones.LogAdministracion;
import com.grupo2.aap.IRepository.Seguridad.LogsOperaciones.ILogAdministracionRepository;
import com.grupo2.aap.Iservice.Seguridad.LogsOperaciones.ILogAdministracionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que contiene el Servicio de sobre el Repositorio LogAdministracion
 *
 * */

@Service
public class LogAdministracionService implements ILogAdministracionService {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Repositorio de LogAdministracion */
    @Autowired
    private ILogAdministracionRepository repository;

    /** Sistema de Control de la Seguridad que controlará los accesos por parte de los usuarios y
     * las actividades realizadas por los mismos */
    private SecurityCtrl securityCtrl;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos para el Control de la Seguridad">


    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    @Override
    public void setSecurityCtrl(SecurityCtrl securityCtrl) {
        this.securityCtrl = securityCtrl;
    }


// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Consultas">


    /**
     * Método que devuelve todos los log de administracion de la Base de Datos
     *
     * @return Lista de Logs de la Capa de Persistencia
     */
    @Override
    public List<LogAdministracion> all(){
        List<LogAdministracion> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = repository.findAll();
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que devuelve los log de administracion cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador del log de administracion del que se quiere obtener la información
     * @return Log de administracion que cumple con los requisitos de búsqueda.
     */
    @Override
    public Optional<LogAdministracion> findById(Long PId){
        Optional<LogAdministracion> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion=repository.findById(PId);
        }else{
            VDevolucion=Optional.empty();
        }

        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de log de administracion cuya operacion es la que se introduce
     * por parámetro.
     *
     * @param POperacion Operacion del log de administracion sobre el que se realizará la consulta.
     * @return Lista de log de administracion cuya operacion coincide con el parámetro de entrada.
     */
    @Override
    public List<LogAdministracion> findListByOperation(Long POperacion){
        List<LogAdministracion> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByOperation(POperacion);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }


    /**
     * Método que encuentra la lista de log de administracion cuyo tipo de entidad es el que se introduce
     * por parámetro.
     *
     * @param PTipoEntidad Tipo de entidad del log de administracion sobre el que se realizará la consulta.
     * @return Lista de log de administracion cuyo tipo de entidad coincide con el parámetro de entrada.
     */
    @Override
    public List<LogAdministracion> findListByTypeOfEntity(Long PTipoEntidad){
        List<LogAdministracion> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByTypeOfEntity(PTipoEntidad);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }


    /**
     * Método que encuentra la lista de log de administracion cuya entidad es la que se introduce
     * por parámetro.
     *
     * @param PEntidad Entidad del log de administracion sobre la que se realizará la consulta.
     * @return Lista de log administracion cuya entidad coincide con el parámetro de entrada.
     */
    @Override
    public List<LogAdministracion> findListByEntity(Long PEntidad){
        List<LogAdministracion> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByEntity(PEntidad);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }


    /**
     * Método que encuentra la lista de log de administracion cuya fecha inicial y fecha final son las que se introducen
     * por parámetro.
     * @param PFechaInicio Fecha inicial del log de administracion sobre la que se realizará la consulta.
     * @param PFechaFin Fecha final del log de administracion sobre la que se realizará la consulta.
     * @return Lista de log de administracion cuyas fechas iniciales y fechas finales coincide con el parámetro de entrada.
     */
    @Override
    public List<LogAdministracion> findByDate(LocalDateTime PFechaInicio, LocalDateTime PFechaFin){
        List<LogAdministracion> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findByDate(PFechaInicio,PFechaFin);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }


    /**
     * Método que encuentra la lista de log administracion cuyo usuario es el que se introduce
     * por parámetro.
     *
     * @param PUsuario Usuario del log de administracion sobre el que se realizará la consulta.
     * @return Lista de log de administracion cuyo usuario coincide con el parámetro de entrada.
     */
    @Override
    public List<LogAdministracion> findListByUser(Long PUsuario){
        List<LogAdministracion> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByUser(PUsuario);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }


    /**
     * Método que encuentra la lista de log de administracion cuyo mensaje es el que se introduce
     * por parámetro.
     *
     * @param PMensaje Mensaje del log de administracion sobre el que se realizará la consulta.
     * @return Lista de log de administracion cuyo mensaje coincide con el parámetro de entrada.
     */
    @Override
    public List<LogAdministracion> findListByMessage(String PMensaje){
        List<LogAdministracion> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findListByMessage(PMensaje);
        }else{
            VDevolucion = null;
        }

        return VDevolucion;
    }
// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de la Persistencia">

    /**
     * Método que Guarda la información del log de administracion que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PLogAdministracion Entidad del log de administracion que se desea almacenar.
     * @return Log de administracion con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public LogAdministracion save(LogAdministracion PLogAdministracion){
        LogAdministracion VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion=repository.save(PLogAdministracion);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

// </editor-fold>


}

