package com.grupo2.aap.Iservice.Seguridad.MaestrasSeguridad;

import com.grupo2.aap.Entity.Seguridad.MaestrasSeguridad.LogTipoEntidad;

import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que será de obligada implementación por parte del servicio asociado.
 *
 * */
public interface ILogTipoEntidadService {

    /**
     * Método que devuelve todos los Tipos de Entidades de seguridad de la Base de Datos
     *
     * @return Lista de log de Tipos de Entidades de seguridad de la Base de Datos
     */    
    List<LogTipoEntidad> all();

    /**
     * Método que devuelve Tipo Entidad de seguridad cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador del log de ventas de seguridad del que se quiere obtener la información
     * @return Lista de Tipos Entidades de seguridad que cumple con los requisitos de búsqueda.
     */
    Optional<LogTipoEntidad> findById(Long PId);

    /**
     * Método que devuelve Tipo Entidad de seguridad cuyo Nombre Coincide total o parcialmente con el
     * introducir por parámetro.
     *
     * @param PNombre Nombre del Tipo Entidad que se desea consultar
     * @return Lista de Tipos Entidades de seguridad que cumple con los requisitos de búsqueda.
     */
    List<LogTipoEntidad> findListByName(String PNombre);
    
    /**
     * Método que Guarda la información del Tipo Entidad de seguridad que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PLogTipoEntidad Entidad del log de Tipo Entidad de seguridad que se desea almacenar.
     * @return Tipo Entidad de seguridad que se ha guardado
     */
    LogTipoEntidad save(LogTipoEntidad PLogTipoEntidad);

    /**
     * Método que Actualiza la información del Tipo Entidad de seguridad que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador del Tipo Entidad de Seguridad que se desea Actualizar.
     * @param PLogTipoEntidad Entidad del log de Tipo Entidad de seguridad que se desea almacenar.
     */
    void update(Long PId, LogTipoEntidad PLogTipoEntidad);

    /**
     * Método que Elimina la información del Tipo Entidad de seguridad que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador del Tipo Entidad de Seguridad que se desea Eliminar.
     */
    void delete(Long PId);

    
}
