package com.grupo2.aap.Service.Seguridad;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Entity.Seguridad.Usuario;
import com.grupo2.aap.Entity.Ventas.Cliente;
import com.grupo2.aap.IRepository.Seguridad.IUsuarioRepository;
import com.grupo2.aap.Iservice.Seguridad.IUsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que contiene el Servicio de sobre el Servicio de Usaurios
 *
 * */
@Service
public class UsuarioService implements IUsuarioService {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Repositorio de Usuarios*/
    @Autowired
    private IUsuarioRepository repository;

    /** Sistema de Control de la Seguridad que controlará los accesos por parte de los usuarios y
     * las actividades realizadas por los mismos */
    private SecurityCtrl securityCtrl;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos para el Control de la Seguridad">

    /**
     * Método que Introduce el Control de Seguridad en el Servicio
     *
     * @param securityCtrl Objeto para el control de la seguridad en el servicio
     */
    @Override
    public void setSecurityCtrl(SecurityCtrl securityCtrl) {
        this.securityCtrl = securityCtrl;
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Consultas">

    /**
     * Método que devuelve todos los usuarios de la Base de Datos
     *
     * @return Lista de usuarios de la Base de Datos
     */
    @Override
    public List<Usuario> all() {
        List<Usuario> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = repository.findAll();
        }else{
            VDevolucion = null;
        }
        return VDevolucion;
    }

    /**
     * Método que devuelve el usuario cuyo Identificador coincide con el parámetro
     * de entrada.
     *
     * @param PId Identificador del Usuario del que se quiere obtener la información
     * @return Usuario que cumple con los requisitos de búsqueda.
     */
    @Override
    public Optional<Usuario> findById(Long PId) {
        Optional<Usuario> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = repository.findById(PId);
        }else{
            VDevolucion = Optional.empty();
        }
        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de usuario cuyo empleado es el que se introduce
     * por parámetro.
     *
     * @param PEmpleado Empleado del usuario sobre el que se realizará la consulta.
     * @return Lista de Usuarios cuyo empleado coincide con el parámetro de entrada.
     */
    @Override
    public List<Usuario> findByEmployee(Long PEmpleado) {
        List<Usuario> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findByEmployee(PEmpleado);
        }else{
            VDevolucion = null;
        }
        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de usuarios cuyo nombre de usuario es el que se introduce
     * por parámetro.
     *
     * @param PNombreUsuario Nombre de usuario del usuario sobre el que se realizará la consulta.
     * @return Lista de Usuario cuyo nombre de usuario coincide con el parámetro de entrada.
     */
    @Override
    public List<Usuario> findByName(String PNombreUsuario) {
        List<Usuario> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = repository.findByName(PNombreUsuario);
        }else{
            VDevolucion = null;
        }
        return VDevolucion;
    }

    /**
     * Método que encuentra la lista de usuarios cuyo Rol es el que se introduce
     * por parámetro.
     *
     * @param PAdministrador Administrador del usuario sobre el que se realizará la consulta.
     * @return Lista de Usuarios cuyo administrador coincide con el parámetro de entrada.
     */
    @Override
    public List<Usuario> findByRol(Boolean PAdministrador) {
        List<Usuario> VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = this.repository.findByRol(PAdministrador);
        }else{
            VDevolucion = null;
        }
        return VDevolucion;
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de la Persistencia">

    /**
     * Método que autentifica al usuario mediante un Nombre de Usaurio y una Password
     *
     * @param PNombreUsuario Nombre de usuario del usuario sobre el que se realizará la consulta.
     * @param PContrasenha Contraseña del usuario sobre el que se realizará la consulta.
     * @return Lista de Usuarios cuyo nombre de usuario y contraseña coinciden con los parámetros de entrada.
     */
    @Override
    public Optional<Usuario> authenticate(String PNombreUsuario, String PContrasenha) {
        return this.repository.authenticate(PNombreUsuario,PContrasenha);
    }

    /**
     * Método que Guarda la información del usuario que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PUsuario Entidad Usuario que se desea almacenar.
     * @return Usuario con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public Usuario save(Usuario PUsuario) {
        Usuario VDevolucion;

        if (this.securityCtrl.isAdministrator()){
            VDevolucion = repository.save(PUsuario);
        }else{
            VDevolucion = null;
        }
        return VDevolucion;
    }

    /**
     * Método que Guarda los cambios de la información del usuario que se introduce por parámetro en la
     * Base de Datos
     *
     * @param PId Identificador de la Entidad Usuario que se desea Actualizar.
     * @param PUsuario Entidad Usuario que se desea Actualizar.
     * @return Usuario con los datos que han sido guardados en la Base de Datos
     */
    @Override
    public Usuario update(Long PId, Usuario PUsuario) {
        Usuario VDevolucion;
        Optional<Usuario> VUsuario;

        try{
            VUsuario = repository.findById(PId);

            if(!VUsuario.isEmpty()){
                PUsuario.setId(VUsuario.get().getId());

                VDevolucion = repository.save(PUsuario);
            }else{
                VDevolucion =null;
            }
        }catch (Exception ex){
            VDevolucion = null;
        }

        return VDevolucion;
    }

    /**
     * Método que elimina el Usuario que se introduce por parámetro de la Base de Datos
     *
     * @param PId Identificador del Usuario que se desea Eliminar.
     */
    @Override
    public boolean delete(Long PId) {
        boolean VDevolucion;
        Optional<Usuario> VUsuario;

        if (this.securityCtrl.isAdministrator()){
            VUsuario = this.findById(PId);

            if (!VUsuario.isEmpty()){
                VUsuario.get().setFechaEliminacion(LocalDateTime.now());
                VDevolucion = (this.save(VUsuario.get())!=null);
            }else{
                VDevolucion=false;
            }
        }else{
            VDevolucion=false;
        }

        return VDevolucion;
    }


// </editor-fold>

}
