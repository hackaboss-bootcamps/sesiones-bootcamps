package com.grupo2.aap.Controller.Fidelizacion;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Component.SecuritySession;
import com.grupo2.aap.Entity.Fidelizacion.Participacion;
import com.grupo2.aap.Entity.Fidelizacion.Sorteo;
import com.grupo2.aap.Iservice.Fidelizacion.ISorteoService;
import jdk.jshell.spi.ExecutionControlProvider;
import org.hibernate.type.LocalDateType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/sorteo")
public class SorteoController {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    @Autowired
    private ISorteoService service;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos Controladores de Conexión">

    @GetMapping("/ID")
    public Optional<Sorteo> show(@RequestParam Long id) {
        return service.findById(id);
    }

    @GetMapping("/NO")
    public List<Sorteo> findByName(@RequestParam String nombre) {
        return service.findByNombre(nombre);
    }

    @GetMapping("/FC")
    public List<Sorteo> findByCreationDate(@RequestParam String fechaInicio,
                                           @RequestParam String fechaFin) {
        List<Sorteo> VDevolucion;
        DateTimeFormatter VFormateador = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        LocalDateTime VFechaInicio;
        LocalDateTime VFechaFin;

        try{
            fechaInicio=fechaInicio+" 00:00";
            fechaFin=fechaFin+" 00:00";
            VFechaInicio=LocalDateTime.parse(fechaInicio, VFormateador);
            VFechaFin=LocalDateTime.parse(fechaFin, VFormateador);

            VDevolucion=service.findByCreationDate(VFechaInicio,VFechaFin);;
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @GetMapping("/FI")
    public List<Sorteo> findByStartDate(@RequestParam String fechaInicio,
                                        @RequestParam String fechaFin) {
        List<Sorteo> VDevolucion;
        DateTimeFormatter VFormateador = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        LocalDateTime VFechaInicio;
        LocalDateTime VFechaFin;

        try{
            fechaInicio=fechaInicio+" 00:00";
            fechaFin=fechaFin+" 00:00";
            VFechaInicio=LocalDateTime.parse(fechaInicio, VFormateador);
            VFechaFin=LocalDateTime.parse(fechaFin, VFormateador);

            VDevolucion=service.findByStartDate(VFechaInicio,VFechaFin);
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @GetMapping("/FF")
    public List<Sorteo> findByEndDate(@RequestParam String fechaInicio,
                                        @RequestParam String fechaFin) {
        List<Sorteo> VDevolucion;
        DateTimeFormatter VFormateador = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        LocalDateTime VFechaInicio;
        LocalDateTime VFechaFin;

        try{
            fechaInicio=fechaInicio+" 00:00";
            fechaFin=fechaFin+" 00:00";
            VFechaInicio=LocalDateTime.parse(fechaInicio, VFormateador);
            VFechaFin=LocalDateTime.parse(fechaFin, VFormateador);

            VDevolucion=service.findByFinalizeDate(VFechaInicio,VFechaFin);
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @GetMapping("/PC")
    public List<Sorteo> findByPresentCard(@RequestParam String dtoInicio,
                                          @RequestParam String dtoFin) {
        List<Sorteo> VDevolucion;
        Double VDtoInicio;
        Double VDtoFin;

        try{
            VDtoInicio=Double.valueOf(dtoInicio);
            VDtoFin=Double.valueOf(dtoFin);

            VDevolucion=service.findByDtoPresentCard(VDtoInicio,VDtoFin);
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @GetMapping("/DT")
    public List<Sorteo> findByDtoInvoice(@RequestParam Integer dtoInicio,
                                         @RequestParam Integer dtoFin) {
        return service.findByDtoInvoice(dtoInicio,dtoFin);
    }

    @GetMapping("/DP")
    public List<Sorteo> findByDaysParticipation(@RequestParam Integer cantidadInicio,
                                                @RequestParam Integer cantidadFin) {
        List<Sorteo> VDevolucion;

        try{
            VDevolucion=service.findByDaysParticipation(cantidadInicio,cantidadFin);
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @GetMapping("/MG")
    public List<Sorteo> findByMaxWinners(@RequestParam Integer cantidadInicio,
                                         @RequestParam Integer cantidadFin) {
        List<Sorteo> VDevolucion;

        try{
            VDevolucion=service.findByMaxWinners(cantidadInicio,cantidadFin);
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @GetMapping("/RS")
    public List<Participacion> realizarSorteo(HttpSession sesion) {
        List<Participacion> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        try{
            VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
            if (VSecurityCtrl!=null){
                service.setSecurityCtrl(VSecurityCtrl);
                VDevolucion=service.realizarSorteo();
            }else{
                VDevolucion=null;
            }
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @PostMapping("/SA")
    @ResponseStatus(code = HttpStatus.CREATED)
    public Sorteo save(@RequestBody Sorteo sorteo, HttpSession sesion) {
        Sorteo VDevolucion;
        SecurityCtrl VSecurityCtrl;

        try{
            VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
            if (VSecurityCtrl!=null){
                service.setSecurityCtrl(VSecurityCtrl);
                VDevolucion=service.save(sorteo);
            }else{
                VDevolucion=null;
            }
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @DeleteMapping()
    @ResponseStatus(code = HttpStatus.ACCEPTED)
    public boolean delete(@RequestParam Long id,
                          HttpSession sesion) {
        boolean VDevolucion;
        SecurityCtrl VSecurityCtrl;

        try{
            VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
            if (VSecurityCtrl!=null){
                service.setSecurityCtrl(VSecurityCtrl);

                VDevolucion=service.delete(id);
            }else{
                VDevolucion=false;
            }
        }catch (Exception ex){
            VDevolucion=false;
        }

        return VDevolucion;
    }

// </editor-fold>

}
