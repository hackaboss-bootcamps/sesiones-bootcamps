package com.grupo2.aap.Controller.Ventas;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Component.SecuritySession;
import com.grupo2.aap.Entity.Ventas.Cliente;
import com.grupo2.aap.Entity.Ventas.FormaPago;
import com.grupo2.aap.Iservice.Ventas.IFormaPagoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/formapago")
public class FormaPagoController {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    @Autowired
    private IFormaPagoService service;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos Controladores de Conexión">


    @GetMapping("/AL")
    public List<FormaPago> all() {
        return service.all();
    }

    @GetMapping("/ID")
    public Optional<FormaPago> show(@RequestParam Long id, HttpSession sesion) {
        Optional<FormaPago> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findById(id);
        }else{
            VDevolucion=null;
        }
        return VDevolucion;
    }

    @GetMapping("/NO")
    public List<FormaPago> findByName(@RequestParam String nombre, HttpSession sesion) {
        List<FormaPago> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByName(nombre);
        }else{
            VDevolucion=null;
        }
        return VDevolucion;
    }
// </editor-fold>

}
