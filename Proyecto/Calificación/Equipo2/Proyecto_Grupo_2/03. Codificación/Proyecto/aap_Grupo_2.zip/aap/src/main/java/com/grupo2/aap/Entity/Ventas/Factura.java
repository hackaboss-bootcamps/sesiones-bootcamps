package com.grupo2.aap.Entity.Ventas;

import com.grupo2.aap.Entity.Ventas.Component.FacturaData;

import javax.persistence.*;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que implementa la Entidad de Factura. Esta clase contendrá la información básica y las operaciones
 * Básicas con dicha información.
 *
 * */
@Entity
@Table(name="facturas")
public class Factura extends FacturaData {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Cliente de la Factura  */
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "cliente", nullable = false)
    private Cliente cliente;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Encapsulamiento">

    /**
     * Método que Devuelve el Cliente de la factura.
     *
     * @return Cliente de la factura.
     */
    public Cliente getCliente() {
        return cliente;
    }

    /**
     * Método que Introduce el Cliente de la Factura.
     *
     * @param cliente Cliente de la Factura.
     */
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de Datos">

    /**
     * Método que Clona la información de otra entidad factura en sí misma.
     *
     * @param PFacturaClonar Factura cuyos parámetros se desean clonar.
     * @return Sí se ha realizado correctamente o no la operación.
     */
    public boolean clone(Factura PFacturaClonar){
        boolean VDevolucion;

        try{
            this.setCliente(PFacturaClonar.getCliente());
            super.clone(PFacturaClonar);

            VDevolucion=true;
        }catch (Exception ex){
            VDevolucion=false;
        }

        return VDevolucion;
    }

// </editor-fold>

}