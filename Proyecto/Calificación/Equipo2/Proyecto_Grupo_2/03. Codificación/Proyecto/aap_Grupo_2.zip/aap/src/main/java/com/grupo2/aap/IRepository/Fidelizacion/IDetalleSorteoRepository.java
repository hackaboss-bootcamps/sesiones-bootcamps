package com.grupo2.aap.IRepository.Fidelizacion;
import com.grupo2.aap.Entity.Fidelizacion.DetalleSorteo;
import com.grupo2.aap.Entity.Fidelizacion.Sorteo;
import com.grupo2.aap.Entity.Ventas.DetalleFacturaSimplificada;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que permite la ejecución de las cláusulas SQL necesarias para servir de repositorio de
 * la entidad DetalleSorteo.
 *
 * */
@Repository
public interface IDetalleSorteoRepository  extends JpaRepository<DetalleSorteo,Long> {

    /**
     * Método que encuentra la lista de detalle sorteo  cuyo Atributo Porcentaje Descuento es el que se introduce
     * por parámetro.
     *
     * @param PDtoInicio Descuento Inicial sobre la que se realizará la consulta.
     * @param PDtoFin Descuento Final sobre la que se realizará la consulta.
     * @return Lista de Detalle De Sorteo cuyo DtoInicio y DtoFin coincide con los parámetros de entrada.
     */
    @Query(value = "SELECT * " +
            "FROM detalles_sorteos " +
            "WHERE porcentaje_descuento BETWEEN :dtoInicio AND :dtoFin",nativeQuery = true)
    List<DetalleSorteo> findByDto(@Param("dtoInicio") Integer PDtoInicio, @Param("dtoFin") Integer PDtoFin);

    /**
     * Método que encuentra la lista de detalle sorteo cuyo Atributo Producto es el que se introduce
     * por parámetro.
     *
     * @param PIdProducto Id de Producto sobre el que se realizará la consulta.
     * @return Lista de Detalle De Sorteo cuyo Id Producto coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT * " +
            "FROM detalles_sorteos " +
            "WHERE sorteo = :producto ",nativeQuery = true)
    List<DetalleSorteo> findByProduct(@Param("producto") Long PIdProducto);

    /**
     * Método que encuentra la lista de detalle sorteo cuyo Atributo Sorteo es el que se introduce
     * por parámetro.
     *
     * @param PIdSorteo Id de Sorteo sobre el que se realizará la consulta.
     * @return Lista de Detalle De Sorteo cuyo Id Sorteo coincide con el parámetro de entrada.
     */
    @Query(value = "SELECT * " +
            "FROM detalles_sorteos " +
            "WHERE sorteo = :sorteo ",nativeQuery = true)
    List<DetalleSorteo> findBySorteo(@Param("sorteo") Long PIdSorteo);


}
