package com.grupo2.aap.Entity.Fidelizacion;

import com.grupo2.aap.Entity.Ventas.Producto;

import javax.persistence.*;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que implementa la Entidad DetalleSorteo. Esta clase contendrá la información básica y las operaciones
 * Básicas con dicha información.
 *
 * */

@Entity
@Table(name="detalles_sorteos")
public class DetalleSorteo {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Id de la Entidad */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Sorteo de la Entidad */
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "sorteo", nullable = false)
    private Sorteo sorteo;

    /** Producto de la Entidad */
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "producto", nullable = false)
    private Producto producto;

    /** Porcentaje de Descuento de la Entidad */
    @Column(name = "porcentaje_descuento")
    private Integer PorcentajeDescuento=0;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Encapsulamiento">


    /**
     * Método que Devuelve el Id de la entidad.
     *
     * @return Id de la entidad.
     */
    public Long getId() {
        return id;
    }

    /**
     * Método que Introduce el Id de la entidad.
     *
     * @param id de la entidad.
     *
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Método que Devuelve el Sorteo de la entidad.
     *
     * @return Sorteo de la entidad.
     */
    public Sorteo getSorteo() {
        return sorteo;
    }

    /**
     * Método que Introduce el Sorteo de la entidad.
     *
     * @param sorteo de la entidad.
     *
     */
    public void setSorteo(Sorteo sorteo) {
        this.sorteo = sorteo;
    }

    /**
     * Método que Devuelve el Producto de la entidad.
     *
     * @return Producto de la entidad.
     */
    public Producto getProducto() {
        return producto;
    }

    /**
     * Método que Introduce el Producto de la entidad.
     *
     * @param producto de la entidad.
     *
     */
    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    /**
     * Método que Devuelve el Porcentaje de Descuento de la entidad.
     *
     * @return Porcentaje de descuento de la entidad.
     */
    public Integer getPorcentajeDescuento() {
        return PorcentajeDescuento;
    }

    /**
     * Método que Introduce el Porcentaje de Descuento de la entidad.
     *
     * @param porcentajeDescuento de la entidad.
     *
     */
    public void setPorcentajeDescuento(Integer porcentajeDescuento) {
        PorcentajeDescuento = porcentajeDescuento;
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de Datos">

    /**
     * Método que Clona la información de la entidad detallesorteo en sí misma.
     *
     * @param PDetalleSorteoClonar DetalleSorteo cuyos parámetros se desean clonar.
     * @return Sí se ha realizado correctamente o no la operación.
     */
    public boolean clone(DetalleSorteo PDetalleSorteoClonar){
        boolean VDevolucion;

        try{
            this.setId(PDetalleSorteoClonar.getId());
            this.setSorteo(PDetalleSorteoClonar.getSorteo());
            this.setProducto(PDetalleSorteoClonar.getProducto());
            this.setPorcentajeDescuento(PDetalleSorteoClonar.getPorcentajeDescuento());

            VDevolucion = true;
        }catch (Exception ex){
            VDevolucion = false;
        }

        return VDevolucion;
    }

// </editor-fold>

}
