package com.grupo2.aap.Entity.Ventas;

import com.grupo2.aap.Entity.Fidelizacion.DetalleSorteo;
import com.grupo2.aap.Entity.Fidelizacion.Participacion;
import com.grupo2.aap.Entity.Fidelizacion.Sorteo;
import com.grupo2.aap.Iservice.Fidelizacion.IParticipacionService;
import com.grupo2.aap.Iservice.Fidelizacion.ISorteoService;
import com.grupo2.aap.Iservice.Ventas.IDetalleFacturaService;
import com.grupo2.aap.Iservice.Ventas.IFacturaService;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que implementa una configuración para unir los dotos de la Entidad Factura con los datos de la
 * Entidad DetalleFactura
 *
 * */
public class FacturaExtendida extends Factura {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Servicio de Factura que será usado para el tratamiento de los datos de Facturas*/
    private IFacturaService facturaService;

    /** Servicio de DetalleFactura que será usado para el tratamiento de los datos de los Detalles Facturas*/
    private IDetalleFacturaService detalleFacturaService;

    /** Servicio de Participación que será usado para el tratamiento de los datos de las Participaciones generadas*/
    private IParticipacionService participacionService = null;

    /** Servicio de Sorteo que será usado para el tratamiento de los Sorteos en el que está implicada la Factura*/
    private ISorteoService sorteoService = null;

    /** Lista de Detalles de la Factura*/
    List<DetalleFactura> detalleFactura=null;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Constructores de la Clase">

    /**
     * Constructor nulo de la clase necesario para que el controlador cargue correctamente el Objeto
     */
    public FacturaExtendida(){

    }

    /**
     * Constructor en el que se introducen los parámetros básicos de configuración de servicios
     *
     * @param PFacturaService Servicio de Factura
     * @param PDetalleFacturaService Servicio de Detalles de Factura
     * @param PParticipacionService Servicio de Participaciones
     * @param PSorteoService Servicio de Sorteos
     *
     */
    public FacturaExtendida(IFacturaService PFacturaService,
                            IDetalleFacturaService PDetalleFacturaService,
                            IParticipacionService PParticipacionService,
                            ISorteoService PSorteoService){

        this.setServices(PFacturaService,
                            PDetalleFacturaService,
                            PParticipacionService,
                            PSorteoService);

    }

    /**
     * Constructor en el que se introducen los parámetros básicos de configuración de servicios
     *
     * @param PFactura Factura sobre la que se trabajará y que provee de vínculo con el Repositorio
     * @param PFacturaService Servicio de Factura
     * @param PDetalleFacturaService Servicio de Detalles de Factura
     * @param PParticipacionService Servicio de Participaciones
     * @param PSorteoService Servicio de Sorteos
     *
     */
    public FacturaExtendida(Factura PFactura,
                            IFacturaService PFacturaService,
                            IDetalleFacturaService PDetalleFacturaService,
                            IParticipacionService PParticipacionService,
                            ISorteoService PSorteoService){

        this.clone(PFactura);
        this.setServices(PFacturaService,
                PDetalleFacturaService,
                PParticipacionService,
                PSorteoService);

    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Encapsulamiento">

    /**
     * Método que se encarga de introducir de forma confiable los Servicios dentro
     * del Objeto
     *
     * @param PFacturaService Servicio de Factura
     * @param PDetalleFacturaService Servicio de Detalles de Factura
     * @param PParticipacionService Servicio de Participaciones
     * @param PSorteoService Servicio de Sorteos
     * @return Sí se ha realizado correctamente o no la operación.
     */
    public boolean setServices(IFacturaService PFacturaService,
                               IDetalleFacturaService PDetalleFacturaService,
                               IParticipacionService PParticipacionService,
                               ISorteoService PSorteoService){
        boolean VDevolucion;

        try{
            this.facturaService=PFacturaService;
            this.detalleFacturaService=PDetalleFacturaService;
            this.participacionService=PParticipacionService;
            this.sorteoService=PSorteoService;

            VDevolucion=true;
        }catch (Exception ex){
            VDevolucion=false;
        }

        return VDevolucion;
    }

    /**
     * Método que devuelve el detalle de la factura. La carga de la lista de detalles de factura
     * siempre es bajo demanda.
     *
     * @return Devuelve la lista de Detalles de la Factura.
     *                  null: En caso de error
     */
    public List<DetalleFactura> getDetalleFactura() {
        List<DetalleFactura> VDevolucion;

        try{
            if (detalleFactura==null){
                this.detalleFactura=detalleFacturaService.findByInvoice(this.getId());
            }
            if (this.detalleFactura!=null){
                VDevolucion=this.detalleFactura;
            }else{
                VDevolucion=null;
            }
        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    /**
     * Método que Permite la introducción de los Detalles de la Factura desde otro objeto
     *
     * @param detalleFactura Lista de Detalles de Factura que se desean incluir
     */
    public void setDetalleFactura(List<DetalleFactura> detalleFactura) {
        this.detalleFactura = detalleFactura;
    }


    /**
     * Método que devuelve el Total de la Factura teniendo en cuenta todos los descuentos e impuestos.
     * En este método también se toma en cuenta sí a la factura se le quiere compensar con participaciones
     * premiadas
     *
     * @return Devuelve el Valor total de la Factura
     *              null: En caso de error
     */
    public Double getTotalFactura(){
        Double VDevolucion;
        List<Participacion> VParticipaciones;
        Participacion VParticipacion=null;

        try{
            if (this.participacionService!=null){
                VParticipaciones=this.participacionService.findByApplicationInvoice(this.getId());
                if (VParticipaciones!=null && !VParticipaciones.isEmpty()){
                    VParticipacion = VParticipaciones.get(0);
                }
            }

            if (this.getDetalleFactura()!=null){
                VDevolucion=calcularTotalLineasFactura(VParticipacion);

                VDevolucion=this.calcularTotalFactura(VDevolucion,VParticipacion);

                VDevolucion=Double.valueOf(Math.round(VDevolucion.doubleValue()*100.0)/100.0);
            }else{
                VDevolucion=0.0;
            }

        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Registro en Persistencia">

    /**
     * Método que Guarda los datos Generales de la Factura en la capa de persistencia
     *
     * @return Devuelve si se ha realizado correctamente la operación o no
     */
    public boolean save(){
        boolean VDevolucion;
        Factura VFactura;
        int VIndice;

        try{
            VFactura=new Factura();
            VFactura.clone(this);

            VFactura=this.facturaService.save(VFactura);
            if (VFactura!=null){
                this.setId(VFactura.getId());
                VDevolucion=(this.saveDetallesFactura()==true);
            }else{
                VDevolucion=false;
            }
        }catch (Exception ex){
            VDevolucion=false;
        }

        return VDevolucion;
    }

    /**
     * Método que Guarda los datos de los detalles de la Factura en la capa de persistencia
     *
     * @return Devuelve si se ha realizado correctamente la operación o no
     */
    public boolean saveDetallesFactura(){
        boolean VDevolucion=true;
        int VIndice;

        try{
            if (this.detalleFactura!=null){
                for (VIndice=0;VIndice<this.detalleFactura.size();VIndice++){
                    VDevolucion=VDevolucion && this.saveDetalleFactura(this.detalleFactura.get(VIndice));
                }
            }else{
                VDevolucion=false;
            }
        }catch (Exception ex){
            VDevolucion=false;
        }

        return VDevolucion;
    }

    /**
     * Método que Guarda un detalle de la factura en en la capa de persistencia
     *
     * @param PDetalleFactura Detalle de Factura que se desea guardar
     * @return Devuelve si se ha realizado correctamente la operación o no
     */
    private boolean saveDetalleFactura(DetalleFactura PDetalleFactura){
        boolean VDevolucion;

        try{
            PDetalleFactura.setFactura(this);
            this.detalleFacturaService.save(PDetalleFactura);

            VDevolucion=true;
        }catch (Exception ex){
            VDevolucion=false;
        }

        return VDevolucion;
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Herramientas de la Clase">

    /**
     * Método que se encarga de calcular el total de los Detalles de Factura
     *
     * @param PParticipacion Participación que se desea icorporar para la reducción
     *                       del valor de los productos.
     * @return Valor del los productos del detalle de la factura.
     */
    private Double calcularTotalLineasFactura(Participacion PParticipacion){
        Double VDevolucion=0.0;
        int VIndice;
        List<DetalleSorteo> VListaProductosConDescuento=new ArrayList<>();
        Sorteo VSorteo;
        DetalleFactura VDetalleFacturaAux;

        try{
            if (PParticipacion!=null){
                VSorteo=PParticipacion.getSorteo();
                VListaProductosConDescuento = this.sorteoService.findDetallesSorteo(VSorteo);
            }

            for (VIndice=0;VIndice<this.detalleFactura.size();VIndice++){
                VDetalleFacturaAux=this.detalleFactura.get(VIndice);

                VDevolucion=VDevolucion+this.CalcularTotalLinea(VDetalleFacturaAux,
                                                                VListaProductosConDescuento);
            }

        }catch (Exception ex){
            VDevolucion=null;
        }

        return VDevolucion;
    }

    /**
     * Método que se encarga de calcular el Valor de una línea en concreta de los Detalles de Factura
     *
     * @param PDetalleFactura Detalle factura de la que se desea calcular el total teniendo en cuenta
     *                        los productos con descuento que se introducen a través del otro parámetro.
     * @param PListaProductosConDescuento Lista de productos con descuento sobre el que hay que comprobar
     *                                    sí el producto del detalle tiene descuento.
     *
     * @return Valor del detalle de la factura.
     */
    private Double CalcularTotalLinea(DetalleFactura PDetalleFactura,
                                      List<DetalleSorteo> PListaProductosConDescuento){
        Double VDevolucion;
        Double VTotalParcialBase;
        Double VDtoAux;
        Double VIvaAux;
        Integer VPorcentajeDescuentoPromocion;

        try{
            VTotalParcialBase=PDetalleFactura.getCantidad()*PDetalleFactura.getPrecioUnitario();

            VDtoAux=(VTotalParcialBase)*(Double.valueOf(PDetalleFactura.getDtoPorcentaje())/100);
            VTotalParcialBase=VTotalParcialBase-VDtoAux;

            VPorcentajeDescuentoPromocion=this.buscarDescuento(PDetalleFactura.getProducto(),PListaProductosConDescuento);
            if (VPorcentajeDescuentoPromocion==-1){
                VPorcentajeDescuentoPromocion=0;
            }
            VDtoAux=(VTotalParcialBase)*(Double.valueOf(VPorcentajeDescuentoPromocion)/100);
            VTotalParcialBase=VTotalParcialBase-VDtoAux;

            VIvaAux=(VTotalParcialBase)*(Double.valueOf(PDetalleFactura.getIva())/100);

            VDevolucion=(VTotalParcialBase+VIvaAux);
        }catch (Exception ex){
            VDevolucion = -1.0;
        }

        return VDevolucion;
    }

    /**
     * Método que se encarga de Buscar el Descuento asociado al producto que se introduce por parámetro
     *
     * @param PProducto Producto del que se desea comprobar la existencia de descuentos.
     * @param PListaProductosConDescuento Lista de productos con descuento sobre el que hay que comprobar
     *                                    sí el producto tiene descuento.
     *
     * @return Porcentaje de Descuento a aplicar al Producto
     */
    private Integer buscarDescuento(Producto PProducto,
                                      List<DetalleSorteo> PListaProductosConDescuento){
        Integer VDevolucion;
        int VIndice=0;
        boolean VEncontrado = false;

        try{
            while (VIndice<PListaProductosConDescuento.size() && ! VEncontrado){

                VEncontrado=(PListaProductosConDescuento.get(VIndice).getProducto().getId() == PProducto.getId());

                VIndice++;
            }

            if (VEncontrado){
                VDevolucion= PListaProductosConDescuento.get(VIndice-1).getPorcentajeDescuento();
            }else{
                VDevolucion=0;
            }

        }catch (Exception ex){
            VDevolucion = -1;
        }

        return VDevolucion;
    }

    /**
     * Método que se encarga de Calcular el total de la Factura
     *
     * @param PTotalLineas Importe total de los Detalles de la Factura, incluyendo los posibles descuentos
     * @param PParticipacion Participación a tomar en cuenta para los premios asociados a la totalidad de la
     *                       factura y no a los detalles de la misma.
     *
     * @return Importe total de la Factura
     */
    private Double calcularTotalFactura(Double PTotalLineas,Participacion PParticipacion){
        Double VDevolucion;
        Sorteo VSorteo;
        Double VDtoAux;

        try{
            if (PParticipacion!=null){
                VSorteo = PParticipacion.getSorteo();
                if (VSorteo.devolverTipoPremio()==Sorteo.PREMIO_DTO_PORCENTAJE_FACTURA){
                    VDtoAux=(PTotalLineas)*(Double.valueOf(VSorteo.getPorcentajeDescuentoFactura())/100);
                }else{
                    if (VSorteo.devolverTipoPremio()==Sorteo.PREMIO_DTO_TARJETA_REGALO){
                        VDtoAux=VSorteo.getDescuentoTarjetaRegalo();
                    }else{
                        VDtoAux=0.0;
                    }
                }
                VDevolucion=PTotalLineas-VDtoAux;
            }else{
                VDevolucion=-1.0;
            }
        }catch (Exception ex){
            VDevolucion=-1.0;
        }

        return VDevolucion;
    }

// </editor-fold>

}
