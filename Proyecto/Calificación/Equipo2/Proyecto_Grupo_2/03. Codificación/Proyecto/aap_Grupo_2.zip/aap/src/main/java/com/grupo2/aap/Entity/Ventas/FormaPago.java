package com.grupo2.aap.Entity.Ventas;

import com.grupo2.aap.Entity.Component.PersonalData;
import com.grupo2.aap.Entity.Seguridad.Empleado;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Clase que implementa la Entidad de FormaPago. Esta clase contendrá la información básica y las operaciones
 * Básicas con dicha información.
 *
 * */
@Entity
@Table (name = "Formas_Pago")
public class FormaPago {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    /** Id de la Forma de Pago */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    /** Nombre de la Forma de Pago */
    @Column(name = "nombre",nullable = false,length = 50)
    private String nombre;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Encapsulamiento">

    /**
     * Método que Devuelve el Id de la Forma de Pago.
     *
     * @return Id de la Forma de Pago.
     */
    public long getId() {
        return id;
    }

    /**
     * Método que Introduce el Id de la Forma de Pago.
     *
     * @param id de la Forma de Pago.
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * Método que Devuelve el Nombre de la Forma de Pago.
     *
     * @return Nombre de la Forma de Pago.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Método que Introduce el Nombre de la Forma de Pago.
     *
     * @param nombre de la Forma de Pago.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos de Tratamiento de Datos">

    /**
     * Método que Clona la información de otra entidad formapago en sí misma.
     *
     * @param PFormaPagoClonar FormaPago cuyos parámetros se desean clonar.
     * @return Sí se ha realizado correctamente o no la operación.
     */
    public boolean clone(FormaPago PFormaPagoClonar){
        boolean VDevolucion;

        try{
            this.setNombre(PFormaPagoClonar.getNombre());

            VDevolucion = true;
        }catch (Exception ex){
            VDevolucion = false;
        }

        return VDevolucion;
    }

// </editor-fold>

}