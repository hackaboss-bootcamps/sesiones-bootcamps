package com.grupo2.aap.Controller.Seguridad.LogsOperaciones;

import com.grupo2.aap.Component.SecurityCtrl;
import com.grupo2.aap.Component.SecuritySession;
import com.grupo2.aap.Entity.Seguridad.LogsOperaciones.LogVentas;
import com.grupo2.aap.Entity.Seguridad.LogsOperaciones.LogVentas;
import com.grupo2.aap.Iservice.Seguridad.LogsOperaciones.ILogVentasService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/logventas")
public class LogVentasController {

// <editor-fold defaultstate="collapsed" desc="Atributos">

    @Autowired
    private ILogVentasService service;

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Métodos Controladores de Conexión">

    @GetMapping("/ID")
    public Optional<LogVentas> show(@RequestParam Long id, HttpSession sesion) {
        Optional<LogVentas> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findById(id);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

    @GetMapping("/OP")
    public List<LogVentas> findByOperation(@RequestParam Long operation, HttpSession sesion) {
        List<LogVentas> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByOperation(operation);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }


    @GetMapping("/TE")
    public List<LogVentas> findListByTypeOfEntity(@RequestParam Long tipoEntidad, HttpSession sesion) {
        List<LogVentas> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByTypeOfEntity(tipoEntidad);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }


    @GetMapping("/EN")
    public List<LogVentas> findListByEntity(@RequestParam Long entidad, HttpSession sesion) {
        List<LogVentas> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByEntity(entidad);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }


    @GetMapping("/FE")
    public List<LogVentas> findByDate(@RequestParam LocalDateTime fechaInicio,
                                              @RequestParam LocalDateTime fechaFin,
                                              HttpSession sesion) {
        List<LogVentas> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findByDate(fechaInicio,fechaFin);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }


    @GetMapping("/US")
    public List<LogVentas> findListByUser(@RequestParam Long usuario,
                                                  HttpSession sesion){
        List<LogVentas> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByUser(usuario);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }


    @GetMapping("/ME")
    public List<LogVentas> findListByMessage(@RequestParam String mensaje,
                                                     HttpSession sesion) {
        List<LogVentas> VDevolucion;
        SecurityCtrl VSecurityCtrl;

        VSecurityCtrl = SecuritySession.getSecurityCtrl(sesion);
        if (VSecurityCtrl!=null){
            service.setSecurityCtrl(VSecurityCtrl);
            VDevolucion=service.findListByMessage(mensaje);
        }else{
            VDevolucion=null;
        }

        return VDevolucion;
    }

// </editor-fold>

}
