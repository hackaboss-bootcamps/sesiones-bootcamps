package com.grupo2.aap.IRepository.Seguridad.MestrasSeguridad;

import com.grupo2.aap.Entity.Seguridad.MaestrasSeguridad.LogTipoEntidad;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * @author Grupo2
 * @Version v1 del 01/10/2023
 *
 * Interfaz que permite la ejecución de las cláusulas SQL necesarias para servir de repositorio de
 * la entidad LogTipoEntidad
 * */
public interface ILogTipoEntidadRepository extends JpaRepository<LogTipoEntidad,Long> {

    /**
     * Método que encuentra la lista de Tipos de Entidades que pueden registrar en los LOGS
     *
     * @return Lista de Tipos de Entidades que se pueden registrar en los logs
     */
    @Query(value = "SELECT  * " +
            "FROM LogTipoEntidad " +
            "WHERE nombre LIKE %:nombre% ", nativeQuery = true)
    List<LogTipoEntidad> findListByName(@Param("nombre") String PNombre);

}
